近两天费老大劲装上了Win2K Beta。在这个过程中，还顺带装了一下NT4.0。下面分享一下总结的一点经验。
英文版NT4.0 Server镇楼
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/36fd2c37acaf2eddbaf9d2bd871001e93801934b.jpg)
我为什么要“顺带”装NT4.0呢？其实是因为我不懂得怎么把VMware的显示驱动提取出来以装上Win2K Beta，同时VMtools显然是不支持Win2K Beta的。所以我就用了笨办法，先在NT4.0装上VMtools再升级到Win2K Beta。这样虽然VMtools程序本身不能留住，但是各种驱动都完美保留[真棒]
装NT4.0没什么难的。
但是，要装上VMtools，是要折腾一下的。
首先，你们平时应该都装过NT4.0吧。这样你们就会知道，要装VMware Tools，要装上NT4.0的SP6（据说SP4好像也行，我没试过）。在中文版系统里这是没有问题的。但是现在我们要装（英文的）Win2K Beta，从中文版NT4.0启动安装的话只能全新安装而不能升级，那么装了NT4.0的驱动有卵用[喷]
好不容易下载到了英文版的NT4.0，你怀着紧张的心情装上虚拟机，但是很可能会发现SP6装不上，前功尽弃[怒]
如图，提示什么加密什么的不对。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/4ab2951ebe096b63144ddf0406338744eaf8ac00.jpg)
我看了Help，（在主机）上网找了半天，也只找到这仅有的一种英文版NT4.0的SP6安装包，而它不能装上我这里的NT4.0。当然如果有dalao有其他版本，也即我说的那种“加密等级”正确的SP6安装包，欢迎打脸[滑稽]
那么装不上SP6就装不了VMtools，怎么办？
我实践证明，NT4.0 Server装SP6会有这种问题，但是NT4.0 Workstation不会[滑稽][大拇指]
所以你们可以下载NT4.0的Workstation英文版。（我又是找了半天，幸运的是这种资源最后依靠百度云盘搜索引擎找到了[太开心]）
特别感谢xkai的分享。链接：https://pan.baidu.com/s/1sjz60zF
安装NT4.0 Workstation过程中，可能卡住的就是输入密钥这里。密钥我可以提供一个：
28997-OEM-0025957-49297
其他地方应该不会有问题。
装上NT4.0 Workstation后，装SP6和VMtools就没有压力了。从略。
展示一张NT4.0 Workstation安装完毕的截图。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/8861b642ad4bd1130e47426650afa40f49fb05d5.jpg)
下面开始升级到Win2K Beta。以Build 2000.3为例。
这里当然Upgrade啦
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/23d305d1f703918f1488c29e5b3d269758eec47b.jpg)
这里还是要特别感谢xkai，因为他提出了Win2K Beta在VMware上不能启动的问题的解决方案。
非常简单，在这个界面按下F5（不是F6）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/91e714f182025aafd1c5809ff1edab64014f1ae0.jpg)
然后选择Standard PC（默认Other）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/c5c182dce71190ef796b6c8bc41b9d16fffa60c3.jpg)
注：如果不这么做，稍后很可能卡在这个界面：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/191a5a6c55fbb2fbf94ea146454a20a44723dc77.jpg)
安装会提示少文件，不用害怕，直接按ESC跳过，没有问题的。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/411d5e00213fb80e7a7299833cd12f2eb838943c.jpg)
然后安装会顺利到达重启后阶段[滑稽][玫瑰]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/38049037afc3793170047c7de1c4b74542a9116f.jpg)
到了这里会出现一点小小的问题。系统问你要驱动文件！怎么办？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/411d5e00213fb80e84219b833cd12f2ebb3894ec.jpg)
其实这个东西不用现在弄，你点No就好了[滑稽]
这个界面需要很长时间。如果你发现已经过了很多分钟进度条还没有动怎么办？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/d53eb6c9a786c9174599b66dc33d70cf39c757c5.jpg)
***
粗暴重启！再不行再重启，最后会好的。
Win2K Beta有一点特别厚道，就是你如果忘了调时间，它不仅不会拒绝安装，还会特地提醒你赶快调对，这良心也是没谁了[滑稽][滑稽]@cghvbnv22 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/97de0758252dd42ae4a9e2ff093b5bb5c8eab83c.jpg)
然后的安装几乎不会有任何困难。你可以顺利地来到这个界面。小小地庆祝一下吧。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/f20f24176d224f4a925a914703f790529a22d19d.jpg)
值得注意的是，虽然这里还是16色，但是你登录的时候可以听到那具有时代气息的NT4.0 Workstation登录音乐（好像也称作开机音乐，不管它了），说明驱动还是至少部分地保留下来了的。如果虚拟声卡驱动没有保留下来的话，你在这就不会听到音乐了，而是VMware替虚拟机发出的蜂鸣器声。
接下来解决显卡驱动问题。
打开设备管理器。打开方法和现在的系统完全一样[haha]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/e1b0ca355982b2b73406d7903badcbef77099b3b.jpg)
打开Display adapters下的VMware SVGA II（上面那个）的属性。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/dedb600928381f30672364fda3014c086f06f0a6.jpg)
不用说，装驱动（Update Driver）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/746f643a5bb5c9eadf33ebb7df39b60038f3b39c.jpg)
当然要自己选而不是自动搜索。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/913cc087c9177f3e488214597acf3bc79e3d5621.jpg)
选“Have Disk”
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/833aa4fcfc039245e9050a5b8d94a4c27c1e2523.jpg)
系统会要inf文件。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/3632c0eece1b9d1601e34d35f9deb48f8d5464b0.jpg)
点“Browse”，定位到这个位置：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/49d0cc19972bd4077ae604a971899e510eb309b2.jpg)
使用这个文件。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/b2ebd9086b63f624de16ee578d44ebf81b4ca315.jpg)
然后Open-OK-Next-Next。之后就会到这：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/50cc3442fbf2b2114234531ac08065380dd78e46.jpg)
OK之后 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/1a5bc30e4bfbfbedf44fe72b72f0f736aec31f41.jpg)
接着到了这儿。与前面同样点“Browse”。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/20ad422cd42a28348b35e75f51b5c9ea17cebfcd.jpg)
定位到同样的位置，选择这个文件。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/06d76ef690529822db1be997ddca7bcb0b46d4b4.jpg)
***
之后Open-OK。然后就会成功安装了，FInish。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/75dea15d10385343363157759913b07ec88088da.jpg)
重启。重启后你连显示设置都不用动，真彩色就有了[花心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/d1d7f0dca144ad348f2555d3daa20cf433ad85c6.jpg)
你甚至可以完全正常地玩CS1.6，这个游戏的兼容性真的是超级好[真棒][真棒][真棒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/f0a59f188618367ab57aa48924738bd4b11ce5ed.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/90566bf531adcbefa3e6a552a6af2edda1cc9f8e.jpg)
***
Ra95也可以 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/b2ebd9086b63f624c1c5e1578d44ebf8184ca3c4.jpg)
显驱还是小case。声卡驱动则不那么容易了。今天我成功给1983装上了声卡驱动，将办法记录一下。
感谢@linaofeng 提出了NT4安装虚拟声卡的办法。原帖地址：![](http://tieba.baidu.com/p/3265510923
注意：从Beta3某个Build开始，Windows 2000已经自带了VM模拟的SBPCI128的声卡驱动，那种情况下系统自己就有声音，你不需要手动去给虚拟机装驱动。只有在虚拟机没有声音的情况下，才可能需要去装一下。
1.默认模拟的SBPCI128在NT5/2K预览版上难以安装。我们要把虚拟声卡改为SB16。
用记事本打开虚拟机的配置文件 （*.vmx) 在打开的文件的结尾添加一行文字：
sound.virtualDev = ""sb16""
2.a)如果你的Build与1381比较接近的话：
(1)打开控制面板->多媒体。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/c27fc11fa8d3fd1f8312d6913a4e251f94ca5f73.jpg)
***
(2)打开Devices->Add，选中Creative Labs Sound Blaster 1.X,Pro,16，再点OK。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/730ee58aa61ea8d33d1d03af9d0a304e241f5857.jpg)
(3)如果缺少文件，就将安装光盘塞进虚拟机，找到文件所在处。（一般是光盘:\i386\，除非你的镜像是自己手动包装的）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/11c9419659ee3d6d1475f16049166d224d4adedb.jpg)
***
(4)这些东西我们作为一般用户也没法弄，就用默认设置。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/ef371e300a55b319e3f0f4de49a98226cefc1700.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/3deab51a0ef41bd54f7a9e5f5bda81cb38db3d61.jpg)
(5)重启。
b)如果你的Build离1381已经比较远的话，
直接跟着图操作。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/99c7af94d143ad4b1a92026c88025aafa60f06d7.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/89e3183f6709c93dea9c4f5b953df8dcd0005421.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/3fca0008c93d70cfa094eba1f2dcd100bba12b21.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/27fdae3c70cf3bc7036e8c40db00baa1cc112a21.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5154437617/89c917ce3bc79f3d658fa59cb0a1cd11738b2921.jpg)
而后系统就能装上驱动了。
.Windows 2000 Build 1989
阶段：Beta3
编译日期：1999年2月25日
版本字串：5.0.1989.1
去除水印也很简单。办法：（转自脚本之家）
从Build 1989到2183，安装完成后，系统默认在桌面上显示出版本号。如果你觉得看起来不很舒服，我们可以把它隐藏起来：在注册表的HKEY_CURRENT_USER\ControlPanel\desktop位置下有一个名为 “PaintDesktopVersion”的DWORD值，把它的值修改为“0”即可。
