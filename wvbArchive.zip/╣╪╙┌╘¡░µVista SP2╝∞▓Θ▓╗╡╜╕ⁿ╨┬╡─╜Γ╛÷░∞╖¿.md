关于原版Vista SP2检查不到更新的办法，我似乎找到了解决方案[滑稽] [滑稽] [滑稽]，装上六个补丁后再检查更新就好了，我装上了这六个补丁后，第一次检查更新后报错[怒] [怒] [怒]，第二次再检查更新，扫出来182个重要更新[太开心][太开心][太开心]，补丁编号在下图上，各位有空可以试试
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/d2b1b189d43f879438ddfbbdda1b0ef41ad53a7c.jpg)
***
 诺基亚Lumia 1520
放一张大V更新的截图[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/553a51d2d539b6001d69bc24e150352ac45cb7f7.jpg)
***
 诺基亚Lumia 1520
@happymax1212 @longhorn4074 @vistawithsp2 @longhorn4093 @滚回功率坐放宽 @redapple0204 
 诺基亚Lumia 1520
我装的是原版Vista with SP2 64位旗舰版[太开心] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/95cdd1013af33a87f312a089ce5c10385243b51f.jpg)
***
 诺基亚Lumia 1520
更新完毕了[花心] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/a00afe24bc315c6063cfc87c85b1cb134b5477c4.jpg)
***
 诺基亚Lumia 1520
我再检查一次更新试试，应该不会再有更新了吧[哈哈] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/dedb600928381f303f942e3aa1014c086c06f08e.jpg)
***
 诺基亚Lumia 1520
度娘怎么吞我帖子
 诺基亚Lumia 1520
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/1b41aeeb15ce36d3db542ba332f33a87eb50b1c2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/891e72cf36d3d539b96da7503287e950372ab0c2.jpg)
***
 诺基亚Lumia 1520
更新：这六个补丁编号有变化，就是第一个补丁编号KB3177725，现在已变更成KB3185911，如下图所示，因为我的大V检查九月更新第一次报错，第二次再继续检查更新，检查了一晚上都无法检查到，今天上午装了KB3185911，就能检查到九月更新了，详情参见我那个《Vista开装九月更新》的帖子[太开心] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/cae7042662d0f7031afa544b00fa513d2497c5d7.jpg)
***
 诺基亚Lumia 1520
新的六个补丁的64位的百度网盘分享（也就是KB3185911取代了KB3177725）[哈哈]链接：![](http://pan.baidu.com/s/1dFdrRpf 密码：sqju
 诺基亚Lumia 1520
现在解决不能检查到更新的六个补丁编号已经变为KB3078601、KB3109094、KB3164033、KB3183431、KB3185911、KB3191203，望各位悉知
今天微软推送了11月更新，![](http://wu.krelay.de/en/也更新了，解决Vista不能检查到更新的补丁编号已经变更为KB3198234、KB3194371、KB3203859这三个，敬请各位悉知[滑稽]
晚上在去图书馆之前打开了大V虚拟机，手动装上了KB3198234、KB3194371、KB3203859这三枚补丁，然后点击检查更新，然后就离开寝室了[滑稽]回来后发现大V已经检查到巨硬推送的11月更新了[太开心] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/8de5158a4710b912b0076131cbfdfc0390452234.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/792fd1fc5266d01684df09e79f2bd40737fa3534.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/c7b08cf91a4c510fd071422f6959252dd52aa547.jpg)
今天微软推送了12月月度更新，解决不能检查到更新的补丁编号又变了，如下图所示：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/e9f52b096e061d959ae6e33172f40ad163d9ca09.jpg)
昨天晚上10点多先装上12月的这三个补丁KB3194371、KB3198234、KB3203859后就去检查更新，检查了两个多小时没检查到更新，后来电脑没电了就关机了（学校晚上断电），然后今天中午12点再检查更新，然后就出去了，现在刚回来，看到Vista已经成功检查到MS推送的12月更新了，16个重要更新[太开心]如下图所示，说是16：16检查到更新的，嗯，检查了四个小时[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/7b33f83cf8dcd10027a1ba2e7b8b4710b8122ff1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/0bc2cbae2edda3cc2efcfa2f08e93901203f929e.jpg)
今天微软推送了1月更新，![](http://wu.krelay.de/en/ 这个网站也更新了，解决Vista不能检查到更新的补丁编号已经变更为KB3216775[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/5b21ca6fddc451da8fb622b0bffd5266d1163219.jpg)
我装上KB3216775，然后检查更新很快就检查到两个更新[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/5ee3ed83b9014a90dbca5be6a0773912b11beeee.jpg)
全新安装的原版Vista with SP2，现在要先装了IE9，然后再装了Windows Update Agent 7.6.7600.256，然后再装11个更新，然后就去检查更新了，就能检查到更新了，我在笔记本上装了Vista，亲测过了半个小时就顺利检查到更新了，感谢@VistaWithSP2，他翻译了![](http://wu.krelay.de/en/ 这个网站上的说明，说要安装此网站提供的2016年9月及以后所有大V的更新，然后再检查更新，这样才能检查到更新，果然是这样的！（向各位抱歉之前我没认真看这个网站上的说明，给有些吧友带来了困扰）我下载了9月及以后的更新并且剔除了被新更新替换的旧更新后，共有11个更新，我先装了IE9，然后再装了Windows Update Agent 7.6.7600.256，然后再装了这11个更新，然后就去检查更新了，过了半个小时就顺利检查到更新了[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/ef371e300a55b319bb904be84aa98226cefc1733.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/fcc53b6134a85edf7f6937be40540923df5475b8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/5b21ca6fddc451daad8ac476bffd5266d1163220.jpg)
刚刚在虚拟机里面装了Vista的服务器版msdn原版Windows Server 2008 Datacenter with SP2，用64楼的方法成功使Server 2008检查到更新了[太开心]检查更新中途报错一次，然后再点检查更新，整个检查更新过程总计耗时约50分钟，现在正在下载更新了，如图所示
我是71楼的图[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/b6f7148ca9773912a9998fb7f1198618347ae29a.jpg)
还是截图看着舒服[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4778342730/f3ed8cc5b74543a98d0c8f1a17178a82bb0114c1.jpg)
