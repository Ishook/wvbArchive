很抱歉OS X Public Beta有一些问题需要解决，目前暂时更不了[勉强]
所以我干脆新开一贴，单独来讲讲这个版本[滑稽]
Rhapsody其实是OS X的一个测试版本，使用了NeXT STEP的内核，但是换上了苹果自家的OS 9的桌面。
但这不是重点，重要的是，Rhapsody是苹果第一个x86的Mac OS版本！[真棒]这也就意味着我们可以在VMware上安装他[滑稽]
***
二楼固有领土[滑稽]
先@一波人 
@焊锡补牙 @happymax1212 @Longhorn3683 @r216571tyq
***
在安装之前，你需要：
1.Rhapsody安装/驱动软盘、光盘（废话
2.VMware OpenSTEP驱动盘
两者链接如下：
驱动盘：www[喷]mediafire[喷]com/file/fu1s2719bdk1esf/openstep-vmware.iso
安装盘：winworldpc[喷]com/download/41c3b8c3-8ae2-82ac-18c3-9a11c3a4efbf
***
我个人推荐使用VMware Fusion进行安装，因为Workstation/Player貌似有Bug[狂汗]
下面新建虚拟机，类型选择MS-DOS[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/65d9b32b2834349bf9b0f243c2ea15ce34d3bebc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/94de4f35349b033ba03e601c1ece36d3d739bdbc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/68c0539a033b5bb53561bc383dd3d539b400bcbc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/746f643a5bb5c9eae8459f25de39b60038f3b3bc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/43cf3cb4c9ea15cec8587ccfbd003af33887b2bc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/1b41aeeb15ce36d32ab21ff631f33a87eb50b1bc.jpg)
这是推荐配置，特别注意光驱和硬盘均为IDE，不然后面驱动不好弄[滑稽]
***
插盘开机后，语言选英文，一路跟着过去[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/91f4dda0cd11728b2d3e12e4c3fcc3cec1fd2cde.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/fa55aa10728b4710d23c630ac8cec3fdfe0323de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/8de5158a4710b912a4d26838c8fdfc03904522de.jpg)
到这里，插入驱动软盘[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/327f2011b912c8fcaee0680bf7039245d48821de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/07e4de13c8fcc3ceadd357f59945d688d63f20de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/f9e6affdc3cec3fd932d39b3dd88d43f859427de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/8808a4cfc3fdfc03e26b7d7edf3f8794a6c226de.jpg)
按两下7并回车之后，在这里会找到Intel PIIX PCI EIDE/ATAPI Device Controller，这便是我们的光驱驱动。所以这个时候，按4并回车[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/191a5a6c55fbb2fb9a92c1d4444a20a44423dcb5.jpg)
这个时候再按下1并回车，便可以进入安装程序[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/7d9932fab2fb4316b7a6e3bc2ba446230bf7d3b5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/150fd5fa43166d2294ce8c524d2309f79252d2b5.jpg)
下面我们继续[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/9a402dec2e738bd400d72af7aa8b87d6257ff97c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/0a1949728bd4b31c33ca0c7d8cd6277f9c2ff87c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/6e87ecd5b31c870114402a202c7f9e2f0508ff7c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/cb20d41d8701a18b311d8a89952f07082a38fe7c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/f3e8e000a18b87d690b433d90c0828381d30fd7c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/c7f5c68a87d6277f26e4aafe23381f30eb24fc7c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/e17fe0d7277f9e2fbec385ce1430e924ba99f37c.jpg)
一路按1回车，到这里便可以拔软盘重启了[滑稽]
当然，我们的其他驱动问题还没有解决，所以还没完[滑稽]
待楼主先去吔个饭，稍后回来[勉强]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/2b9791256b600c3363c45f0e114c510fdbf9a1a9.jpg)
重启后，我们需要首先阻断Rhapsody的自动安装，换上先前下好的VMware OpenSTEP驱动盘，然后在boot选项中输入“-s”（不带引号），进入Rhapsody的单用户模式。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/b6d00c610c3387440e78aeba5a0fd9f9d52aa0a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/2b946b328744ebf8fccce5f9d2f9d72a6259a7a9.jpg)
看到命令行出现#时，就说明启动完成了[滑稽]
没错，你没猜错，我们正是要用这个命令行拷贝OpenSTEP驱动盘上的驱动[滑稽]
***
这里我先把拷贝的命令放在这里，供各位愉快参考[滑稽]
````shell
# 检查且装载文件系统
fsck
mount -w /
# 为CD-ROM创建挂载点（名称可以自定义）
mkdir /cd-drivers
# 为拷贝来的驱动程序创建文件夹（可以自定义）
mkdir /drivers-tmp
# 挂载CD-ROM
mount -t cd9660 /dev/sd0a /cd-drivers
# 拷贝驱动程序
cp /cd-drivers/next_drivers/* /drivers-tmp
# 解压缩驱动程序
cd /drivers-tmp
gnutar xf vmmouse_1_1_i_bs.tar
gnutar xf vmwarefb_config_1_1_1.tar
# 移动驱动程序到系统驱动文件夹下
mv /drivers-tmp/VMWareFB.config /private/Devices
mv /drivers-tmp/VMMouse/VMMouse.config /private/Devices
# 重启系统
reboot
````
这里除了“#”之外便是命令，执行之后，便可以继续安装[滑稽]
楼下上图[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/07e4de13c8fcc3cea1f44bf59945d688d53f2031.jpg)
就是这样没报错的话，那就说明成功了[滑稽]
***
重启之后，不要急着高兴就让Rhapsody自动启动了，这个时候我们还得把安装盘换回去，才能够愉快玩耍[滑稽]
按任意键阻断自动启动，换上Rhapsody安装光盘，再进行引导。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/fefd0c62f6246b60d26f3eb2e0f81a4c530fa28d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/2b9791256b600c335818520e114c510fdbf9a18d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/b6d00c610c3387440ba4a3ba5a0fd9f9d52aa08d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/2b946b328744ebf8fb10e8f9d2f9d72a6259a78d.jpg)
启动界面据说很像NeXT STEP，不过这里已经换上了苹果的标志[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/e1b0ca355982b2b7d54cb5023aadcbef74099b1e.jpg)
然后便启动到了驱动选择这里[滑稽]接下来，我们要挨个选择刚才拷贝进来的驱动[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/edc03e83b2b7d0a20a1a885bc0ef760949369a1e.jpg)
就像这样[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/1976d5b6d0a20cf4364372197d094b36aeaf991e.jpg)
对于鼠标，你需要先点一下主菜单上的Add，再选择VMware的鼠标驱动。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/f243b7a30cf431adc301cfff4036acaf2cdd981e.jpg)
最后，配置成这样，就可以Save了[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/8861b642ad4bd113f14638f451afa40f49fb0566.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/91b7ca4ad11373f001b4e059af0f4bfbf9ed0466.jpg)
下面跟着向导进行安装即可[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/ca76de004a90f603eafe12813212b31bb251eda4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/f9f52d91f603738d330482e4b81bb051fa19eca4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/0a649102738da977a26108edbb51f8198418e3a4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/b6f7148ca97739122f680ba7f3198618347ae2a4.jpg)
点击重启，然后等待其自动启动，彩色就来了[滑稽] [大拇指]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/a529801090ef76c6ba3c73ed9616fdfaad51677b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/a7e5f7ee76c6a7efd0c820e0f6faaf51f1de667b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/d01b11c7a7efce1b82c5400ca451f3deb68f657b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/3632c0eece1b9d16dd2912a7f8deb48f8e54647b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/e71ba91a9d16fdfa8e824e28bf8f8c5496ee7b7b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/8eeffa17fdfaaf51d10d0979875494eef21f7a7b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/dde29afbaf51f3de975c31a29feef01f3829797b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/bd0ec850f3deb48fa8872918fb1f3a292ff5787b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/efa594dfb48f8c54b13d4de931292df5e2fe7f7b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/b32ad38e8c5494eed6cc87df26f5e0fe9b257e7b.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/891e72cf36d3d5395d2784053187e950372ab0d0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/553a51d2d539b600d6d48471e250352ac45cb7d0.jpg)
再次重启，安装便完成了[滑稽] [玫瑰]
***
补：鼠标驱动还需要进行这样的设置：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/4ab2951ebe096b63270aaf9607338744e9f8acdf.jpg)
仅剩VMware鼠标驱动后，选择他，点击右边的“Expert...”，
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/b2ebd9086b63f624b94ec8c58c44ebf8184ca3df.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/fefd0c62f6246b60df1d43b2e0f81a4c530fa2df.jpg)
下滑到底，应该会看到一个X Size和Y Size，
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/2b9791256b600c33536a2f0e114c510fdbf9a1df.jpg)
像这样，把前者改为1024，后者改为768即可。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/3379ce763912b31b202830ef8d18367ad8b4e1a2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/e9835e13b31bb05169604eee3d7adab448ede0a2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/79e6d41ab051f8191461fe8cd1b44aed2c73e7a2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/f3efd750f8198618a503124241ed2e7389d4e6a2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/f0a59f188618367a4ecd821b25738bd4b11ce5a2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/b8ede119367adab4df94e68580d4b31c8501e4a2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5531461445/c6ec517bdab44aedb80a4322b81c8701a38bfba2.jpg)
可以看到预装的应用非常少，但苹果已经接着NeXT STEP的应用框架搞出了一堆后缀为app的应用[真棒]
***
到此本贴完结撒花[滑稽] [玫瑰]后面有时间我会弄个视频丢到B站上的[滑稽]