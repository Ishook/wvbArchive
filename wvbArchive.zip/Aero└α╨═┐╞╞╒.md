aero 细分类型
4039_4042
4066_4074
5048
5112_5219
5231_5270
6000_6469
6519_6801
6936_7068
7077
7100_7601
7850
7927_7963
7973
8056
8102_8161
8250_8331
8400_843x
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/3379ce763912b31be63dfd818e18367adbb4e13e.jpg)
4039 4042
特征:家庭普通版的玻璃化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/8de5158a4710b912dcdfc556cbfdfc0393452274.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/c722407e9e2f07084dc51aa8e124b899ab01f24f.jpg)
2.4066 4074
特征:支持任务栏，侧边栏透明化，任务栏好评，窗口透明差评，像沙纸似的，按钮复古3.1
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/7a738e51352ac65cbb7454dbf3f2b21192138a1e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/a9a4522bc65c1038ff0ffc6aba119313b17e891e.jpg)
3.5048
由于重组，只有窗口透明，有两种真aero，一种假aero。其中一个成为RTM窗口。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/fccad63433fa828b5f93a14bf51f4134950a5adf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/c2d2a8fd1e178a82f28f4308fe03738dab77e8d8.jpg)
4.5112 5219
aero效果秒杀4074，并且5219开始支持任务栏透明化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/97de0758252dd42ab2d13e030b3b5bb5cbeab8b7.jpg)
6.vista 正式版
特征:阳光效果更明显，关闭按钮默认是红色的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/65ebf2cbd1c8a786c98b73a66f09c93d72cf50ed.jpg)
7.6519_6801
特征:各种鬼畜的发光效果 6730发光最明显
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/11c9419659ee3d6d2c2cbf634b166d224d4adea1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/66633eef3d6d55fbc82c4e8e65224f4a22a4dda1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/191a5a6c55fbb2fb38c160ba474a20a44423dca1.jpg)
8.6936
按钮变大了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/7d9932fab2fb4316168d41d228a446230bf7d3f9.jpg)
9.6956_7068
迎来了超级任务栏
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/dde29afbaf51f3de608083cc9ceef01f3b297959.jpg)
10.7077
阳光效果几乎消失【这是aero最大的浩劫】，任务栏按钮四周泛白
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/e1b0ca355982b2b761b21c6c39adcbef77099b5a.jpg)
11.7100_7601
任务栏按钮效果和7077不一样，史上最丑的aero！！！[吐]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/4e007cd4ad6eddc4484c915331dbb6fd506633e7.jpg)
12.7850
增大按钮并修改了泛白效果，而且阳光效果回归
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/e0186ffb513d26972af82cf55dfbb2fb4216d860.jpg)
13.7927_7963
继续修改泛白效果
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/5ee3ed83b9014a90b3be6215a1773912b11bee8f.jpg)
14.7973
泛白效果最浓烈的版本
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/f9e6affdc3cec3fdf0f383ddde88d43f859427b9.jpg)
15.8056
窗口细节全部直角，开始扁平，aero效果除8400和6000全部秒杀
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/f2e5f412b07eca80c2b01e4f992397dda34483d2.jpg)
16.DP阶段(8102 8148 8161)
开始扁平化，而且如果你妆的好，可以并不亚于4074 5112
如下图
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/09a06e22dd54564e7342c591bbde9c82d0584f6c.jpg)
18.CP阶段
由于继续扁平化，透明度最低的阶段
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/e772ae167f3e67093288645733c79f3dfadc5587.jpg)
19.RP阶段
完美结合了win8特征，扁平化的玻璃
非常美丽，可惜夭折
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765650054/973e1cca0a46f21f3cdc7ffbfe246b600e33aea7.jpg)
aero美观排名
6000>8148=8400=8056=5112>5259=6801=7850>4074>7955>7973>5048＞7077>4042>7600>8250=8102
