谁能告诉我这里如何修改，就差这个部分就能完成了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/3fca0008c93d70cf23d16831f2dcd100bba12bdc.jpg)
tmd网上又没有关于basic主题修改的教程，只有aero主题修改的教程。我呵呵
***
@史莱姆魔皇
效果图：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/c7b08cf91a4c510f5899cb276a59252dd52aa5a7.jpg)
地址: s/1o8uMtC2
提取码: v7d6
***
@史莱姆魔皇 @lsqsjz @喜羊羊441 @Longhorn4093 @happymax1212 
***
搭配@lsqsjz 发的vista十周年帖子里面我在最后面的楼层发的主题，效果更加好。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/4aa1d418ebc4b7456dfa9d2bc5fc1e178b821591.jpg)
@史莱姆魔皇 IE11目前不知道怎么解决这种贴图BUG。 其实win8的仿win10主题，IE11也是会有贴图错误问题。
别的效果图：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/91f4dda0cd11728bb4fe9a1fc2fcc3cec2fd2c35.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/e17fe0d7277f9e2f443e0c351530e924b999f3fd.jpg)
更新：
basic主题窗口配色修改成跟vista beta2主题窗口颜色一样；
任务栏缩略图窗口颜色修改成主窗口一样。
***
效果图：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/112ee6ca39dbb6fdfe59af180324ab18962b3787.jpg)
***
地址: 
s/1misiB9Y 
***
提取码: 
3g9b
***
@史莱姆魔皇 @lsqsjz @喜羊羊441 @Longhorn4093 @happymax1212 @孙必林 @cghvbnv22
跟外国的Vista Beta 2 basic主题比较：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/990db02b6059252dc81aad3a3e9b033b5ab5b9f0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/5ab8360ed9f9d72a7a69a023de2a2834359bbbf0.jpg)
***
@史莱姆魔皇 @lsqsjz @喜羊羊441 @Longhorn4093 @happymax1212
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/fa55aa10728b4710ccdb6af2c9cec3fdfd032309.jpg)
***
@lsqsjz 红框选中的就是
![](http://www.deviantart.com/art/Vista-Beta-1-for-Windows-7-526223562
***
@lsqsjz 你试试这个vista beta1 主题，win7的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5082716853/9da0314f9258d1094c696a8cdb58ccbf6d814d78.jpg)
@lsqsjz 这个外国的vista beta1 基础主题 跟 win7 vista beta 2 基础主题一样，看清楚了没。
