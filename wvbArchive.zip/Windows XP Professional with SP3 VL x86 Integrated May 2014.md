此映像包含 2014-5-13 及之前所有更新，详请可在下载HotfixList.html查看整合的更新及软体更新
● Adobe Flash Player v13.0.0.214 ActiveX control
●DriverPack Chipset 12.09 - 晶片组驱动程式支缓
●DriverPack Mass Storage 12.09 - SATA/AHCI/SCSI/RAID驱动程式支缓
●Microsoft.NET Framework 1.1 SP1 (v1.1.4322.2503) - July 2013
●Microsoft.NET Framework 3.5 SP1 family (v2.0.50727.3659+v3.2.30729.4058.3+v3.5.30729.4056.3 - May 2014 update)
●Microsoft.NET Framework 4.0 v4.0.30319.1023 (May 2014 update)
●DirectX for WinXP Post-SP3 June 2010 Update (including DirectX for Managed Code for .NET 1.x)
●Microsoft Silverlight v5.1.30214.0
●Windows Management Framework Core - WinMFc (includes Powershell v2 and PowershellISE)
●MSXML 4.0 SP3
●Internet Explorer 8
●Windows Media Player 11

***
感谢@jyjs3993 的搬运，说明：此资源是转的。
***
File Name: zh-hk_windows_xp_professional_with_service_pack_3_x86_vl_integrated_may_2014.iso
Languages: Chinese - Hong Kong SAR
Size: 850 MB (891,981,824 bytes)
CRC32: A08234F5
MD5: 3553D243CC34C7D3A45B828A28E59507
SHA-1: BB393D624CD09CFAD20295CD05A3B5265EB6D9B4
***
File Name: zh-tw_windows_xp_professional_with_service_pack_3_x86_vl_integrated_may_2014.iso
Languages: Chinese - Taiwan
Size: 850 MB (892,006,400 bytes)
CRC32: 6B2FC748
MD5: ED1590BB8209638A6080C39518A245BD
SHA-1: B62B83DB57E9F96DBBBFA3E981F6AFC876D86D5C
***
File Name: zh-hans_windows_xp_professional_with_service_pack_3_x86_vl_integrated_may_2014.iso
Languages: Chinese - Simplified
Size: 847 MB (888,834,048 bytes)
CRC32: 896515D9
MD5: 23CE11086A13A5F774222D7A7D2C1A00
SHA-1: 3160C24B3D6B2A87A1B2E153FCCEADCB624801AE
***
@bingohuanj 申精
@jyjs3993
***
测试windows update,
高优先级有2个，
Windows 恶意软件删除工具 - 2014 年 10 月 (KB890830)
Microsoft Silverlight 更新 (KB2977218)上次发布日期: 2014/7/23
软件，可选有7个
Microsoft .NET Framework 3.5 Service Pack 1 (KB951847) x86 语言包
Microsoft .NET Framework 3.0： x86 语言包 (KB928416)
Microsoft .NET Framework 2.0 语言包：x86 (KB829019)
必应 Bing 输入法 1.3
设备健康助手 1.0 (KB2938861)
Feature Pack - Microsoft Security Essentials - 4.4.304.0 (KB2902907)
Windows Live 软件包
***
基本上XP的补丁打全了，恶意删除工具没啥用处，Silverlight都没人用
NET Framework语言包不装也可以运行net程序，只是报错提示是英文而已。
病输入法，设备健康助手,MSE自己选装
windows live貌似MS自己都已经放弃他了
***
评测结束
***
结论，此ISO值得收藏。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5292983183/22249002918fa0ecb7f491cb2c9759ee3c6ddb3f.jpg )
