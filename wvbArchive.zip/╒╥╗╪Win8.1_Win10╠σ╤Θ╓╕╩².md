一楼防吞，刚刚帖子突然被度娘吞了[喷][不高兴]
老是说我的内容不合法，还是用截图发吧[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4895254339/dde29afbaf51f3de6b1a8f609deef01f3b29797b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4895254339/f6093567d016092487d5941fdd0735fae7cd3432.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4895254339/0253be32c895d14394b3d2277af0820258af07e5.jpg)
下面就是附件了：链接：http:[滑稽]//pan[滑稽].baidu.com/s/1pLpnzYF 密码：i5h0
8楼又被度娘吞了[喷]
