1l祭天
系统说明：本系统以MSDN我告诉你的镜像为母盘制作，安装了自SP2发布以来到2017年的所有更新（感谢@jyjs3993 的整理）
系统安装组件如下：
（以下软件来自官网）
7-zip 18.06
Flash Player 32
K-lite Mega Code Pack
（以下软件来自睿派克论坛）
CCleaner
ACDSEE 5.0 精简增强版
WinRAR 5.5美化破解版
千千静听7.04美化增强版
（以下软件来自独木成林）
搜狗输入法传统版7.2h
（以下组件为自己整理）
XP官方主题
IE6、IE7独立版（IE6独立版解决国企网站问题）
（以下组件由@jyjs3993 整理）
DX9
NetFx2.0 3.0 3.5 4.0及其语言包更新
VC运行库2005-2017 Visual F# Visual J#
MSXML 4.0 6.0
本系统安装说明：将系统映象刻录至DVD或USB安装即可。注意安装完后修复引导！！！
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/7a738e51352ac65c8e4c5ca7f6f2b21191138a8a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/a9a4522bc65c1038cc37f416bf119313b27e898a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/75dea15d103853435b86bdf59e13b07ec880888a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/86a877395343fbf213659cf7bd7eca8067388f8a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/50cc3442fbf2b2113167bf9ac78065380ed78e8a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/13b79cf3b2119313130ac56468380cd793238d8a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/bb06d5109313b07e6ef46adc01d7912395dd8c8a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/f2e5f412b07eca80c04c03339c2397dda344838a.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/f20f24176d224f4a566f56c704f790529a22d161.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/03e20a234f4a20a431e819139d529822700ed061.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/2dd6284b20a44623713c80b69522720e0ef3d761.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/0fbe47a5462309f7e99988c67f0e0cf3d5cad661.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/6050212209f79052e2e962ea01f3d7ca79cbd561.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/06d76ef69052982209c51c17daca7bcb0846d461.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/4903f7539822720e7038c72e76cb0a46f01fab61.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/d0a6ff23720e0cf3aa016b2f0746f21fbc09aa61.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/d8d6150f0cf3d7ca05001aa2ff1fbe096963a961.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/32fa6bf2d7ca7bcb758de2fbb3096b63f424a861.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/e71ba91a9d16fdfa6412e23ab98f8c5496ee7bd9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/8eeffa17fdfaaf513f9da56b815494eef21f7ad9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/dde29afbaf51f3de79cc9db099eef01f382979d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/bd0ec850f3deb48f4217850afd1f3a292ff578d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/efa594dfb48f8c545bade1fb37292df5e2fe7fd9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/b32ad38e8c5494ee205c2bcd20f5e0fe9b257ed9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/f47beb5594eef01feb6a3c11edfe9925be317dd9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/cca0f3eff01f3a29ffb6f11a9425bc315e607cd9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/d41a971e3a292df533bd88c1b1315c6036a873d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/b0eb5d282df5e0fe4d66add5516034a85cdf72d9.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/1976d5b6d0a20cf49ce1da0b7b094b36aeaf99e2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/f243b7a30cf431ad65a367ed4636acaf2cdd98e2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/90566bf531adcbefd9455ad2a1af2edda1cc9fe2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/4c0056accbef7609fb7abd4b23dda3cc7ed99ee2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/7159acee76094b361de33f39aecc7cd98f109de2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/8b1b11084b36acaf9c91b22871d98d1003e99ce2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/36fd2c37acaf2edd10806d3d801001e93b0193e2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/0bc2cbae2edda3ccc8959cf40ce93901233f92e2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/ec5b49dca3cc7cd9385c100d3401213fba0e91e2.jpg)
***
系统修改：关闭关机追踪程序，添加了一个2k的用户账户，开机无需按CAD等等……
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/b0eb5d282df5e0fe4de7add5516034a85cdf7258.jpg)
Windows修复引导方法：
安装完成后你会看到
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/edbfb61273f082027285b0eb46fbfbeda9641bc7.jpg)
点“确定”
你会回到此处
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/91e714f182025aaf8d255f1ff6edab64014f1ac7.jpg)
点修复计算机，然后点击方框里的空白处，点下一步，然后点命令提示符
输入cd recovery
startrep
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/3304e5035aafa40f61d1ef09a664034f7af019c7.jpg)
点自动修复，然后重启即可
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6024055263/c2f63daea40f4bfbd0c7bf800e4f78f0f53618c7.jpg)
***