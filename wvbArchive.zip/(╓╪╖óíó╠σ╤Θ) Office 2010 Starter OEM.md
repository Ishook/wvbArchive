（上次的贴自删了，链接放错了）
最近我在玩 Thinkpad Windows 7 的恢复盘，恢复完后发现系统自带 Office 2010 Starter 我就把他提取了出来，顺便评测一下
***
2l召唤
@2006bt @vistawithsp2 @happymax1212 @呵呵韩国观光饭 @bingohuanj 
（顺便说一下，我想申请wvb的小吧主，所以我要多多发帖，提供资源，少潜水）
@孙必林
***
先安装，安装时一定要把uac关掉，不然无法安装
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/fa55aa10728b4710cdeb69f0cfcec3fdfd03233f.jpg)
***
安装完后开始菜单多出来了东西
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/70ba421e95cad1c8c5e06c1b733e6709c83d51ac.jpg)
打开
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/c2f63daea40f4bfb60280e680f4f78f0f6361803.jpg)
***
使用starter
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/833aa4fcfc039245a04471338b94a4c27c1e250a.jpg)
要注意一点，这个office会创建盘符为r的虚拟盘（存放office本体），所以r盘符不能占用
占用后
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/5d616d7a02087bf4c1dcc4d5fed3572c10dfcfd4.jpg)
***
美如画
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/f3ed8cc5b74543a9243369f012178a82b80114d3.jpg)
很快就安装完了，进入word看一下
word
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/ca76de004a90f603de640f7b3512b31bb151ed28.jpg)
excel
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/0f36b2638535e5ddc80037e37ac6a7efcf1b62d7.jpg)
***
右边的入门栏可以用第三方软件关掉，叫office ad remover
去除后效果
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/20ad422cd42a2834cec6a43757b5c9ea14cebfa4.jpg)

日常使用没问题
***
但是[阴险][滑稽]，本次评测的重点不在这里。看过来
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/cde466e83901213f9cdedce058e736d12e2e9516.jpg)
office to go？？？？？？？[疑问]这就很interesting了。打开看看
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/3b006dd062d9f2d39a9cb6d3a5ec8a136227cc77.jpg)
点击开始
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/5ee3ed83b9014a905db0d481a5773912b21bee72.jpg)
***
然后，进度条不动。我等了一个小时，没反应。但是，lz不是轻言放弃的人。[滑稽]
我问我的好基友要来一个破解版的l[阴险]an[怒]t[狂汗]ern，ok，进度条动了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/bcf7f544d688d43ff2bd0cce711ed21b0ff43bef.jpg)
***
终于，lz创建好了优盘，创建后优盘根目录是这样的。。。。。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/c7f5c68a87d6277f22ebaf0424381f30e824fc03.jpg)

忽略officeadremover和打开保险箱。vbe 这些是我后来加上去的（打广告：office2010 starter将会加入WYY OS 敬请期待[滑稽]）
***
打开office.exe出现
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/c13f5edab6fd52665137a028a718972bd50736e7.jpg)
（ui不错）
***
分别打开
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/91b7ca4ad11373f01111f3a3a80f4bfbfaed04d1.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/c2f63daea40f4bfb6c9102680f4f78f0f63618ba.jpg)
（没啥两样）
主菜单右下角还有快速修复功能，好评
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/6e87ecd5b31c8701191b2eda2b7f9e2f0608ff57.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/7add4af4e0fe9925828cf56c38a85edf8cb1717b.jpg)
***
最后，发上office 2010 starter to go 链接
直接解压到u盘根目录就可使用链接: https://pan.baidu.com/s/1pMlnDDh 密码: pc2c
***
为什么老是没人[泪][泪][不高兴][不高兴]单机版贴吧[鄙视][喷]
Windows8/8.1使用时要先安装一个更新，不然会提示不兼容。更新等一会放出
安装程序链接oem office 2010 starter.zip

https://pan.baidu.com/s/1smcweWt 密码：4093
***
还有，@BingOHuanJ 我想申请小吧主，还要做什么事情[疑问]
office 2007 click to run 即将提取成功
挖坟补充一下（望吧务破例别封）office 2010 starter已经被微软抛弃，已经无法再线下载、更新了（包括在线安装）。office to go 也没法下载了。
还有建议吧务加个精，毕竟已经是绝版资源了
我404
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/c760c3c37d1ed21bb2d57f54a06eddc450da3f5c.jpg)
我又找到一个office家庭学生版c2r ，但是是英文版
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5554756235/b8ede119367adab4a0065ff286d4b31c8501e4a7.jpg)
@bullaird office starter无64位，w10理论上打了补丁就可以运行，你成功了吗