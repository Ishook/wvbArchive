High Sierra with JPEG zipped镇楼[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ca76de004a90f603fc8a6cae3212b31bb151ed13.jpg)
***
二楼固有领土[滑稽]
所以我先放一下更新列表吧[滑稽]
由于模拟器原因，我将先更Classic系列：
Macintosh Guided Tour
System 1.1 with Finder 1.1g
System 2.0 with Finder 4.2
System 3.0 with Finder 5.1(added System Tools 1.0 for Macintosh Plus)
System 3.2 with Finder 5.3(added Hard Disk support)
System 4.1 with Finder 5.5(added System Tools 2.0.1)
System 6.0.8
System 7.0.1
System 7.5.5(upgrade from System 7.5.3)
Mac OS 7.6.1
Mac OS 8.1
Mac OS 8.6
Mac OS 9.0.4
***
然后是Special列表[滑稽]
MacWrite
MacPaint
System 6.0.7 SC
System 7.5.3 SC
Mac OS 8.5.1 SC
Mac OS 9.0.4 SC
***
目前计划就这么多了，下面先更Macintosh Guided Tour吧[滑稽]
Macintosh Guided Tour是目前已知最早的System Software公共发布版本。本质上，这是一个教程，为了“教化”一下那些脑子还停留在DOS思维的人[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d3e7d77fca806538e3b059fa9cdda144af3482f3.jpg) 
这个教程是随最早的Macintosh 128k一起发布的，下面我们开机吧[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4aa1d418ebc4b745c7344affc4fc1e17888215a8.jpg) 
***
打开Mini vMac，插盘，就可以看到楼上那一幕[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3ed8cc5b74543a907bb072515178a82bb0114a8.jpg)
***
这里面有很多教程，不过任意点开就会出现下图的070B错误，原因未知。如果继续，一定几率下Mini vMac会闪退。就算打开，也会很卡。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/79f5463eb80e7bec507efc08242eb93899506bac.jpg) 
这是对桌面的简介。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/61cbdf0f7bec54e73348e5f7b2389b504dc26aac.jpg) 
这里是一个鼠标教程，类似于你们在Windows 3.2里面见到的那个[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f8fa1ced54e736d129b773e190504fc2d76269ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b1833e636d12f2ebea1518944c2d562873568ac.jpg) 
不过，除了鼠标教程能正常打开之外，其他的东西都会爆070B错误，然后是动画，完了之后就宕机。
下面我们看看Finder吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/50cc3442fbf2b2117b847ba7c18065380ed78ea3.jpg) 
经典的山水画[滑稽]
事实上，自System 1.1g之后就再也没出现过这种东西。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/13b79cf3b211931359e901596e380cd793238da3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bb06d5109313b07e2017aee107d7912395dd8ca3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f2e5f412b07eca808eafc70e9a2397dda34483a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d3e7d77fca806538e0405afa9cdda144af3482a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f08aad8165380cd77cb45c04aa44ad345b8281a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8a7402390cd79123794a6a9da6345982b0b780a3.jpg) 
所有的应用[滑稽]真的非常简陋 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/25cc6bd6912397dd4ed366ed5282b2b7d2a287a3.jpg) 
盘里的所有程序，仍然没有什么特别的。
***
楼主回来啦[滑稽]
刚去游了下泳[勉强]
***
下面是System Software 1.1[滑稽]
这款SSW发布于1984年4月，实质上是1.0的小幅升级+补丁版本，随1984年4月及以后的Macintosh 128k一同销售。这也是一个完整且稳定的System Software，而非教程。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2c75e70b19d8bc3eb7f1c523898ba61eaad34557.jpg) 
***
插盘开机后可以看到，界面的整体改观并不大，下面我们看看详细功能[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f6f45df23a87e95081773f851b385343f9f2b4e9.jpg) 
经典的山水画[滑稽]
不过这次加入了太阳和山脉[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7a075d86e950352a7301e9e15843fbf2b0118be9.jpg) 
这次的Scrapbook有了填充内容，不像0.85还在招租[滑稽] [弱] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7a738e51352ac65ca665aa9af0f2b21191138ae9.jpg) 
新增！作为完整功能一部分的时钟
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a9a4522bc65c1038e41e022bb9119313b27e89e9.jpg) 
同样，Note Pad也有了内容填充，我们可以从中得知这里一共有8页[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/75dea15d1038534343af4bc89813b07ec88088e9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/86a877395343fbf20b4c6acabb7eca8067388fe9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/50cc3442fbf2b211294e49a7c18065380ed78ee9.jpg) 
计算器，模拟键盘和控制面板仍然没变。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/13b79cf3b21193130b2333596e380cd793238de9.jpg) 
新增！难到爆炸的拼图（
因为这货只有一个空可以移动，所以真的很烧脑[滑稽] [弱]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bb06d5109313b07e76dd9ce107d7912395dd8ce9.jpg) 
再看一下盘里面，就能看到第一版的Disk Copy[滑稽]
这东西直到后面提供了所有Classic Mac OS需要的启动虚拟磁盘文件，意义重大[滑稽]
这里还多了一个很迷的空文件夹，以及一个字体册（见下图）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f2e5f412b07eca80d865f50e9a2397dda34483e9.jpg) 
这里的字体并不是很多，并且锯齿感人[喷]
***
Special！——MacWrite&MacPaint
这是两个充分展示图形化优越性的软件，前者是WYSIWYP（What You See Is What You Print）的文字处理软件，后者则是类似于M$Paint的画图软件，两者都是随Macintosh 128k一起销售的。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/23d305d1f703918fdc6809205a3d26975beec490.jpg) 
***
我需要处理一下从Macintosh Garden上搬来的MacPaint和MacWrite[阴险]
因为这些东西需要一个个封在dsk里[阴险] [心碎]
***
lz尝试了很多次把MacPaint和MacWrite丢进一个MFS磁盘里，不过我失败了[不高兴]
因为这么多Copy&Paste导致System 1.1并不能识别我丢进去的是一个应用程序[阴险]
所以......你们还要看MacPaint和MacWrite吗？要的话我就把新一点的翻出来，不要的话我继续System 2.0[滑稽]
楼下回复[滑稽]
***
我还是先更System 2.0吧[勉强]后面我会把MacWrite和MacPaint补上，放在相应的系统版本中
System 2.0也是一款小幅度升级版本，添加了对Apple LaserWriter的滋磁。
日期上来看（1985）确实如此[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/06d76ef690529822329b4129dcca7bcb0846d4a1.jpg) 
我可以说基本没变化吗......
那么我们先来安装Finder 4.2吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/65ebf2cbd1c8a78675d432e46c09c93d72cf5057.jpg) 
感谢Mini vMac能让我同时插进去两张盘[滑稽] [大拇指]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1a5bc30e4bfbfbed5fd64d9573f0f736adc31f46.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e4fb2cfafbedab64f6fd362afc36afc37b311e46.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0b0f9cecab64034f8e42b9eca4c3793108551d46.jpg) 
***
这可能是SSW的第一次对自身的Update[滑稽] [阴险]
点了几下就升级完了[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8a7402390cd79123fd80ee9ea6345982b0b780e9.jpg) 
***
重启后我们可以看到已经刷了版本号了[滑稽]
下面看看程序
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0cfc09071d950a7b226f2b2e01d162d9f0d3c9f3.jpg) 
好像多的真的只有打印机了......
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2ef27a940a7b02085a935a0b69d9f2d3552cc8f3.jpg) 
不过苹果这次良心加了“关机”功能[滑稽]
实测在Macintosh 128k上这个关机只不过是重启到ROM里面而已[阴险]
***
并且我大致看了下，MacWrite 4.5和MacPaint 1.5正是在System 2.0发布的1985年发布的[滑稽] [大拇指]
所以我们开始更Special分支吧[haha] [滑稽]
***
P.S:请在此楼回复“吱”以获得后期更新@
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5fc48e25b899a90154123adc16950a7b0308f52e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a9d0df98a9014c08771c494f017b02087af4f42e.jpg) 
***
这感觉......真的是后来Microsoft Word的发展方向[滑稽] [大拇指]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f86dce004c086e06078f5ea109087bf40bd1cb2e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e9f52b096e061d95116156d270f40ad163d9ca2e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0cfc09071d950a7b1e122f2e01d162d9f3d3c92e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2ef27a940a7b020866ee5e0b69d9f2d3562cc82e.jpg) 
***
这是MacWrite实现的一些基本功能，我们都能在当今的所有文字处理软件看到[滑稽] [大拇指]
总结一下，MacWrite正是后面所有文字处理软件的祖先。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/768ebdb54aed2e738124e6c68c01a18b85d6fa04.jpg) 
***
当lz十分高兴地打开MacPaint的时候......
？？？
***
lz起床来更贴了[滑稽]
早上七点多爬起来赶完作业，今天开更MacPaint吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/411d5e00213fb80e79439f3d3dd12f2ebb3894bb.jpg) 
***
我在winworldpc上找到一个无锁的dsk，丢到System 1.1里面挂载，居然可以打开！！！[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/79f5463eb80e7bec5748fd0b242eb93899506bbb.jpg) 
***
M$Paint的界面和这个可以说是十分/*雷同*/，并且Ps侧边栏也来自于此。
接下来我们来画点东西[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/768ebdb54aed2e731abd7dc68c01a18b85d6fafe.jpg) 
***
搞了半天弄出来个这个[滑稽] [haha]
莫名喜感[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9a402dec2e738bd4217549dbaa8b87d6257ff9fe.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0a1949728bd4b31c14686f518cd6277f9c2ff8fe.jpg) 
***
苹果十分贴心地给当时的人们提供了快捷键和界面布局说明，吼评[真棒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6e87ecd5b31c870135e2490c2c7f9e2f0508fffe.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cb20d41d8701a18b12bfe9a5952f07082a38fefe.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3e8e000a18b87d6b11650f50c0828381d30fdfe.jpg) 
***
同样在Goodies里面有很多高度自定义的选项，比如画笔形状，花纹自定义等等。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7f5c68a87d6277f0946c9d223381f30eb24fcfe.jpg) 
***
像 @焊锡补牙之前所说的那样，Bill Atkinson真的是个大胡子[滑稽]
我在MacPaint上看到了很多后启之秀的影子，包括Ps那隔了三十年的侧栏。MacPaint，开启了图像GUI处理的大门。
***
@焊锡补牙 @VistaWithSP2 @r21657tyq @371东升的旭日 @redapple0204 @一个技术宅_ @我的世界5111 @呵呵韩国观光饭
请在此楼回复“吱”以确定你正在看贴[滑稽]
集齐五个“吱”我就开更SSW3.0[滑稽]
***
贴吧单机版[不高兴]
算了忍痛继续更吧（
System Software 3.0是Macintosh Plus的出厂版本。这次更新带来了HFS的完整支持，800k磁盘启动支持，以及著名的SCSI。同时，System 3.0还加入了System Tools和Utility。
下面我们开机吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edc03e83b2b7d0a2e538e777c0ef760949369a59.jpg) 
***
使用模拟Macintosh Plus的Mini vMac启动后，发现这里面的确多了点东西[滑稽]
我们先准备一个24M的dsk镜像[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/13b79cf3b21193136df11d5a6e380cd793238da4.jpg) 
***
？？？
没有明白这个Installer到底要干嘛
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/43bb1ff1f736afc31444d08fb819ebc4b5451281.jpg) 
***
把System Tools上的System文件拷到目标磁盘上就可以安装了[滑稽]
点击一下就安装完了，不过，读取那个24M的dsk时，非常的......卡
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/38049037afc37931642069c3e0c4b74541a91181.jpg) 
***
就像这样，卡到吔*[阴险]
***
可能是我安装了打印机驱动吧......换了个dsk只安装第一项就什么事情也没有了[勉强]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/68c0539a033b5bb50092c9143dd3d539b400bc8d.jpg) 
***
大概看了下，可能就这点区别了[阴险] [弱]
***
楼主要去整理笔记去了，各位保重[不高兴]
下午我/*可能*/会有时间更一到两个版本，所以......祝各位愉快[勉强]
轻喷[勉强]
***
@焊锡补牙 @VistaWithSP2 @r21657tyq @371东升的旭日 @redapple0204 开更[滑稽]
这次到了SSW 4.1了[滑稽]
是的，4.x的出现标志着Macintosh进入了彩色时代！[太开心]因为其滋磁了Mac SE和Mac II系列，使得全线滋磁了彩色显示。并且System Tools和Utility也刷了一波版本号[滑稽]
下面，开机吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e9f52b096e061d95315836d370f40ad163d9ca30.jpg) 
***
用模拟Macintosh II的Mini vMac打开后，第一眼看到的就是那个耀眼的VGA输出的苹果[太开心]
下面开始安装吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b7c2c8c279310a55a6dadf1fbc4543a980261057.jpg) 
***
一样的界面差评，一样的速度好评[滑稽] [大拇指]
并且SSW 4.1顺便赠送了Utility 2.1，下面我们来看看[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b32ad38e8c5494ee5df90cf226f5e0fe9b257e73.jpg) 
***
这里面似乎是一个合集，而非一个提供了安装程序的软盘。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f47beb5594eef01f94cf1b2eebfe9925be317d73.jpg) 
***
不过不难发现，这些东西似乎是一套急救盘。
我们还是回到SSW 4.1主分支来吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3e8e000a18b87d60bc8a6f40c0828381d30fd4c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7f5c68a87d6277fb3983fd323381f30eb24fc4c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e17fe0d7277f9e2f29bf10e31430e924ba99f34c.jpg) 
这次的Chooser和Control Panel有了改变，并且加入了Find File。不过实用的小工具却少了很多。不知道是不是苹果把系统和应用分开了的原因。
这个版本可能就是这样了吧。
***
下面我直接把SSW“5.0”和SSW6.0更完吧[滑稽]
关于System “5.0”：
这个版本在About Finder上是System 4.2，但在包装盒和说明文稿当中这个版本是5.0。事实上，我也没搞清楚这到底是个什么操作[狂汗]
照例插盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3304e5035aafa40f4d96c136a064034f7af019f9.jpg) 
***
卡......卡死了？！！！
我试着换了一下Utility盘启动，同样无解......
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b8ede119367adab46b5a12a880d4b31c8501e44c.jpg) 
***
很迷的是这货在Mac Plus下居然正常启动了。不管怎么说，先安装吧[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/303b5cc69f3df8dc0222847ac611728b46102837.jpg) 
***
先执行Mac II的安装操作，然后继续把安装好的盘放到了模拟Mac II的Mini vMac下[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7b33f83cf8dcd1006e83f3ca798b4710b8122f37.jpg) 
***
关机加入AT兼容的重启选项大吼评[滑稽] [大拇指]要知道在Mac II上我才发现了ACPI
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ab0c7d4d510fd9f988d05e822e2dd42a2a34a40f.jpg) 
***
SSW 5.0怕不是和Mac II有仇......
插入安装好的盘仍然卡死在开机[阴险]
我还是先用Mac Plus吧[阴险]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/43cf3cb4c9ea15ce500694e2bd003af33887b262.jpg) 
***
【插播楼主学习情况】我好兴奋啊（
***
回来了[滑稽]
这次System “5.0”主要更新了MultiFinder，能够完美地滋磁多任务运行[真棒]这里也增加了选择启动项的选择页面。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a529801090ef76c629df82c09616fdfaad5167c5.jpg) 
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a7e5f7ee76c6a7ef412bd1cdf6faaf51f1de66c5.jpg) 
***
重启到MultiFinder后，可以看到右上角有一个很明显的图标，这是你正在运行的程序的图标，也是后来多任务切换的地方（“5.0”并不滋磁在这里切换，因为这里压根没有下拉菜单）。
其他好像就没有什么了[勉强]
***
我说了今天要更到6.0的[滑稽]
System 6.0.x就是苹果迈向全球化的第一步了。这次，苹果更新了大量亚太区域的语言，以适应更多亚太区域的用户们。这次更新同时加入了MultiFinder的一些新功能（from winworldpc）。
所以，你们想先看6.0.7 SC呢，还是6.0.8 US呢[滑稽]
评论告诉我！[滑稽] [haha]
***
应 @r216571tyq 的要求，我先更6.0.7 SC[滑稽]
Special！[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/191a5a6c55fbb2fb738138f9444a20a44423dcac.jpg) 
***
严重机翻差评，安装界面大改大吼评[真棒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7d9932fab2fb43165cb51a912ba446230bf7d3ac.jpg) 
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/150fd5fa43166d227ddd757f4d2309f79252d2ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f20f24176d224f4a133313f802f790529a22d1ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/03e20a234f4a20a472b45c2c9b529822700ed0ac.jpg) 
***
这里的安装风格已经有点像后面Classic Mac OS的通用安装风格了[滑稽] [大拇指]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2dd6284b20a446233c60c5899322720e0ef3d7ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0fbe47a5462309f7a6c5cdf9790e0cf3d5cad6ac.jpg) 
***
完结撒花[滑稽]
下面拔盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b3f6d47f21fbe095535a0ff60600c338544ade3.jpg) 
***
默认启动MultiFinder吼评[滑稽]并且这里注意右上角，已经有了专门适配的输入法[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4ab2951ebe096b63c9723dbb07338744e9f8ace3.jpg) 
***
这是1990年发布的，也就是说还是比Windows 3.2早上了2年[滑稽] [大拇指]
下面我们来看看功能吧。
***
常言道：“直播必吔饭[滑稽]”，lz刚才就是去吔饭去了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/678bf92e0708283818c188ffb399a9014e08f106.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dedb600928381f30e1d5d942a2014c086c06f006.jpg) 
MultiFinder应用切换在苹果菜单里，新增颜色菜单吼评[滑稽]
并且这次增加了对Powerbook的滋磁，看到那个电池了吗[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e9835e13b31bb05100aee7c33d7adab448ede04d.jpg) 
然而这东西并不能用[滑稽] [弱] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/49d7ba55564e925843add2059782d158cebf4eb1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3379ce763912b31b47e699c28d18367ad8b4e14d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f0a59f188618367a21032b3625738bd4b11ce54d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/97de0758252dd42a68515540083b5bb5cbeab8f2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dea568b20f2442a70f97a94eda43ad4bd31302b1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4b0bb7122b89025aafa60f06b1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/65ebf2cbd1c8a78661991ee56c09c93d72cf509b.jpg) 
所有的程序，还是有部分没有被汉化的地方，不过已经很完善了[滑稽]
下一层楼测试输入法[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c760c3c37d1ed21bb97b700ea66eddc453da3fa4.jpg) 
***
输入法仍然是单拼，使用方向键选字，回车键确定，和Win3.2的拼音比起来绝对有的一拼[滑稽] [弱]
这基本上是System 6.0.7 SC的全部特性了，下周再更[勉强]
***
你们一定要相信我这贴一定不会凉的[滑稽]
开更[滑稽]
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
请在此楼回复“吱”以确认你正在看贴[滑稽]
下面开更6.0.8[滑稽]
***
其实说白了我更6.0.8就是为了给你们对照下当时的机翻水平的[滑稽]
插盘开机后，我们可以发现这里多了一个安装环境[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/92ef69f51bd5ad6e34ed6d3e8acb39dbb4fd3cc7.jpg) 
***
并且安装程序被藏在了软盘里，而不是开机自启[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4e007cd4ad6eddc4bbf3bd2f32dbb6fd506633c7.jpg) 
***
并且这次好歹还有了个排列[滑稽]
开装[滑稽] [haha]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1976d5b6d0a20cf4b2c9f60b7d094b36aeaf99fa.jpg) 
***
为了让标题更优雅，苹果特地把标题换了个字体，英文是Times，中文是正楷[滑稽]
不过都是锯齿感人[滑稽] [弱]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f243b7a30cf431ad4f8b4bed4036acaf2cdd98fa.jpg) 
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90566bf531adcbeff36d76d2a7af2edda1cc9ffa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4c0056accbef7609cd52914b25dda3cc7ed99efa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7159acee76094b362bcb1339a8cc7cd98f109dfa.jpg) 
***
这里都是一样的，不过英文由于少了中文GB2312字库就只有两张盘[滑稽]
完结撒花，拔盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a7e5f7ee76c6a7ef53f3a3f2f6faaf51f1de6606.jpg) 
***
其实其他都是一样的，就是语言和翻译不同[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d01b11c7a7efce1b03fec31ea451f3deb68f6506.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3632c0eece1b9d16621291b5f8deb48f8e546406.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e71ba91a9d16fdfa0fb9cd3abf8f8c5496ee7b06.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8eeffa17fdfaaf5152368a6b875494eef21f7a06.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dde29afbaf51f3de1667b2b09feef01f38297906.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bd0ec850f3deb48f2fbcaa0afb1f3a292ff57806.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/efa594dfb48f8c543006cefb31292df5e2fe7f06.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b32ad38e8c5494ee55f704cd26f5e0fe9b257e06.jpg) 
***
所有的应用，都差不多，你们可以对照着看翻译[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c760c3c37d1ed21bedbc2431a66eddc453da3fe6.jpg) 
MultiFinder同样没有区别[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e4361a1fd21b0ef4ff9d928ad6c451da83cb3ee6.jpg) 
系统文件也是大同小异，只是没有中文talk而已[滑稽]
***
下面开更7.0吧[滑稽] [haha]
System 7.0可以说是苹果正式迈入彩色时代的一个象征，因为这次大幅度地加入了彩色元素[滑稽]要知道之前版本貌似真的只有苹果标志是彩色的[阴险]
并且这次还增加了一个全新的帮助系统，还是得装上再看看[滑稽]
同时这次苹果还优化了下系统架构，重新清理了一遍系统文件夹，同时用C重写了很多组件，替换了原来大量的Pascal组件。
下面插盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/39c56d54b319ebc4bfa3004d8926cffc1c17167b.jpg) 
***
刚开机时一阵惊喜啊！[滑稽]这次看来是真的大刀阔斧地加了颜色[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4aa1d418ebc4b7454a4fc1c2c4fc1e178882157b.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3ed8cc5b74543a988c08c1815178a82bb01147b.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ab30d04443a98226c41a5df38182b9014890eb04.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f7b124a88226cffc12f1c966b2014a90f403ea04.jpg) 
安装过程，有颜色就是不一样[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/035de527cffc1e178764fae54190f603718de904.jpg) 
完结撒花，拔盘开机[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c2d2a8fd1e178a82b7e70974fd03738dab77e804.jpg) 
并且貌似安装程序并没有使用ACPI，这里还给出了一个选择关机重启的对话框。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edc03e83b2b7d0a279a57b49c0ef760949369aef.jpg) 
***
给出了机型型号吼评[真棒]
不过恕我喷一句，苹果的设计师就这么喜欢这种蓝色吗[阴险]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1976d5b6d0a20cf447fc810b7d094b36aeaf99ef.jpg) 
苹果菜单加上应用图标大吼评[真棒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f243b7a30cf431adbcbe3ced4036acaf2cdd98ef.jpg) 
颜色菜单加上了一堆喜感的名字[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90566bf531adcbef0e5801d2a7af2edda1cc9fef.jpg) 
这便是帮助了，后面我会看看到底有些什么的。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4c0056accbef76093267e64b25dda3cc7ed99eef.jpg) 
同样默认启动MultiFinder，并且这次加了一堆选项[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4fd025a6d933c8953ccde1afda1373f0800200ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0253be32c895d14343c59df778f0820258af07ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4b3e9d3f1489025aafa60f06ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd113837ecee651afa40f49fb05ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91b7ca4ad11373f0738c164baf0f4bfbf9ed04ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202a821e8eb40fbfbeda9641bac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91e714f182025aaf5781071ff0edab64014f1aac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3304e5035aafa40fbf75b709a064034f7af019ac.jpg) 
***
所有的应用，基本就是加灰，加蓝，立体化[滑稽] [阴险]
并且Puzzle换成了苹果标吼评[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d2acb608b3de9c82781b815b6781800a1bd843d9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91fdd4df9c82d15866fc21658b0a19d8be3e42d9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f32afb83d158ccbfc7c2cdee12d8bc3eb33541d9.jpg) 
***
这便是帮助了。其实说白了，就是一个姗姗来迟的气泡而已。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dc76b659ccbf6c812c49543cb73eb13531fa40d9.jpg) 
***
并且System Folder也加入了相关调整，可以加扩展了[滑稽]
***
lz先更到这里，先去做完作业了来[勉强]
开更！
再次重申这贴绝不会凉除非更完[滑稽]
（lz终于考完了耶耶耶耶耶耶耶耶耶
***
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
可以的今天开更7.5.3[滑稽]
System 7.5貌似就是一堆DPI的加入，以及一些新PowerPC硬件的滋磁。不过这里我们仍然使用Mini vMac来模拟到最后[滑稽]
所以你们打算先看SC还是US呢[滑稽]
此楼回复[滑稽] [haha]
***
可以吧那就先开SC[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e9f52b096e061d95c937aee370f40ad160d9caea.jpg) 
***
这次是一个iso，所以我得先从6.0.7 SC启动[阴险]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1292b7170924ab1815ff78ec3efae6cd79890b71.jpg) 
***
当lz兴致勃勃地打开安装程序时......
那好吧我们用7.0启动[阴险]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8b1b11084b36acaf36270e2777d98d1003e99c1f.jpg) 
***
享受来自GB2312的乱码吧[滑稽]
大面积乱码警告[滑稽] [haha]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/36fd2c37acaf2eddba36d132861001e93b01931f.jpg) 
是的没错，由于当时的嘤glish没有GB2312字库的滋磁，所以就只能这样（
下面开装
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0cfc09071d950a7bc234cb1f01d162d9f0d3c9da.jpg) 
***
貌似卡死（
不过没关系，模拟器速度调到All out就好了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2ef27a940a7b0208bac8ba3a69d9f2d3552cc8da.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5d616d7a02087bf4c8edd232f9d3572c13dfcfda.jpg) 
***
受不了乱码了，重启[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e918ed12632762d03d582064abec08fa533dc6f9.jpg) 
***
界面小改，输入法加入吼评[滑稽] [大拇指]
***
补上楼：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8be72e550923dd54699820b3da09b3de9e824873.jpg) 
***
这可能是首个出现Mac OS字样的SSW，不过关于本机里面还是原来的SSW[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/09a06e22dd54564ed28e63e2b8de9c82d3584f73.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/891e72cf36d3d53942b68f183187e950372ab05c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/553a51d2d539b600cf458f6ce250352ac45cb75c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7627b238b6003af3cc315cbb3e2ac65c1238b65c.jpg) 
苹果菜单里多了点东西，同时加入了输入法[滑稽]
并且这次机翻好很多了[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4a8f65097bf40ad1d9c64a385c2c11dfabeccec5.jpg) 
首先最显眼的就是游戏变成了拼图[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/42fc1cf50ad162d94eccefc71adfa9ec8813cdc5.jpg) 
然后是便签，这应该是M$的Sticky Note的原身，有知道的可以补充一下[勉强] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b006dd062d9f2d3ea33a934a2ec8a136127ccc5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4a2505d8f2d3572cafc011078113632760d0c3c5.jpg) 
搜索更立体了[真棒] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/222d95d2572c11df16f332f8682762d0f503c2c5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b227302d11dfa9ec4a0cdbcc69d0f703938fc1c5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/17d876dea9ec8a13a238da3bfc03918fa2ecc0c5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/512bceed8a136327a0cf4fe89a8fa0ec0afac7c5.jpg) 
这是苹果的CD Player，不过由于模拟器的原因，这里并不能使用光驱......
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e918ed12632762d0341c2964abec08fa533dc6c5.jpg) 
Chooser多了几个打印机[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cae7042662d0f7035590180703fa513d2497c5c5.jpg) 
并且这是第一次出现自动化的Script[真棒]
***
下面测试输入法[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/68cc7831e924b8991b86f5e365061d95087bf6ad.jpg) 
这次苹果加了“全拼”，只不过是把候选栏整个移到下面了，并且只能单字输入[阴险]
感觉......有点倒退的意思[阴险]
***
下面给各位对照下US的7.5.3我就要睡了[勉强]
明天从7.5.3 US升级到7.5.5，System Software阶段就算完结撒花了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2c75e70b19d8bc3ef1b28f11898ba61eaad345ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c0fe7ed9bc3eb135727d3e60ad1ea8d3ff1f44ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/592cdb3fb13533fac00c1af5a3d3fd1f43345bac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fccad63433fa828be5991438f61f4134950a5aac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f1c154fb828ba61eec5441f44a34970a324e59ac.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/730ee58aa61ea8d3b898fddf9c0a304e271f58ac.jpg) 
***
此楼为安装过程，区别不大。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/94cbe095a4c27d1eb1f8b01f10d5ad6edfc43800.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c760c3c37d1ed21b6a17a53ea66eddc453da3f00.jpg) 
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e4361a1fd21b0ef47e361385d6c451da83cb3e00.jpg) 
值得一提的事，英文版的盘里似乎多了些经典的应用。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3deab51a0ef41bd5cb8d632f5ada81cb3bdb3d00.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/92ef69f51bd5ad6eba27ef318acb39dbb4fd3c00.jpg)
***
好了lz明天再更，各位晚安[勉强]
开更！
今天先更7.5.5[滑稽]
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fefd0c62f6246b6076c49aa8e0f81a4c530fa21d.jpg) 
***
这其实是苹果官方的三张升级软盘，所以我直接一股脑丢了进去[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f20f24176d224f4a49b859cf02f790529922d13a.jpg) 
可以看到这里就只有一个无用的霸王条款[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/03e20a234f4a20a42c3f161b9b529822730ed03a.jpg) 
然后就直接开门见山了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2dd6284b20a4462362eb8fbe9322720e0df3d73a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0fbe47a5462309f7fc4e87ce790e0cf3d6cad63a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6050212209f79052f53e6de207f3d7ca7acbd53a.jpg) 
***
非常简单，就这点东西[滑稽]
下面重启[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/03e20a234f4a20a42cbe161b9b529822700ed0bb.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2dd6284b20a44623626a8fbe9322720e0ef3d7bb.jpg) 
大概看了下，还真的没什么变化......
估计这次的变化更多的体现在补丁上[阴险] [滑稽]
***
不过，本macOS史第一阶段——System Software篇更完了！！！[滑稽] [胜利]
完结撒花[滑稽] [玫瑰]
***
下面开更Mac OS 7.6.1吧[滑稽]
Mac OS 7.6.1是第一个正式被苹果介绍为“Mac OS”的系统版本，不过好像除了名称就没别的了[黑线]
并且最重要的一点是7.6.1抛弃了对老旧68000和68020的滋磁，也就是说Mini vMac正式不能用了[不高兴]
接下来直到Classic环境完结我都将继续使用模拟PowerPC的SheepShaver进行直播[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b0eb5d282df5e0fe5fea9ddd576034a85cdf7275.jpg) 
***
在偏好设置页上，我直接给出了Classic Mac OS的最强配置[滑稽] [haha]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/83099b029245d6882f4da578afc27d1ed01b2490.jpg) 
***
一开机就想让我格式化硬盘啊[滑稽]
那好就格吧[滑稽]
这次加入了光盘安装环境和桌面图案吼评[真棒]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0bc2cbae2edda3ccdf45a9fc0ae93901233f92ba.jpg) 
***
经典的Mac OS小人正式在历史中出现[滑稽] [大拇指]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ec5b49dca3cc7cd9298c25053201213fba0e91ba.jpg) 
经典的开始界面[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6e29c4cd7cd98d10a4751ded2a3fb80e79ec90ba.jpg) 
可以看到苹果当时苹果貌似是第一次做这种安装程序，居然还要分步骤[黑线]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e3381bd88d1001e99f9d05d3b30e7bec56e797ba.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3c2dea1101e9390186a39ce270ec54e734d196ba.jpg) 
虚拟硬盘不要钱[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cde466e83901213f10925f005fe736d12d2e95ba.jpg) 
霸王条款不读[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/411d5e00213fb80ed270700b3dd12f2ebb3894ba.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/79f5463eb80e7becfe7b123d242eb93899506bba.jpg) 
好了，就这么就可以重启了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/61cbdf0f7bec54e79d4d0bc2b2389b504dc26aba.jpg) 
***
最后来一张光盘版本[滑稽]
About This Computer还没改差评[阴险]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/22249002918fa0ec50c377d12d9759ee3f6ddbdf.jpg) 
开机没什么大问题，7.5.3也有这个[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b7f7f68ea0ec08fa0804007b52ee3d6d57fbdadf.jpg) 
开机就告诉我能睡眠[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d17bc7ed08fa513d7cae7f02366d55fbb0fbd9df.jpg) 
***
先来一张版本[滑稽]
还有就是，下面的快速控制面板也出现了[真棒]貌似这个快速控制面板一直在后面的Classic都有，直到OS X的Dock出现[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1b41aeeb15ce36d3aa359fec31f33a87e850b12a.jpg) 
苹果菜单里出现了些新的东西[滑稽]
大概看了下，就是下面这些： 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/891e72cf36d3d539360c131f3187e950342ab02a.jpg) 
看得出SheepShaver模拟的是Power Macintosh 9500的ROM，但是配上了一个PowerPC G4（后面可知）的CPU[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/553a51d2d539b600bbff136be250352ac75cb72a.jpg) 
这貌似是一个计算图表的东西，后面演变成了Grapher[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7627b238b6003af3b88bc0bc3e2ac65c1138b62a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/95cdd1013af33a876a5c1cc6cd5c10385243b52a.jpg) 
同时值得一提的是，由于SheepShaver光驱的加入，Apple CD Player可用了[滑稽]
***
我打算等下更Mac OS 8.1你们说吼不吼哇[滑稽]
此楼回复三个吱开更[滑稽]
***
算了忍痛也得更啊[不高兴]
Mac OS 8主要更新了完整的Platinum设计风格，优化了设备性能，同时也提供了网络连接[滑稽] [大拇指]
不过此时Mac OS 8预装的是Microsoft IE[阴险]
下面开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3fca0008c93d70cfe535afd1f3dcd100b8a12b10.jpg) 
***
开机一看，顶栏风格很明显变了[滑稽]
并且我必须要提的是，顶栏菜单支持单击悬停了！[真棒]
这个是我必须要大赞的功能，因为从此以后我就可以直接截取窗口而不是截取整个屏幕再裁图了[太开心]（macOS默认窗口截图需要单击一下，但是Mac OS 7及以前的菜单必须要一直按住鼠标左键才能悬停）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/27fdae3c70cf3bc740cfc830da00baa1cf112a10.jpg) 
***
就像这样[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/89c917ce3bc79f3d182ee1ecb1a1cd11708b2910.jpg) 
***
打开光盘可以看到多了好多东西，包括IE和Netscape Navigator[滑稽] [大拇指]
下面开装[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f7b124a88226cffc007cbb6eb2014a90f403ea89.jpg) 
***
补楼上：这次Mac OS 8还带来了著名的HFS+，使当时的磁盘性能大为提升[滑稽] [大拇指]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/06d76ef69052982228143f1fdcca7bcb0b46d438.jpg) 
这次有了向导式的安装程序，画风和谐些了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4903f7539822720e57e9e42670cb0a46f31fab38.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d0a6ff23720e0cf38bd048270146f21fbf09aa38.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d8d6150f0cf3d7ca26d139aaf91fbe096a63a938.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/32fa6bf2d7ca7bcb545cc1f3b5096b63f724a838.jpg) 
安装说明和霸王条款都给出来了，还需要同意一遍[阴险] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4c07b0cb7bcb0a46ad058de56063f6246a60af38.jpg) 
虚拟硬盘不要钱[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/973e1cca0a46f21fde13588ffd246b600d33ae38.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b3f6d47f21fbe090a79c5c860600c338644ad38.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4ab2951ebe096b63943e588c07338744eaf8ac38.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b2ebd9086b63f624087a3fdf8c44ebf81b4ca338.jpg) 
最后的结束画面我没截到，是因为SheepShaver喜闻乐见又卡Bug了......
安装完直接闪退[阴险]
***
@bingohuanj @ss433_2 申精[吐舌]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cd45ac124954092360ee65a29958d109b1de4958.jpg) 
***
补上版本合照[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4f47682542a7d933ca05e7afa64bd11371f001b5.jpg) 
开机加入桌面图案吼评[真棒] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4fd025a6d933c895d2d39ba7da1373f0800200b5.jpg) 
同样是开机提示睡眠，不过貌似到了Mac OS 9就没了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0253be32c895d143a9dbe7ff78f0820258af07b5.jpg) 
啊是这个，经典的设置助理[滑稽] [大拇指] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4bd483451c89025aafa60f06b5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd1137560b4ee51afa40f49fb05b5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91b7ca4ad11373f085926c43af0f4bfbf9ed04b5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202523f92e340fbfbeda9641bb5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91e714f182025aafad9f7d17f0edab64014f1ab5.jpg) 
大概就是一些这样的东西，但是......SheepShaver再次喜闻乐见闪退......[阴险]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/411d5e00213fb80eec9c620b3dd12f2ebb389496.jpg) 
补上版本，这个地球有点意思[滑稽]
lz有点事情，可能要等到12:00才能把这个更完了[勉强]
***
可以了开更吧[滑稽]
更完这个版本我就得去看书去了[勉强]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9da0314f9258d109261fc36eda58ccbf6e814d67.jpg) 
这次苹果的确加了很多东西，并且大刀阔斧地改了外观[真棒] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/16baf559d109b3de0a438eb4c7bf6c81820a4c67.jpg) 
然并*的收音机[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d2acb608b3de9c82469993536781800a1bd84367.jpg) 
系统信息有一点小改[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91fdd4df9c82d158547e336d8b0a19d8be3e4267.jpg) 
CD Player并没有什么变化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f32afb83d158ccbff540dfe612d8bc3eb3354167.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dc76b659ccbf6c811acb4634b73eb13531fa4067.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91acabbe6c81800a8219e3d2ba3533fa808b4767.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8c4b0b80800a19d820ffeed938fa828ba41e4667.jpg) 
新增！网络连接助理[滑稽]
不过SheepShaver并不能上网，因为没有FPU模拟......
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2c75e70b19d8bc3e2cf46c16898ba61eaad34567.jpg) 
控制面板更整齐了[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/89e3183f6709c93ddcfb5a2b943df8dcd30054d2.jpg) 
***
不过值得一提的是，这次桌面有了图片[滑稽] [大拇指]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3fca0008c93d70cf96f3fed1f3dcd100b8a12bd2.jpg) 
***
这个扁平化做得很棒的说[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b6d00c610c338744d8287ca05a0fd9f9d52aa076.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2b946b328744ebf82e9c37e3d2f9d72a6259a776.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4cc7e045ebf81a4c64dfbf15dc2a6059272da676.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7b08cf91a4c510fef29b1c66b59252dd62aa576.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ab0c7d4d510fd9f9e0fa06b52e2dd42a2a34a476.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5ab8360ed9f9d72a588943c1df2a2834369bbb76.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/11fbbef8d72a60591cfdb2c62334349b013bba76.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/990db02b6059252deefa4ed83f9b033b59b5b976.jpg) 
其他就没什么多的了[滑稽]
***
开更！[滑稽]
今天我尽量更完Classic Mac OS吧[滑稽]
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
下面是Mac OS 8.5[滑稽]
Mac OS 8.5貌似是第一个抛弃了68k支持的Mac OS，不过我在winworldpc上找到了一个中文版[滑稽]
所以你们打算先看SC还是US？
例行此楼回复[滑稽]
***
好那就先更SC[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2c75e70b19d8bc3e05057b14898ba61eaad345d0.jpg) 
***
全中文真是棒啊[滑稽] [大拇指]
下面开始安装[滑稽]
***
我需要先说明一下，这是Power Macintosh G3的随机附赠安装盘，所以在其中还能看到Power Macintosh G3的说明文件[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cae7042662d0f703a548e80203fa513d2497c56f.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d1d7f0dca144ad342b03f859dba20cf433ad85a1.jpg) 
这次的中文翻译自然多了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d729c645ad345982c1369a4c07f431adc9ef84a1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e1b0ca355982b2b7a423461a3aadcbef74099ba1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edc03e83b2b7d0a279757b43c0ef760949369aa1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1976d5b6d0a20cf4472c81017d094b36aeaf99a1.jpg) 
霸王条款都是那么简单易懂[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f243b7a30cf431adbc6e3ce74036acaf2cdd98a1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90566bf531adcbef0e8801d8a7af2edda1cc9fa1.jpg) 
这次苹果直接让安装程序单独运行了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4c0056accbef760932b7e64125dda3cc7ed99ea1.jpg) 
好了，完结撒花，拔盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ed9abac551da81cbe5d1fa135966d0160824312a.jpg) 
启动速度好快......
敌不过我的手速[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9d3036db81cb39db6bf71e88db160924aa18302a.jpg) 
又到了设置助理时间[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/112ee6ca39dbb6fd8c6c9cf80224ab18962b372a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c13f5edab6fd52660f1c45caa018972bd507362a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/792fd1fc5266d016e92ee7f69c2bd40734fa352a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f6093567d01609244a12dbc5df0735fae7cd342a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1292b7170924ab18752198e93efae6cd7a890b2a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90e26e25ab18972b370d7914edcd7b899f510a2a.jpg) 
***
喜闻乐见再次卡死[喷]
没事我们来看应用[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d7dfb30635fae6cd9d66d2bf04b30f2440a70f17.jpg) 
刚才硬重启之后，我突然发现Mac OS 8.5加入了磁盘修复[真棒]
又是一个新特性[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/94f352fbe6cd7b8979be435d042442a7db330e17.jpg) 
苹果菜单又换了一波中文名[滑稽] [大拇指]
下面我们来看看汉化程度[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dea568b20f2442a73092867bda43ad4bd3130241.jpg) 
图表貌似就是英文搬过来的...... 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4f47682542a7d93322349fada64bd11371f00141.jpg) 
又改了一波！[真棒] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4fd025a6d933c8953ae2e3a5da1373f080020041.jpg) 
新！著名的Sherlock，以福尔摩斯的大名命名还真是有底气[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0253be32c895d14341ea9ffd78f0820258af0741.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4b3cb23d1e89025aafa60f0641.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd1139d51ccec51afa40f49fb0541.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91b7ca4ad11373f06da31441af0f4bfbf9ed0441.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202aa0eeae140fbfbeda9641b41.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91e714f182025aaf55ae0515f0edab64014f1a41.jpg) 
这几样的汉化都很自然[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0bc2cbae2edda3cc052bc3fe0ae93901233f9212.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ec5b49dca3cc7cd9f7e24f073201213fba0e9112.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6e29c4cd7cd98d107a1b77ef2a3fb80e79ec9012.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e3381bd88d1001e945f36fd1b30e7bec56e79712.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3c2dea1101e939015ccdf6e070ec54e734d19612.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cde466e83901213fc6fc35025fe736d12d2e9512.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/411d5e00213fb80e041e1a093dd12f2ebb389412.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/79f5463eb80e7becd415783f242eb93899506b12.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/61cbdf0f7bec54e7b72361c0b2389b504dc26a12.jpg) 
值得一提的是，Mac OS 8.5里面竟然内置了9大9个主题！[真棒]
你们感觉和Win98相比，哪个更好呢？[滑稽]
此楼评论[滑稽]
***
lz现在又被母上叫去洗碗，请各位看官稍等一下，小的去去就回，轻喷[勉强]
回来了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cb20d41d8701a18b8d997e91952f07082a38fef7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3e8e000a18b87d62c30c7c10c0828381d30fdf7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7f5c68a87d6277f92605ee623381f30eb24fcf7.jpg) 
这个苹果DVD光盘程序根本打不开，可能是因为SheepShaver只模拟了CD驱动器的原因吧。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e17fe0d7277f9e2f0a4771d61430e924ba99f3f7.jpg) 
这次系统概述定型了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c722407e9e2f0708267746dee224b899ab01f2f7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/678bf92e07082838107fb0cab399a9014e08f1f7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dedb600928381f30f96be177a2014c086c06f0f7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/47fc4f391f30e924a9d6f0ef47086e061f95f7f7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/68cc7831e924b899bb4e15e665061d95087bf6f7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5fc48e25b899a9015f4737e816950a7b0008f5f7.jpg) 
并且比较有趣的是，8.5的IE被正式直接摆了出来。
其实关于Mac OS捆IE的，有一个非常重要的原因，那就是这其实是微软威胁的。如果苹果不捆IE，微软就不给苹果开发Office for Mac[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e4361a1fd21b0ef4d294f780d6c451da83cb3ee1.jpg) 
最后一张系统版本，方正姚体吼评[滑稽] [大拇指]
lz今天就更到这里吧，明天我同学要找我一起编曲，我更贴的时间就比较少了。
@你de爸爸吖 [滑稽]
***
开更！[滑稽]
今天应该能再更一个版本[滑稽]
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
先更Mac OS 8.5的英文版更完吧[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e0186ffb513d2697d28dcb825efbb2fb4116d88d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/480e363c269759eeb10ea314b9fb43166f22df8d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/11c9419659ee3d6dd898441448166d224d4ade8d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/66633eef3d6d55fb3c98b5f966224f4a22a4dd8d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/191a5a6c55fbb2fbcc759bcd444a20a44423dc8d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7d9932fab2fb4316fd41b9a52ba446230bf7d38d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/150fd5fa43166d22de29d64b4d2309f79252d28d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f20f24176d224f4ab2c7b0cc02f790529a22d18d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/03e20a234f4a20a4d540ff189b529822700ed08d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2dd6284b20a446239d9466bd9322720e0ef3d78d.jpg) 
***
安装过程，除了桌面和语言真的没什么变化。-
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8b1b11084b36acafe197552377d98d1003e99cf4.jpg) 
补版本，拔盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/750e81cc7b899e5132ddf8cb49a7d933ca950d97.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a6391c889e510fb3314ab548d233c895d3430c97.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b7df9500fb30f247dc92edcc395d143af4b0397.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dea568b20f2442a7995d3f7ada43ad4bd3130297.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4f47682542a7d93389fb26aca64bd11371f00197.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4fd025a6d933c895932d5aa4da1373f080020097.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0253be32c895d143ee2526fc78f0820258af0797.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4b957d841f89025aafa60f0697.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd113369e75ed51afa40f49fb0597.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91b7ca4ad11373f0c46cad40af0f4bfbf9ed0497.jpg) 
可算是走完一遍Setup Assistant了[狂汗]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cae7042662d0f7031474570303fa513d2497c525.jpg) 
我就知道它会在网络上面炸掉，所以我就直接Control+Option+Escape了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/23d305d1f703918f2617ff155a3d26975beec425.jpg) 
补上磁盘检查[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f2e5f412b07eca80df70f0389a2397dda34483ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d3e7d77fca806538b79f6dcc9cdda144af3482ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f08aad8165380cd72d6b6b32aa44ad345b8281ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8a7402390cd791232a955daba6345982b0b780ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/25cc6bd6912397dd1f0c51db5282b2b7d2a287ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4c23f62297dda144127ca56db9b7d0a20ef486ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d1d7f0dca144ad3499ca4e58dba20cf433ad85ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d729c645ad34598273ff2c4d07f431adc9ef84ea.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e1b0ca355982b2b712eaf01b3aadcbef74099bea.jpg) 
***
这些都没有什么变化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0f36b2638535e5dd3c906c007dc6a7efcc1b62a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9596e234e5dde7114c6e8a29acefce1b9f1661a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c5c182dce71190efab475b00c51b9d16fffa60a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a529801090ef76c6796e32f49616fdfaad5167a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a7e5f7ee76c6a7ef119a61f9f6faaf51f1de66a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d01b11c7a7efce1b7d970115a451f3deb68f65a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3632c0eece1b9d161c7b53bef8deb48f8e5464a3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e71ba91a9d16fdfa4dd00f31bf8f8c5496ee7ba3.jpg) 
不过我发现一个十分有趣的问题，也许那个“棒棒糖”是Power Macintosh G3独占？[滑稽]
零售版只有8种主题。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a529801090ef76c67af133f49616fdfaad5167c0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a7e5f7ee76c6a7ef100560f9f6faaf51f1de66c0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d01b11c7a7efce1b42080015a451f3deb68f65c0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3632c0eece1b9d161de452bef8deb48f8e5464c0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e71ba91a9d16fdfa4e4f0e31bf8f8c5496ee7bc0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8eeffa17fdfaaf5111c04960875494eef21f7ac0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dde29afbaf51f3de579171bb9feef01f382979c0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bd0ec850f3deb48f684a6901fb1f3a292ff578c0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/efa594dfb48f8c5471f00df031292df5e2fe7fc0.jpg) 
***
不过这次我并不能直接开IE了......
lz上午就更到这里，各位下午见[勉强]
***
开更！[滑稽]
今天上午再来一个Mac OS 8.6[滑稽]
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/09a06e22dd54564e0ca685f8b8de9c82d3584f21.jpg) 
开机一看背景图片变了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/49d7ba55564e92584ef7e72f9782d158cebf4e21.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9da0314f9258d1091320c873da58ccbf6e814d21.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/16baf559d109b3de3d7c85a9c7bf6c81820a4c21.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d2acb608b3de9c8273a6984e6781800a1bd84321.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91fdd4df9c82d1586f4138708b0a19d8be3e4221.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f32afb83d158ccbfc87fd4fb12d8bc3eb3354121.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dc76b659ccbf6c8125f44d29b73eb13531fa4021.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91acabbe6c81800abf26e8cfba3533fa808b4721.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8c4b0b80800a19d81bc0e5c438fa828ba41e4621.jpg) 
安装程序倒没有什么大变化[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b7c2c8c279310a554795be35bc4543a9802610b7.jpg) 
***
补系统版本[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c2d2a8fd1e178a8242871c61fd03738dab77e8aa.jpg) 
版本号第一次出现在开机[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8f0879168a82b901b616a0f2788da9773b12efaa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5ee3ed83b9014a900b85257ca2773912b11beeaa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ca76de004a90f6038d0bff863212b31bb251edaa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f9f52d91f603738d56f16fe3b81bb051fa19ecaa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0a649102738da9773995e5eabb51f8198418e3aa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b6f7148ca9773912b29ce6a0f3198618347ae2aa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3379ce763912b31bb2d6aee88d18367ad8b4e1aa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e9835e13b31bb051fb9ed0e93d7adab448ede0aa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/79e6d41ab051f819829f608bd1b44aed2c73e7aa.jpg) 
这里也没有什么大变化。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/09a06e22dd54564e0ecb87f8b8de9c82d3584fbe.jpg) 
***
磁盘检查貌似直到Mac OS 9都没变化[黑线]
***
大概看了下，有变化的可能也只有IE了......
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/745c39de8db1cb13deef5ed2d654564e90584b66.jpg) 
不过当我截完图后1s内，SheepShaver第n次喜闻乐见闪退......[喷]
***
所以下面我准备开始更Mac OS 9了[滑稽]
Mac OS 9是最后一个Classic Mac OS，此后，带有全新Darwin内核的OS X取而代之。
这次更新带来了全新的Sherlock 2和其他一些无名的功能、
所以你们打算先看SC还是US呢[滑稽]
（提示：SC由于是恢复盘，故没有安装程序）
此楼回复[滑稽]
***
吼那就US[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cde466e83901213fd74b261d5fe736d12d2e95e8.jpg) 
一开机就知道版本更了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/411d5e00213fb80e0ba909163dd12f2ebb3894e8.jpg) 
这里除了CD内没啥变化[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/303b5cc69f3df8dc630ce550c611728b46102837.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7b33f83cf8dcd10009ad92e0798b4710b8122f37.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dfc99fddd100baa1791d2d7a4c10b912c9fc2e37.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b828b601baa1cd11c78718e1b212c8fcc2ce2d37.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91f4dda0cd11728bf11ce6e3c3fcc3cec2fd2c37.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fa55aa10728b47100e1e970dc8cec3fdfd032337.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8de5158a4710b91270f09c3fc8fdfc0393452237.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/327f2011b912c8fc7ac29c0cf7039245d7882137.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/07e4de13c8fcc3ce79f1a3f29945d688d53f2037.jpg) 
安装程序仍然没啥变化[阴险]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dea568b20f2442a701489764da43ad4bd31302a6.jpg) 
关于这台电脑倒是变了点[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e918ed12632762d0ed9ff07eabec08fa533dc647.jpg) 
开机就是一个版本号不同......
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cae7042662d0f7038a13c11d03fa513d2497c547.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/23d305d1f703918fbc70690b5a3d26975beec447.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/22249002918fa0ec156630cc2d9759ee3f6ddb47.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b7f7f68ea0ec08fa4fa1476652ee3d6d57fbda47.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d17bc7ed08fa513d390b381f366d55fbb0fbd947.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e0186ffb513d269779725c9c5efbb2fb4116d847.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/480e363c269759ee1cf1340ab9fb43166f22df47.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/11c9419659ee3d6d7767d30a48166d224d4ade47.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/66633eef3d6d55fb916722e766224f4a22a4dd47.jpg) 
不过可喜可贺的是，这次的错误对话框可以把OK点下去了[滑稽] [大拇指]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5fc48e25b899a90147dd0ff716950a7b0008f578.jpg) 
不过按照惯例，我还是把磁盘检查补上[滑稽]
不过我不得不提一下，Mac OS 9的字体渲染和谐多了[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/20ad422cd42a28340a8e67ca50b5c9ea14cebf38.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/65d9b32b2834349b3c2e3f44c2ea15ce37d3be38.jpg) 
Sherlock的变化倒真是挺大的[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/94de4f35349b033b1ba0ad1b1ece36d3d439bd38.jpg) 
***
IE倒还是4.5，不过不闪退了[滑稽]
看了下，变化倒也只有这些，其他的变化都不大。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c13f5edab6fd526615ec6fd5a018972bd6073625.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/792fd1fc5266d016cfdecde99c2bd40737fa3525.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f6093567d01609246ce2f1dadf0735fae4cd3425.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1292b7170924ab185fd1b2f63efae6cd79890b25.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90e26e25ab18972b1dfd530bedcd7b899c510a25.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/49d0cc19972bd407ff00803c70899e510db30925.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ebecf02ad40735fa2d371d7895510fb30d240825.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d7dfb30635fae6cdb773f8a004b30f2440a70f25.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/94f352fbe6cd7b8953ab6942042442a7db330e25.jpg) 
***
并且值得一提的是，Mac OS 9加了一堆主题[滑稽] [大拇指]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1292b7170924ab185007b3f63efae6cd79890bd7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90e26e25ab18972b1c2b520bedcd7b899c510ad7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/49d0cc19972bd407fcd6813c70899e510db309d7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ebecf02ad40735fa2ce11c7895510fb30d2408d7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d7dfb30635fae6cdb0a5f9a004b30f2440a70fd7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/94f352fbe6cd7b89527d6842042442a7db330ed7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/750e81cc7b899e51c29f68d549a7d933ca950dd7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a6391c889e510fb3c1082556d233c895d3430cd7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b7df9500fb30f248d8bbec2c395d143af4b03d7.jpg) 
***
补楼上[滑稽]
***
打算开更Classic最后一个版本了[滑稽]
不@人
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7b08cf91a4c510fc30b55db6b59252dd62aa51d.jpg) 
先补上OS 9.0.4的关于电脑[滑稽]
***
lz可能得去吃饭了，等下回来[滑稽]
终于有时间更了......
不@人，真没时间[泪]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3304e5035aafa40fb342b31fa064034f7af01965.jpg) 
开机......没什么大问题。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c2f63daea40f4bfb0254e396084f78f0f5361865.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1a5bc30e4bfbfbed51dd4bbd73f0f736adc31f65.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e4fb2cfafbedab64f8f63002fc36afc37b311e65.jpg) 
不过打开之后我们可以发现，这是个恢复盘！
但是，可以注意到的是，恢复盘其实是一个大镜像[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0b0f9cecab64034f8449bfc4a4c3793108551d65.jpg) 
所以，我们用Disk Copy就能解决这个问题[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bb19cc65034f78f00a8fe73172310a55b1191c65.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/eb90644e78f0f736517a31c30155b319e9c41365.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/43bb1ff1f736afc3868842a7b819ebc4b5451265.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/38049037afc379310aeffbebe0c4b74541a91165.jpg) 
就像这样，挂载，然后丢到目标磁盘里，就可以实现曲线救国[滑稽]
完后拔盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7b08cf91a4c510f8ad09ed86b59252dd62aa5d5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ab0c7d4d510fd9f9830329ab2e2dd42a2a34a4d5.jpg) 
这里报了个错，然后就没什么大问题了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5ab8360ed9f9d72a35706cdfdf2a2834369bbbd5.jpg) 
成功使用恢复盘曲线救国[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b7df9500fb30f24af1e90c1c395d143af4b0365.jpg) 
这里有个AirPort，但是硬件不允许......
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dea568b20f2442a7378a8167da43ad4bd3130265.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4f47682542a7d933272c98b1a64bd11371f00165.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4fd025a6d933c89521fae4b9da1373f080020065.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0253be32c895d1435cf298e178f0820258af0765.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4b23aa3a0289025aafa60f0665.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd1138049cbf051afa40f49fb0565.jpg) 
新增钥匙串好评[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91b7ca4ad11373f076bb135daf0f4bfbf9ed0465.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202af16edfd40fbfbeda9641b65.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91e714f182025aaf52b60209f0edab64014f1a65.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2ef27a940a7b02085328432369d9f2d3552cc800.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5d616d7a02087bf4230d2b2bf9d3572c13dfcf00.jpg) 
IE4.5貌似是Classic环境最后一个预装的IE版本了......
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4a8f65097bf40ad14805bb215c2c11dfabecce00.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/42fc1cf50ad162d9d90f1ede1adfa9ec8813cd00.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b006dd062d9f2d37bf0582da2ec8a136127cc00.jpg) 
Mac OS 9.0.4到这里就结束了[滑稽] [玫瑰]
***
昨天晚上花都没撒我就被我妈叫去睡觉了......[狂汗]今天找个时间更OS X[滑稽]
开更！[滑稽]
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
先放一波OS X/macOS更新列表[滑稽]（感觉我放不放这个都一样的说
PowerPC篇
=======================
***
Mac OS X Public Beta
OS X 10.0(Cheetah)
OS X 10.1(Puma)
OS X 10.2(Jaguar)
OS X 10.3(Panther)
OS X 10.4(Tiger)
***
Intel篇
=======================
OS X 10.5(Leopard)
OS X 10.6(Snow Leopard)
OS X 10.7(Lion)
OS X 10.8(Montain Lion)
***
OS X 10.9(Mavericks)
OS X 10.10(Yosemite)
OS X 10.11(El Captain)
***
macOS 10.12(Sierra)
macOS 10.13(High Sierra)
***
下面先更Public Beta吧[滑稽]
这是苹果首个向公众发布的OS X，定价$29.95（乔帮主还真会坑钱），旨在给开发者和极客们看看全新的系统长什么样[阴险]
这是苹果首次向公众发布Aqua DE和Darwin内核，所以名义上这才是OS X的首个发行版本[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/eb90644e78f0f7368b635bc20155b319e9c4134c.jpg) 
我使用事先备好的脚本启动QEMU[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/43bb1ff1f736afc35c9128a6b819ebc4b545124c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/38049037afc379312cf591eae0c4b74541a9114c.jpg) 
鬼畜的Happy Mac......
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b7c2c8c279310a5594b9c937bc4543a98026104c.jpg) 
可见这里还是有一些OS 9的痕迹的[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ef371e300a55b319c36495b648a98226cdfc174c.jpg) 
苹果菜单中置......这应该是Public Beta最大的一个特点[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c6ec517bdab44aed15b4a827b81c8701a38bfb74.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/768ebdb54aed2e73b71390ef8c01a18b85d6fa74.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9a402dec2e738bd48edba4f2aa8b87d6257ff974.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0a1949728bd4b31cb9c682788cd6277f9c2ff874.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6e87ecd5b31c87019e4ca4252c7f9e2f0508ff74.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cb20d41d8701a18bc711048c952f07082a38fe74.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3e8e000a18b87d666b8bddc0c0828381d30fd74.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7f5c68a87d6277fdce824fb23381f30eb24fc74.jpg) 
安装程序的思路还是一样的，但是漂亮多了[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e17fe0d7277f9e2f44cf0bcb1430e924ba99f374.jpg) 
pppppp......panic?!!!!!
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dedb600928381f30ad389d6aa2014c086c06f0c1.jpg) 
***
仔细看了下，Macintosh Garden上还有个ReadMe，里面提到了这货居然有个时间炸弹......
如果要改时间的话，需要一个已经存在的OS X才可以调时间[喷]
所以你们打算先看10.0呢，还是我补更一个Mac OS 9.2.2呢[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dea568b20f2442a7d6f6e066da43ad4bd3130269.jpg) 
所以我将实体机时间调了，不知道行不行[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edc03e83b2b7d0a299ee1b5ec0ef760949369ac7.jpg) 
***
成功！[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91fdd4df9c82d15800db47728b0a19d8be3e4289.jpg) 
***
完结撒花，拔盘开机[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/191a5a6c55fbb2fb1a8241d1444a20a44423dcb9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7d9932fab2fb431637b663b92ba446230bf7d3b9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/150fd5fa43166d2214de0c574d2309f79252d2b9.jpg) 
这一切都很鬼畜啊......我有点方，就如同我第一次看到Vista三点一样😂
***
我打算拔掉网络再来一遍，因为我这个是有网卡驱动的......
现在我正在手机上发帖，完后我会插上发帖的[滑稽] [勉强]
***
现在我就有点迷惑了.......
这Public Beta卡在199楼的最后一张图了，并且一直没有反应......
我需要帮助啊wwwww
***
http://tieba.baidu.com/p/5531461445
先给各位来一发Rhapsody，过两天再弄Public Beta[勉强]
不@人
***
经过慎重考虑，接下来，是时候请出我的PowerBook G4了[滑稽]
接下来我将会开更实体机Special[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2c75e70b19d8bc3e8b11f2dd8e8ba61ea9d34585.jpg)
***
Special列表：
Mac OS 9
==========
9.2.2
9.2.2 CHS
***
OS X
==========
10.2.1
10.3
10.4.6
10.5.4
***
所以，我们先刻盘[滑稽]
先征集一下，你们想先看嘤glish呢，还是CHS呢[滑稽] [茶杯]
***
开始刻了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/07e4de13c8fcc3ce8c5735249e45d688d53f2003.jpg)
***
噩耗来了[不高兴]
我现在为了刻盘费了4张CD-R，同时我家路由器也坏了[阴险] [怒] [不高兴]
我再尝试一下，如果不行可能就只有下周另找办法了[泪] [不高兴] [阴险] [心碎]
***
预告一下，今天晚上我有机会更贴[滑稽]
到时候还有专门的恢复盘评测，这个得等我把DVD买来了再说[滑稽]（我家没有DVD
——来自学校信息技术教师的i3-6100[滑稽]
***
各位我又回来啦[滑稽]
之前折腾了半天OS 9，感觉实在有点难度，同时手头没有DVD也用不了恢复盘[不高兴]，我就先更10.3吧[滑稽]
***
由于我不能在手机上在图片之间插入文字，所以各位看官就直接看吧[勉强]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/65ebf2cbd1c8a7866c1c1c116b09c93d71cf50f4.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a7e5f7ee76c6a7efb917fe39f1faaf51f2de66f5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7a738e51352ac65c5b7d306cf7f2b21192138aae.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/09a06e22dd54564e1c55b226bfde9c82d0584ff6.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b1833e636d12f2ed436f87f43c2d562843568f7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6fdade399b504fc2a525e61ae9dde71191ef6da8.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/11fbbef8d72a60591e65b7052434349b023bbaa9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0a649102738da977cb02d034bc51f8198718e3f2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bd0ec850f3deb48ff145f7c1fc1f3a292cf578f2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d0a6ff23720e0cf3fcd818e40646f21fbf09aaf3.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5d616d7a02087bf4044601f6fed3572c10dfcf78.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/112ee6ca39dbb6fd94f1b3390524ab18962b3778.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d7fe574f251f95ca729fc4a9c5177f3e660952b8.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/745c39de8db1cb13c30c6a0cd154564e93584bb9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/97de0758252dd42a156d57b40f3b5bb5c8eab8ba.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/112ee6ca39dbb6fd94fcb3390524ab18962b377b.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d9d1db305c6034a8d944ee9ec713495408237604.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6e29c4cd7cd98d1065f55d2e2d3fb80e7aec9085.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2ef27a940a7b0208761469fe6ed9f2d3552cc8c1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ca76de004a90f603836dca583512b31bb251edc2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ed9abac551da81cbfd3ad5d25e66d0160b2431c2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9d3036db81cb39db731f3149dc160924a91830c3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91acabbe6c81800a8f3bdf11bd3533fa808b47cc.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/86a877395343fbf2ff30f73cbc7eca8064388f82.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3304e5035aafa40f971f98c2a764034f7af019cd.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202804ac72047fbfbeda9641bce.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/47fc4f391f30e924be7eca2e40086e061f95f7c8.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7b08cf91a4c510fee12b3056c59252dd62aa5d4.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a7e5f7ee76c6a7efbb34f839f1faaf51f2de6690.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5b21ca6fddc451da43245df4bafd5266d21632d0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/49d7ba55564e92585ff9d7f19082d158cebf4ed1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7b33f83cf8dcd1001699a83e7e8b4710b8122f99.jpg)
***
先到这里，各位还想看什么，欢迎此楼评论[滑稽]
lz先去写作业去了[滑稽]
***
预告:明天我DVD会到，所以同时整理更新9.2.2破解+10.2.1[滑稽] [捂嘴笑]
开更[滑稽]
手机端不好@人就算了[滑稽]
核能预警:前方全程由手机进行记录，请自备护目镜 [捂嘴笑]
***
开机，推入光盘，按下C键，就能看到Happy Mac[滑稽]
启动除了9.2之外和其他OS 9没有区别[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f08aad8165380cd7c7eaf69aad44ad345b8281c2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b2ebd9086b63f6245fef6d748b44ebf81b4ca308.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/27fdae3c70cf3bc732b2999bdd00baa1cc112a08.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0b0f9cecab64034f9a3a9671a3c3793108551dc3.jpg)
***
启动之后，由于ROM版本的原因，分辨率会降至640*480
不用担心，我们等会就能解决这个问题[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1292b7170924ab185c42b64039fae6cd7a890b62.jpg)
***
由于这是Power Mac G4 QuickSilver的Software Install膜改而成，我们先要破解机型限制[滑稽]
将整个光盘的内容复制到另一个磁盘（我这里是HFS+的U盘），再将/软件安装程序/升级程序文件下的Welcome文件替换同目录下的IncompatHW，即可正常进行安装[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4f47682542a7d9331bb8b504a14bd11372f001ae.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f6f45df23a87e9507d04a21b1c385343faf2b4af.jpg)
***
在格式化磁盘后，我们就可以开始安装了[滑稽]
安装程序的区别可以说是基本没有，除了中文
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/70ba421e95cad1c8058eac50733e6709c83d5181.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/22249002918fa0ec10f3347a2a9759ee3c6ddb82.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/89c917ce3bc79f3d5298b447b6a1cd11738b2945.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/22249002918fa0ec10bf347a2a9759ee3c6ddb46.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/01c0f00b304e251f35c0b48fab86c9177e3e5383.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b3f6d47f21fbe094568936367600c338644ad8c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2c75e70b19d8bc3e277356bd8e8ba61ea9d34547.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cb20d41d8701a18b7add4238922f07082938fe8d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6d0187ff9925bc31df2751ef52df8db1ca137040.jpg)
***
安装过程中有两个包没装上，没关系，手动补[滑稽]
反正都是在软件安装程序里的[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/17d876dea9ec8a136cd40b97fb03918fa2ecc0f4.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/36fd2c37acaf2eddff7a159e811001e938019337.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9d3036db81cb39db094b3b21dc160924aa183037.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d3e7d77fca8065384123f8649bdda144af3482f5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/65ebf2cbd1c8a78656a016796b09c93d71cf5030.jpg)
***
下面就是我们破解的时间了[滑稽]
首先我们要把较新的ROM（我的最低9.7.1）替换到硬盘上的系统文件夹中[滑稽]
我的ROM提取自我恢复盘恢复的OS 9英文[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1976d5b6d0a20cf460e1a5a87a094b36adaf994d.jpg)
***
同时为了解决睡眠问题，我们还要把较新的ATI显卡扩展（如果是N卡那就是N扩展）丢进硬盘里[滑稽]
这个时候就可以重启了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/49d7ba55564e9258533dc3999082d158cdbf4eb5.jpg)
***
重新启动，听一声悦耳的Duang，我们就会发现主题已经成了默认的灰色Quantum Foam[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/50cc3442fbf2b211d1cbc039c68065380ed78ed1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8a7402390cd79123d0fbd003a1345982b3b780a7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1976d5b6d0a20cf47e74bba87a094b36aeaf99d2.jpg)
***
启动就给我很积极地蹦出两个设置 
话说苹果当年用15' 1280*854的3:2屏幕可以说是真的很有勇气了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4a2505d8f2d3572c128cdbab8613632763d0c354.jpg)
***
终于能够成功走完一遍设置助理而不报错了[滑稽]
其实就是OOBE，也没有什么大的差别[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/92ef69f51bd5ad6e6f01239d8dcb39dbb4fd3cc6.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bb06d5109313b07e8b81167f00d7912396dd8cfa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d1d7f0dca144ad341045c0f0dca20cf433ad85c0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/47fc4f391f30e9244f5edb4640086e061f95f7c1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e8279a1e4134970aa186575899cad1c8a5865dc1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/92ef69f51bd5ad6e6cc2229d8dcb39dbb7fd3c87.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e8279a1e4134970aa04a565899cad1c8a6865d85.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1c9453a95edf8db1b1d93b130523dd54544e74c3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/03e20a234f4a20a450e87bb09c529822700ed0cc.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9da0314f9258d10933d8efc5dd58ccbf6d814d87.jpg)
***
值得一提的还有这个AirPort设置助理
由于网卡的局限性，现在有密码的WiFi这机子都不能连接，于是就出现了密码错误的这种蛇皮提示[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1a5bc30e4bfbfbed66f5770874f0f736aec31f0a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fccad63433fa828b2c5edc94f11f4134960a5ab9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ca76de004a90f603ac1fdd303512b31bb151ed14.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2c75e70b19d8bc3e367447bd8e8ba61ea9d345ba.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7b08cf91a4c510ffe6da36d6c59252dd52aa515.jpg)
***
值得一提的还有随光盘送的iTunes[滑稽]
这是唯一一个能在OS 9上播放正常MP3的播放器，同时作为随盘程序，我觉得还是可以看一下的[滑稽]
***
安装程序在光盘的应用文件夹中[滑稽]
安装程序倒没什么亮点[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f243b7a30cf431ad8167004e4736acaf2fdd9801.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6e87ecd5b31c87014a03f1912b7f9e2f0608ff02.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bd0ec850f3deb48fe6dde2a9fc1f3a292cf57802.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/50cc3442fbf2b211afcbc639c68065380ed78ed1.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/678bf92e07082838eee89f63b499a9014e08f1d2.jpg)
***
重启打开后会有一个简单的设置[滑稽]然后就能开始BOOM了
界面很Brushed Metal，很OS X，但仍是原生OS 9应用，可见当时苹果有多嫌弃Platinum
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8b1b11084b36acaf6245db8b70d98d1000e99c11.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fefd0c62f6246b6012aaff03e7f81a4c500fa212.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/750e81cc7b899e51b42a77634ea7d933c9950d12.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4c0056accbef76090190d4e822dda3cc7dd99e27.jpg)
***
最后来一张关于本机，今天就到这里了[滑稽]
明天还有点作业要处理，完后便可更10.2.1[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c0fe7ed9bc3eb135b076fbccaa1ea8d3fc1f440d.jpg)
***
开更！[滑稽] 
@焊锡补牙 @VistaWithSP2 @r216571tyq @redapple0204 @呵呵韩国观光饭
***
今天更一波10.2.1和10.2.8[滑稽]
插盘，开机按下C，就可以从光盘启动[滑稽]
这里我使用的是恢复盘进行的安装，值得一提的是苹果自10.2开始就砍掉了Happy Mac[喷]
界面和之前的Cheetah和Puma基本没有区别的，所以基本可以看作一个版本[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6e87ecd5b31c87015111f69e2b7f9e2f0608ff1d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5ab8360ed9f9d72a4cd05465d82a2834359bbb03.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5fc48e25b899a901b6931f4e11950a7b0308f51e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a529801090ef76c6cf73bf539116fdfaae51671e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/112ee6ca39dbb6fdeaeca15e0524ab18962b370c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/95cdd1013af33a87d3db4462ca5c10385243b50d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cae7042662d0f7039b2fd1a404fa513d2797c51a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/13b79cf3b2119313f2f2bbc869380cd790238d0e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bb06d5109313b07e891f147000d7912396dd8c19.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b6f7148ca97739125684c119f4198618377ae21a.jpg)
***
补楼上的图[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edc03e83b2b7d0a2414440e5c7ef76094a369a2a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ca76de004a90f6039169d83f3512b31bb251ede7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9596e234e5dde711f60a078eabefce1b9f1661e7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/327f2011b912c8fc66edb1b5f0039245d78821a5.jpg)
***
不忘叫你注册之后就能进桌面了[真棒]
真的.......Aqua不知道比XP的Luna高到哪里去了，乔布斯做UI也很有一套[滑稽]
先来一张版本信息[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f6f45df23a87e9500c42b5141c385343faf2b462.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c6ec517bdab44aedc41bf89cbf1c8701a08bfb63.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d7dfb30635fae6cdc51aed1903b30f2443a70f15.jpg)
***
此时OS 9并没有被干掉，而是变成了Classic继续在OS X中xu了4年的命[滑稽]（Classic自Leopard被砍）
其实这就是一个由苹果官方出品的的融合模式，深度适配架构和流畅度，运行起来丝毫感觉不出这东西是个基于硬盘原有系统的""虚拟机"
***
同时，也能从启动磁盘处更改顺序启动至OS 9[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/913cc087c9177f3ef1f7bd757ccf3bc79d3d56f8.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b828b601baa1cd11ed173358b512c8fcc2ce2d1e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e6eacfd2fd1f413419f54406291f95cad3c85ef9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4ab2951ebe096b63e9241e2800338744eaf8acfa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d8d6150f0cf3d7ca60557e0efe1fbe096a63a918.jpg)
***
下面来讲一下应用[滑稽]
苹果自OS X之时就推出了iLife套件和一堆配套应用，同时由于众超级给力的开发者，OS X才得以获得如此成功
这都是些小工具，倒没什么好说的
不过值得一提的是，苹果在后来的Aqua中还加入了一个""Brushed Metal"
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cb20d41d8701a18b6b295137922f07082a38fefa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/79f5463eb80e7bec03344099232eb93899506bd5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6d0187ff9925bc312eb242e052df8db1c91370d4.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/43cf3cb4c9ea15ce19d2a271ba003af33b87b2fb.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/13b79cf3b21193138dadbcc869380cd793238dd5.jpg)
***
IE5的百度梦
在Panther中苹果才正式基于KHTML开发了Safari，不过IE一直作为友(shang)情(ye)捆绑陪着OS X走到了Tiger[喷]
现在这个IE5.2已经不能滋磁所有新HTTPS网页了，不过看看还是能看的，虽然说锯齿感人[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b32ad38e8c5494ee9bda4d6121f5e0fe9b257ec7.jpg)
***
下面着重讲一下iLife[滑稽]
首先是iCal和iPhoto，分别是日历和图片，亮点倒不算太大
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ed9abac551da81cb9684ceb55e66d01608243159.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d0a6ff23720e0cf3c1aa03830646f21fbf09aa5a.jpg)
***
下面是iMovie和iTunes[滑稽]
iMovie的效果和Windows Movie Maker的五毛特效有得一拼，在此就不多说了
关键是这个iTunes......除了加入了OS X兼容外和2.0.3基本没有区别好不好[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ebecf02ad40735fa514002c192510fb30e24080f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2dd6284b20a44623192ee91a9422720e0ef3d7d3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cca0f3eff01f3a29462c99b69525bc315e607cd3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4aa1d418ebc4b7459170fb6ec3fc1e17888215d3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5ab8360ed9f9d72a44835c65d82a2834369bbbdc.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f32afb83d158ccbf125bf94215d8bc3eb33541dc.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90e26e25ab18972b61884cb2eacd7b899f510a09.jpg)
***
附上两个版本的对比图[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1c9453a95edf8db1b8fb301c0523dd54544e74e2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/17d876dea9ec8a139ccf1b98fb03918fa2ecc0e3.jpg)
***
貌似网络不稳漏图了......
把前面的OOBE补上来[勉强]
本来是有个视频的，我看怎么提取出来传波度盘[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edc03e83b2b7d0a24ef24de5c7ef76094a369a80.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3fca0008c93d70cfaac1e375f4dcd100bba12b80.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3304e5035aafa40f8f0f80a5a764034f7af019f6.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/90566bf531adcbef330e377ea0af2edda2cc9f81.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7b33f83cf8dcd1002fa6b1597e8b4710b8122f81.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e4fb2cfafbedab64c4ba03b8fb36afc37b311ef7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d8d6150f0cf3d7ca6f3d710efe1fbe096963a9f0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1e2beab0cb1349547ad5a61c5a4e9258d3094af0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d7dfb30635fae6cdcd7fe51903b30f2440a70ff0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e0186ffb513d26975c19462559fbb2fb4116d8f1.jpg)
***
lz先去洗个澡，马上回来
著名大播放器QuickTime[滑稽]
一上来就给我推销Pro是几个意思[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2b9791256b600c3387fd7cb0164c510fd8f9a133.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/cd45ac124954092385edc1069e58d109b2de4933.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8a7402390cd79123b649360ca1345982b3b78016.jpg)
***
这里还有文本编辑和搜索，不过Sherlock打不开是几个意思[喷]
至于下面的文本编辑......MacWrite的重孙[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7f5c68a87d6277f52b09f4024381f30e824fc1a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b8ede119367adab48e60b63b87d4b31c8601e408.jpg)
***
实用工具大概也就是从发布之初就一直没变过的小工具，故此不再多说
偷偷走一波配置[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1292b7170924ab18035b4d4f39fae6cd7a890b6a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/97de0758252dd42a2f45add30f3b5bb5c8eab86b.jpg)
***
下面大概介绍一下这个Combined更新包[滑稽]
这东西类似于Windows的更新合辑，一打就是一堆补丁[滑稽]
和Windows一样，离线包都是Installer安装
偷偷告诉你苹果现在还开放10.4.11 Combo包的下载
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7a075d86e950352ad5278a705f43fbf2b3118b7d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b6f7148ca97739120ffe2a19f4198618347ae2e0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4c0056accbef7609634a36e722dda3cc7dd99e7e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd113d216184a56afa40f49fb05e0.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ab0c7d4d510fd9f9d557fa11292dd42a2934a47f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fa55aa10728b4710c26f52b4cfcec3fdfd03237f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/553a51d2d539b600351ba0cfe550352ac45cb7e2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/303b5cc69f3df8dca7e820e9c111728b451028e2.jpg)
***
一个超级不幸的消息，我屏轴裂了[阴险]
不过没有花屏[阴险]
众所周知TiBook由于设计问题，屏轴是外置，塑料制成，老化过后很容易断，且一边裂了还会导致另一边裂开，让整个屏幕报废
下周用热熔胶救一下，看能不能搞定
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/dea568b20f2442a74ea057dddd43ad4bd0130215.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/17d876dea9ec8a13bab4fd98fb03918fa1ecc016.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/411d5e00213fb80e5678cbaf3ad12f2eb8389416.jpg)
***
明天我已经预约好了和Genius Bar的面刚♂，所以今天我先发一波OS X Public Beta吧[滑稽]
事实上前几次的问题都是因为BIOS时间，使用-rtc参数就可以更改BIOS时间拆掉炸弹[滑稽]
所以最终命令如下[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/9596e234e5dde711f715068babefce1b9f1661f9.jpg) 
***
不过我实在不理解的是，为什么苹果要给一个居然要付费的Beta设炸弹......
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b6d00c610c338744cd8968015d0fd9f9d62aa070.jpg) 
Happy Mac超级鬼畜[滑稽] [弱] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/2b946b328744ebf83d3d2342d5f9d72a6159a770.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4cc7e045ebf81a4c797eabb4db2a6059242da670.jpg) 
事实上，这个苹果标根本就是个装饰[阴险] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c7b08cf91a4c510ff088a5676c59252dd52aa570.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ab0c7d4d510fd9f9fd5b1214292dd42a2934a470.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5ab8360ed9f9d72a4b285760d82a2834359bbb70.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/11fbbef8d72a6059095ca6672434349b023bba70.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/990db02b6059252df95b5a79389b033b5ab5b970.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/97de0758252dd42a064546d60f3b5bb5c8eab870.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/20ad422cd42a28341bea717657b5c9ea14cebf70.jpg) 
安装程序一直到10.2都没变过[阴险]到10.3和10.4只换了个背景图[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/745c39de8db1cb1333027a6ed154564e93584b5d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3efd750f8198618de16a8f946ed2e738ad4e674.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e3381bd88d1001e96e595372b40e7bec55e7975f.jpg) 
可以发现此处进度条下的字体仍然是OS 9默认样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b32ad38e8c5494ee8088486421f5e0fe98257e1e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/411d5e00213fb80e218126aa3ad12f2eb8389474.jpg) 
事实上，这个Assistant的样式基本就是Classic Mac OS的Assistant加上Aqua设计而已[阴险] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0a649102738da977da4ac156bc51f8198718e358.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ec5b49dca3cc7cd9d87d73a43501213fb90e9174.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/792fd1fc5266d016b07cd9559b2bd40734fa355f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ca76de004a90f60392d5db3a3512b31bb151ed58.jpg) 
这里的Email其实可以跳过，并且在后面的版本中被砍掉了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/d53eb6c9a786c917e8531544c53d70cf3ac75774.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/bb19cc65034f78f02683dc8e75310a55b2191c3c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/eb90644e78f0f7367d760a7c0655b319eac4133c.jpg) 
补楼上[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f9f52d91f603738d610fb55fbf1bb051f919ec78.jpg) 
又一zz设计：OOBE完后重启
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0a649102738da977f06a3f56bc51f8198718e378.jpg) 
这里仍然是浓浓的BSD味道，参见我的Rhapsody教程[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b6f7148ca977391279633c1cf4198618377ae278.jpg) 
这里可以看到有好多应用仍然没有开发完全，包括设置[阴险] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3379ce763912b31b7b2974548a18367adbb4e178.jpg) 
并且Public Beta是真的没有苹果菜单，后来苹果菜单的内容现在在Finder中[喷] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e9835e13b31bb05134610a553a7adab44bede078.jpg) 
此时Finder的名字还没有出现在顶栏上，所以关于页面也还是Mac标[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/79e6d41ab051f8194b60ba37d6b44aed2f73e778.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f3efd750f8198618f80256f946ed2e738ad4e678.jpg) 
可以看到其实整个系统都Aqua化了，这点倒是要好评[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f0a59f188618367a15ccc6a022738bd4b21ce578.jpg) 
Classic此时还是一个单独的应用[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/b8ede119367adab49a95a23e87d4b31c8601e478.jpg) 
神奇的GrabBag，在后来的版本就消失了这个目录了，这些应用也都被移出来了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c6ec517bdab44aedff0b0799bf1c8701a08bfb78.jpg) 
Key Caps仍然Carbon化差评[阴险]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4fd025a6d933c8957a872006dd1373f0800200c3.jpg) 
此时iTunes还没有被预装（
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0253be32c895d143018f5c5e7ff0820258af07c3.jpg) 
这里仍然是拨号连接，浓浓的时代感啊[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4b7cd7febd8e025aafa60f06c3.jpg) 
例行推销QuickTime Pro（
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd113dd340f4f56afa40f49fb05c3.jpg) 
Brushed Metal吼评[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91b7ca4ad11373f02dc6d7e2a80f4bfbf9ed04c3.jpg) 
如果尝试打开设置的话，就会提示错误[喷] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202ea6b294247fbfbeda9641bc3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/91e714f182025aaf15cbc6b6f7edab64014f1ac3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3304e5035aafa40ff93f76a0a764034f7af019c3.jpg) 
此时的IE同样也是Beta，图标差评[喷] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c2f63daea40f4bfb482926290f4f78f0f53618c3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1a5bc30e4bfbfbed1fa08e0274f0f736adc31fc3.jpg) 
不知道苹果是怎么想的，把关机设在注销的旁边，还得通过注销进入[喷]
Public Beta，完[滑稽] [玫瑰]
***
插一波拆机
现在有点被卡住，得把那个屏幕周围的塑料框抬起来一点，才能用热熔胶弄好[滑稽]
祝我好运[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0b0f9cecab64034f9741a367a3c379310b551d3c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/5b21ca6fddc451da53b86d8abafd5266d116327e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/03e20a234f4a20a472575da69c529822730ed07f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f6093567d016092473aac37ad80735fae7cd343d.jpg)
***
啊都已经一个月过去了啊......
为避免撤精我来顶一下
这次高考放假，我会忍痛更完实机番外+ppc Mac OS X，敬请期待[滑稽]
***
好了简单开更10.3[滑稽]
懒得@人
***
其实Panther的改动并不大，可能仅仅是窗口栏的改变以及Safari的加入。
先上安装过程[滑稽]
升级程序还是Jaguar样式差评[阴险]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/89e3183f6709c93dba5f7977933df8dcd30054f2.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e772ae167f3e670900ac327f37c79f3dfadc55f3.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/f9e6affdc3cec3fd2b91d0f5da88d43f859427fc.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/c722407e9e2f07080cac5d80e524b899ab01f2fe.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/1c9453a95edf8db161530be40523dd54574e7422.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/745c39de8db1cb13e2154b93d154564e93584b23.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3b1833e636d12f2e377ad9e043c2d5628435682c.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4a2505d8f2d3572c2247eb5c8613632760d0c3fa.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/86a877395343fbf2dd55d1a3bc7eca8064388f2e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/8861b642ad4bd1138a69c0b256afa40f49fb05fb.jpg)
***
值得一提的是，由于Panther是使用3张CD进行的安装(虽然Jaguar也有CD版且Panther也有DVD)，在这里就能看到换盘提示[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/592cdb3fb13533fa38cae5aea4d3fd1f40345b23.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fefd0c62f6246b605f78c4f4e7f81a4c500fa235.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6fdade399b504fc24521c685e9dde71191ef6d2d.jpg)
***
由于这次是升级安装，OOBE并没有填很多信息就完了[滑稽]
完整过程在前面楼层[滑稽]
先上关于版本[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/47fc4f391f30e9249d94edb140086e061c95f777.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/3632c0eece1b9d1665f7ebe1ffdeb48f8d546477.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202a3a2e0bf47fbfbedaa641b77.jpg)
***
首先讲讲Finder[滑稽]
这次Finder加入了侧栏，且最后换上了Brushed Metal的皮肤，基本已经定了型。
当然比现代macOS更细的个人文件夹分类还是需要好评一下的[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/4aa1d418ebc4b7454471c696c3fc1e17888215b9.jpg)
***
同时最大的更新就是Safari了[滑稽]
事实上在Mac OS X发布之后，IE for Mac就一直没有得到M$很好的支持，所以苹果就基于KHTML开发了新的Safari。
对于浏览器内核我觉得没有必要多做评价(你看看这里的百度)，但是界面真的要好太多了好吗!
真的，讲究
事实上Safari这一发布也基本定了后面版本的型。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/ab0c7d4d510fd9f980f025e9292dd42a2a34a444.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/6050212209f79052dedf37be00f3d7ca79cbd567.jpg)
***
同时变化比较大的应该iMovie，iPhoto和iTunes了。
iMovie终于摆脱了OS 9的阴影，做成了一个窗口......整体观感还是不错的。
iPhoto这次的重新设计多引入了几个入口，更加整体化。
而iTunes......就改了个关于[汗]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/e1b0ca355982b2b7a7444a443dadcbef74099b48.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0bc2cbae2edda3ccfc3ecba00de93901233f9249.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/fcc53b6134a85edf28248da345540923df5475ff.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/89c917ce3bc79f3d313597b0b6a1cd11708b294b.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/edbfb61273f08202ad38e2bf47fbfbeda9641bf9.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/99c7af94d143ad4b221e34408e025aafa50f0677.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/0cfc09071d950a7b2be43d4406d162d9f0d3c956.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/a529801090ef76c635e089ab9116fdfaae516771.jpg)
***
其实这次软件更新也有变化，只是10.3的更新服务器也被关了......故不再尝试。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5505567339/7a738e51352ac65c76051bf3f7f2b21192138a27.jpg)
***
其实到这里Panther的新功能就介绍的差不多了，完结撒花[滑稽] [玫瑰]
我会重点介绍一下Leopard，因为其功能更新实在太多，可以说是现代macOS的最后一次定型[滑稽]
同样，也会讲讲如何使用Open Firmware从USB启动安装程序[滑稽]仍记得上次我这么尝试要了我4个小时装完[喷]
***
楼主Tiger和Leopard的番外素材回来了[滑稽]
之前因XZP被家长收走而拖更了四个多月[勉强]
