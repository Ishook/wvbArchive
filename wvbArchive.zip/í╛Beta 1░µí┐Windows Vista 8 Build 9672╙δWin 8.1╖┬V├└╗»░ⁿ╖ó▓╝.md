![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/f47beb5594eef01fb717746be9fe9925bd317d16.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/1b41aeeb15ce36d3a237859e33f33a87e850b166.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/cca0f3eff01f3a29a3cbb9609025bc315d607c16.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/d41a971e3a292df56fc0c0bbb5315c6035a87316.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/b0eb5d282df5e0fe091be5af556034a85fdf7216.jpg)
相对于Win8.1原版的改进与变化：
1.加入Vista拟物元素主题【为默认主题】
2.加入RP主题，与Vista拟物主题共存
3.加入Aero Glass，来自8400的千里相约
4.加入评分机制，最高分数9.9
5.加入侧边栏
6.加入桌面小游戏【已包括墨球】
7.加入梦幻桌面
8.加入Vista屏保
9.加入媒体中心
10.加入微软拼音新体验2012
11.加入7z压缩软件16.04
12.加入Windows Live Mail
13.加入功能强大的照片库和影音制作
14.全新的绿色文件夹图标
15.网络图标更改为Vista式
16.Ribbon变为8250样式
17.开始屏幕改为不违和的黑色背景
18.采用清新的9431默认壁纸
19.注册表编辑器使用了Build 10558的图标
20.破解了第三方主题
21.默认禁止WU
22.默认使用Vista式任务栏
23.内置OldNewExplorer1.1.8.2
24.用户配置文件统一
25.关于的2013改为了2017
26.Vista式安装界面背景
相对于Milestone 4版Build 9638的改进与变化：
1.默认使用Vista式任务栏
2.用户配置文件统一
3.加入媒体中心
4.加入微软拼音新体验2012
5.加入7z压缩软件16.04
6.加入墨球(显光标)
7.加入Windows Live Mail
8.加入功能强大的照片库和影音制作
9.【激活软件】HEU换成了KMSpico
10.采用清新的9431默认壁纸
11.注册表编辑器使用了Build 10558的图标
12.关于的2013改为了2017
13.开始屏幕改为不违和的黑色背景
14.Ribbon的蓝色按钮改为空格
15.首次使用ISO格式
16.Vista式安装界面背景
17.一些细节修改以及体积缩小
***
目前BUG
1.可能出现Modern 应用全崩问题
Beta 1版Build 9672iso信息
文件： Windows Vista 8 Build 9672.iso
ESD大小：2.7G
ISO大小：3.4G
展开体积：8～12G左右
修改时间：2017年2月13日，15:41:14
下载链接：链接: ![](http://pan.baidu.com/s/1qX8BzUO 密码: d8c6
***
注意事项：安装Aero的时候把两个V取消了
Win 8.1仿V美化增强包(Beta 1)
说明：可仿Vista到Windows Vista 8 Beta 1的效果
用于：Windows 8.1原版
大小：581.00M
下载链接：![](http://pan.baidu.com/s/1nu8bADr 密码：zowi
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/f2e5f412b07eca8035c56449982397dda3448355.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/4c0056accbef760916cbc43127dda3cc7ed99e55.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/06d76ef69052982254a7656ddeca7bcb0846d4f9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/792fd1fc5266d016cd11c1869e2bd40734fa350d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/c5c182dce71190ef07b4cd71c71b9d16fffa60c2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/dc76b659ccbf6c8111357346b53eb13532fa4017.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/112ee6ca39dbb6fd900dba880024ab18962b373b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/b2ebd9086b63f624450766ad8e44ebf81b4ca33f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/7a075d86e950352a807b7aa65a43fbf2b3118b7f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/13b79cf3b2119313fc32a01e6c380cd790238d24.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/68c0539a033b5bb5f4807f503fd3d539b700bc3a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/7627b238b6003af3793e83ce3c2ac65c1238b689.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/112ee6ca39dbb6fd93a3bb880024ab18952b379d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/0fbe47a5462309f7b160f4bc7b0e0cf3d6cad602.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/38049037afc37931d4d3df87e2c4b74541a911de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/95cdd1013af33a87abfe59b4cf5c10385143b586.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4983876156/d53eb6c9a786c917df930b97c03d70cf39c75785.jpg)
Windows Vista 8 Beta 2 开发目标
1.修改RP主题与拟物主题
2.新的开始菜单和按钮
3.深度修改win8的安装界面
顶
