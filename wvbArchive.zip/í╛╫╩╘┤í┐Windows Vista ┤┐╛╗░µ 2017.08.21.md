即将开学了，在开学前为大家做了一个系统，希望大家支持；
Windows Vista 纯净版 2017.08.21
系统相关：
1.整合了截止至2017.04.11的所有补丁（xuming补丁没打）
2.整合了IE9；.Net Framework 3.5 SP1；.Net Framework 4.6;VC运行库；Silverlight；DX9；extras这些必要组件（Flash没装）
3.壁纸增加（被隐藏）；自带几张赵丽颖的壁纸；添加了Vista Beta 2主题；
4.防火墙，自动更新已经关闭；UAC开启；系统主题已破解；登陆界面更换为丽颖的；安装了柯达的影像。
5.清理了更新备份文件，韩文、日文输入法
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/553a51d2d539b600d32ff86ee350352ac45cb778.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/7627b238b6003af3d05b2bb93f2ac65c1238b678.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/95cdd1013af33a87028cf7c3cc5c10385143b578.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/f6f45df23a87e950d9f604b51a385343f9f2b478.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/7a075d86e950352a2b80d2d15943fbf2b0118b78.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/7a738e51352ac65cfee491aaf1f2b21191138a78.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/a9a4522bc65c1038bc9f391bb8119313b27e8978.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/75dea15d103853430b2e70f89913b07ec8808878.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/86a877395343fbf243cd51faba7eca8067388f78.jpg)
不足：
1.开始菜单右侧有些地方是英文（不影响使用）
感谢@星游12 所提供的更新
映像上传中……
***
补充：桌面上放置了集火工具；运行winbell，按提示操作即可。
壁纸我藏这儿了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/e4fb2cfafbedab6483cdbc19fd36afc37b311ea5.jpg)
细心点就可以找到了
***
增加的壁纸：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/bb06d5109313b07e3a35a3d106d7912395dd8c51.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/f2e5f412b07eca80948dca3e9b2397dda3448351.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/d3e7d77fca806538fe6257ca9ddda144af348251.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/f08aad8165380cd762965134ab44ad345b828151.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/8a7402390cd79123636867ada7345982b0b78051.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/25cc6bd6912397dd54f16bdd5382b2b7d2a28751.jpg)
***
@bingohuanj @孙必林 @happymax1212 and so on……
上传完成 @redapple0204 @happymax1212 @桔子大师 @孙必林 @vistawithsp2
链接:/s/1mhS6MfQ
4f74
?﹏﹏　我只守护那颗梦的冰晶
***
@bingohuanj 神精
?﹏﹏　我只守护那颗梦的冰晶
***
安装说明:
1.下载install.zip.00*，然后解压出install.wim
2.使用winntsetup或讲该install.wim替换至原版镜像安装
?﹏﹏　我只守护那颗梦的冰晶
***
@asministator @孙必林 @醉看??尘冷红颜 @bingohuanj @遗忘的我5 
?﹏﹏　我只守护那颗梦的冰晶
***
没人？
?﹏﹏　我只守护那颗梦的冰晶
***
?﹏﹏　我只守护那颗梦的冰晶
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/22249002918fa0ec2ea808d62c9759ee3f6ddbf7.jpg)
***
顶
?﹏﹏　我只守护那颗梦的冰晶
***
@zhangguhao0329 
文件名称：E:\Windows合集\sources\install.zip.001
文件大小：734003200 字节
修改时间：2017年8月21日 14:44:13
MD5 ：1E4ED8115C743283E9B8472C9D7D1F5C
SHA1 ：1C12F6677E0FC8DC004B88EC2D335EC6FD736FA3
CRC32 ：433A6160
文件名称：E:\Windows合集\sources\install.zip.002
文件大小：734003200 字节
修改时间：2017年8月21日 14:44:13
MD5 ：D79DF84D47D0C027B52DB218EC8104B3
SHA1 ：0CC25D05C7A03CFF9A08D1B9BD4B37B9AC87F762
CRC32 ：049FD95B
文件名称：E:\Windows合集\sources\install.zip.003
文件大小：734003200 字节
修改时间：2017年8月21日 14:44:13
MD5 ：CCB4E3FEB473C401618CEC662EE7B0CD
SHA1 ：781825E8F854A1D456F647C77782F0254E87B8A4
CRC32 ：B368BDFF
文件名称：E:\Windows合集\sources\install.zip.004
文件大小：734003200 字节
修改时间：2017年8月21日 14:44:13
MD5 ：A420C545755072FD3C9B0730384F429D
SHA1 ：CD4D478F5407ACD4FAB7ACE9863B2586E8C9F08F
CRC32 ：BD61955F

文件名称：E:\Windows合集\sources\install.zip.005
文件大小：734003200 字节
修改时间：2017年8月21日 14:44:13
MD5 ：296772C5F482F6AF93AC70552914618F
SHA1 ：5F2558EA8C6F10F57F84CDE2672E235A4C06A59C
CRC32 ：A400ECC7

文件名称：E:\Windows合集\sources\install.zip.006
文件大小：734003200 字节
修改时间：2017年8月21日 14:44:13
MD5 ：09B69810B8FA3568FC19E0D2A6FF6C97
SHA1 ：3C6F73FC30E01744B255AA1B3E21606C2516EB11
CRC32 ：F5F5878C
文件名称：E:\Windows合集\sources\install.zip.007
文件大小：178786447 字节
修改时间：2017年8月21日 14:44:13
MD5 ：EBE43D053A92AB670239DB1821FB7B77
SHA1 ：81D9B87CA1FC9793AC9ECD3D1D885F79F6E2717F
CRC32 ：AEE32506
不对请重新下载

文件名称：E:\Windows合集\sources\install.wim
文件大小：4824784335 字节
修改时间：2017年8月21日 11:14:28
MD5 ：32F4757C946977E9ABE3E9142E2E90A7
SHA1 ：5235095108F181BD5CB88C2BF16692D88841BD75
CRC32 ：F0485259
***
@happymax1212 问下第二阶段的壁纸怎么改，找了半天也没找到
@happymax1212 需要补充s*img.dll
?﹏﹏　我只守护那颗梦的冰晶
***
即将发布热修复补丁
?﹏﹏　我只守护那颗梦的冰晶
***
可能会修复
oobe后评分界面黑屏
β2主题部分问题
第二阶段界面问题
……
?﹏﹏　我只守护那颗梦的冰晶
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5283182615/c6ec517bdab44aed4f8376d7b81c8701a08bfb2e.jpg)
?﹏﹏　我只守护那颗梦的冰晶
***
v2.0即将发布（预计10.01测试到位后发布）
?﹏﹏　我只守护那颗梦的冰晶
***
v2.0 rc即将发布
?﹏﹏　我只守护那颗梦的冰晶
***
![](http://pan.baidu.com/s/1pLJUShd)
@醉看??尘冷红颜 @bingohuanj @cghvbnv22 @happymax1212 @什么事人 
?﹏﹏　我只守护那颗梦的冰晶
***
@遗忘的我5 @索尼大法吼?? 
?﹏﹏　我只守护那颗梦的冰晶
***
本次改进
系统优化
未精简组建
更新至17.08
有完整的iso
英文问题修复

不足 beta2主题问题未修复
?﹏﹏　我只守护那颗梦的冰晶
***
