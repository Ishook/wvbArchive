1L 百度
图：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/1b41aeeb15ce36d33ad30d1433f33a87e850b131.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/3b006dd062d9f2d3ec6cadcba0ec8a136227cc8f.jpg)
Download Link：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/ebecf02ad40735faad23939f97510fb30e24083e.jpg)
***
@史莱姆魔皇 @Longhorn4093 @VistaWithSP2 
***
控制面板（不知道如何修改）、帮助与支持（直接从Vista移植过来，替换成功，但是打不开帮助与支持，替换失败了）、运行（不知道怎么修改）、远程桌面连接（找不到在哪）
***
以上提到的程序是我不知道怎么去修改成Vista风格，所以我就不发出来我所提到的未修改的那四个程序了。
更新：
任务栏的时间恢复为Vista样式的时间；
资源管理器窗口右下角添加Vista的波浪图标；
窗口玻璃反射改成跟Vista一样的反射；
100%模仿Vista开始菜单；
开机画面改成跟Vista一样的开机画面（没截图，自己去体会）；
窗口放大化100%完全熄灯，跟Vista一样，只不过任务栏不能熄灯，win7的机制就是那么坑爹。
***
效果图在下面
效果图：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/b6f7148ca97739124d88eb60f1198618377ae27f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/3b7df9500fb30f249ffc8202c195d143ac4b0346.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/6d0187ff9925bc31cc3c6f9957df8db1ca137047.jpg)
***
Vista的复制文件动画凑数用
对了，那个资源管理器窗口右下角的那个Vista波浪，小中大的大小是跟Vista一样的，不过没有动画效果，只是个静态图片。
@史莱姆魔皇 
***
效果图：
小
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/191a5a6c55fbb2fb6a4b3313464a20a44723dc40.jpg)
中
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/5ee3ed83b9014a9001412dbca0773912b21beeae.jpg)
大
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4873281574/3b006dd062d9f2d34e484feea0ec8a136227cc4f.jpg)
