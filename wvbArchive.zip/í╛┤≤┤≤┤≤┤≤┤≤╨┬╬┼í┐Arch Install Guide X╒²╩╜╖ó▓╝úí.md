[滑稽]我从 @redapple0204 大佬下半接手了这一计划，所以，各位小白们有福利了！
一楼不放文件2333
也不放镇楼图2333
***
二楼故有领土[滑稽]
Ver 10.0 Public Beta 1
本版是X的第一个版本，相比3.0改进如下：
1.使用Pages进行完全的重新排版（PDF导出，不要方）；
2.增加了xfce，LXQt，DDE的安装说明；
3.改进了UEFI用户安装基本系统时的部分步骤；
4.增加了几个软件包；
5.增加了Noto CJK的安装说明；
已知问题：
1.我手头并没有搭载Nvidia显卡的计算机，所以我暂时无法编写Nvidia闭源驱动的相关部分；
2.gnome-extra和kde-application包组过于臃肿，正在寻找更好的软件列表；
3.我并没有完全明白winetricks-zh的使用方法，所以QQ/TIM只有Deepin版本；
4.我并没有完全明白VMware的安装处理步骤，所以并未加入VMware部分；
5.面向全吧征集Linux自毁命令[滑稽]
链接:https:/[喷]/pan.[喷]baidu[喷].com/s[滑稽]/16Tf3J7PxMQ1WOW[阴险]KrO1JECg 密码:2tyu
***
时隔一个多月，Arch Install Guide X发布第二个公众预览版！[滑稽]
相对于上个版本，本次添加/改进了：
1.将swap分区更改为swapfile的设置
2.增加了QQ/TIM的多种安装方法
3.增加了VMware的安装方法
4.默认字体更改为苹方
5.其他细节的修复和添加
仍已知的问题有：
1.未添加Nvidia闭源驱动的相关支持
2.gnome-extra和kde-application包组过于臃肿
3.面向全吧征集Linux自毁命令[滑稽]
链接:https:/[喷]/pan.[喷]baidu[喷].com/s/1[喷]KZamVv1Sj6rvTw[喷]Jhk8CSZA 密码:somy
***