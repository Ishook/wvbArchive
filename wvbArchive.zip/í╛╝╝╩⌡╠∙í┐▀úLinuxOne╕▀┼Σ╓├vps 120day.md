一楼不说话[滑稽]
电话号码，中国的也可以，而且一个号码可以验证好几次[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/f32afb83d158ccbf97bc7c6c15d8bc3eb035415e.jpg)
***
好了，到这里
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/bd0ec850f3deb48f6fdf6988fc1f3a292cf5782c.jpg)

打开你刚才注册的邮箱，查看账号密码
***
走去登陆去[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/43bb1ff1f736afc33099f733bf19ebc4b54512c0.jpg)
***
login[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/9da0314f9258d10946d462e4dd58ccbf6d814da3.jpg)
***
选择这个
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/750e81cc7b899e513a14f1424ea7d933ca950dc7.jpg)
***
新建
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/27fdae3c70cf3bc78f8006badd00baa1cf112add.jpg)
***
系统推荐选择我选的这个
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/2c75e70b19d8bc3e4cdccd9c8e8ba61eaad34582.jpg)
下面有选配置的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/411d5e00213fb80eb6e9ab813ad12f2eb83894a6.jpg)

两个配置，都是120day，我为什么要选低配置的，给我个理由[滑稽]
***
最重点的来了！！！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/91e714f182025aaf9b44b49df7edab64024f1a63.jpg)

这个key名字你自己取，一定要保管好，不然你就无法登陆VPS！！！
***
完成key新建以后，可能会卡，没有出现选择key的界面，这时退出浏览器，重新打开新建页面
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/07e4de13c8fcc3cedb3afc649e45d688d63f20e7.jpg)

新建！
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/d729c645ad34598208d2d2c500f431adcaef8406.jpg)

补3l
***
坐和放宽[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/8808a4cfc3fdfc038ac7d4efd83f8794a5c2261a.jpg)
***
这样就好了，你们可以链接了，怎么链接我等会发
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5662835042/bcf7f544d688d43f9043a2a5711ed21b0cf43bf7.jpg)
***
@bingohuanj @Longhorn4093 申精
感谢吧主+精[滑稽]
