【巨硬档案0095】
“我是人类，不，，，是一头狮子，，（什么，我怎么看不到一些颜色，然后下意识的看了自己的身体)，我不知道我怎么会在沙漠中，我记得我以前是在森林中被美洲虎吃了，我走了一天，沙漠中食物都没有，直到我看见了三角体的建筑，是金字塔。

。。。。。。。。。。。。。。。。。。。。
过了很久很久。。。。。。。。。。。。
。。。。。。。。。。。。。。。。。。。。
我捕杀了沙漠的管理者。。。成功回到“我自己的世界”———在“美国”的一个城市。
。。。。。。。！！！。。。！！！。。。。！！！！。
什么。。。。。（意识中断）
***
【Chicago 58s】
代号：Chicago
阶段：Pre-Beta（Milestone 4）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.58s
编译时间：1993年8月9日
产品密钥：Beta Site ID: 990036
时间炸弹：无

功能重点：
1.基于WFW3.x，所以自带增强的网络功能。
2.安装界面及过程全面检修。9x分支取消蓝屏安装。并且安装至CHICAGO文件夹。
3.资源管理器（本来是另一个项目的东西。
4.最初的任务栏及新的窗口及属性、右键菜单。
5.UNDER CONSTRUCTION壁纸。
6.一些Beta专有的程序及彩蛋。
7.一些程序及控制面版项目更新。
8.引入了一些新的程序及控制面版项目。

调教度：差
趣味度：A
成功安装使用的虚拟机：Virtual PC和86Box。
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入dossetup。
***
安装界面及过程全面检修。9x分支取消蓝屏安装。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d7fe574f251f95ca62c7f4e2c5177f3e660952ad.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65ebf2cbd1c8a7867c182c5a6b09c93d71cf50ad.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f0a59f188618367ad28f198922738bd4b21ce551.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b8ede119367adab443d67d1787d4b31c8601e451.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f1c154fb828ba61e048eae7b4d34970a314e5973.jpg)
选择文件夹图形化，默认安装至CHICAGO文件夹。9x比NT先进了一步
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e17fe0d7277f9e2f15187b5c1330e924b999f3ae.jpg)
选择硬件图形化，9x比NT先进了一步
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9f52d91f603738da8676a76bf1bb051f919ecae.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f0a59f188618367ad2ea198922738bd4b21ce57c.jpg)
这里取消即可
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/42fc1cf50ad162d9d2c204481ddfa9ec8b13cdaf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a8f65097bf40ad17dc8a1b75b2c11dfa8ecceaf.jpg)
基于WFW3.x，所以自带增强的网络功能。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf4111534bdfed3572c13dfcfda.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d1d7f0dca144ad343cdde4d3dca20cf430ad857d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8b1b11084b36acaf4014f5a870d98d1003e99ce7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a9d0df98a9014c0878994bf1067b02087af4f43d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/47fc4f391f30e924ab06ff6540086e061c95f73d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cca0f3eff01f3a29a37eb69a9525bc315d607c21.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bb06d5109313b07e944a335c00d7912395dd8ce0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d41a971e3a292df56f75cf41b0315c6035a87321.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b32ad38e8c5494ee7b7c6d4d21f5e0fe98257e79.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94de4f35349b033b162a9f8e19ce36d3d439bd3d.jpg)
美丽的太阳开机界面
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4aa1d418ebc4b745b77dd542c3fc1e17888215ea.jpg)
点击按钮即可进入桌面，你会看到平铺的UNDER CONSTRUCTION壁纸。（意思是修建中
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8eeffa17fdfaaf517533eceb805494eef21f7a83.jpg)
一下子，弹出三个窗口，最前的是正在修建中的说明，中间是让你输入Beta Site ID，最后的是安装打印机向导
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/79e6d41ab051f81986196f1ed6b44aed2f73e79f.jpg)
***
【巨硬档案0111】
??正在施工??

这个预发布版本的Microsoft Chicago正在建设中！

请记住，用户界面，系统程序将在产品的开发周期中持续改变。

谢谢！

- Chicago 开发团队
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5b21ca6fddc451da38fb54bfbafd5266d116324e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ed9abac551da81cb83ebdb995e66d0160824314e.jpg)
新的安装打印机向导，可建设本地打印机和网络打印机。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/92ef69f51bd5ad6e6a8d3cbe8dcb39dbb7fd3c67.jpg)
Tracker，版本1.00.016
貌似是跟踪使用人员的。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d10385343b8afdf759f13b07ecb808873.jpg)
华生医生，主要用于错误调试，版本1.00b
***
新的任务管理
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d9d1db305c6034a82425fdd5c71349540b237690.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1c9453a95edf8db1b7e939300523dd54544e7490.jpg)
引入新的搜索
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ec5b49dca3cc7cd9db72708d3501213fb90e9178.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9ccfc514fc2d562e65794b9eb1190ef77c66c78.jpg)
一些窗口排列
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d17bc7ed08fa513d296a298a316d55fbb0fbd993.jpg)
应用文件夹最初集成在任务管理
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0253be32c895d1436519a0777ff082025baf0768.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a7e5f7ee76c6a7efa779ec72f1faaf51f2de6678.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7625482fb9389b502eb4a4068935e5dde6116e14.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0cfc09071d950a7bfc5a0a9006d162d9f3d3c969.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8f0879168a82b901aab387677f8da9773812efba.jpg)
帮助项全是灰的
***
当时的快捷方式被称为链接，而且显示为＞＞

当时的任务栏并不叫任务栏，而是被称为“托盘”或系统工具栏。
一些图标是灰色的，和3.1的彩色图标形成对比。
可能是灰色为Beta，彩色为RTM的机制就开始就有了。
资源管理器被称为“Chicago Cabinet Explorer”

桌面的图标：
Chicago Cabinet Explorer - 资源管理器，列出系统中的所有驱动器。
从3.x传下来的应用文件夹 - 此文件夹包含指向系统上安装的应用的链接。
最初的回收站 - 指向临时存储要删除文件的文件夹的链接。没有清空回收站功能。
网络 - “网上邻居”
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/17d876dea9ec8a13662211b4fb03918fa1ecc09b.jpg)
程序最小化，并不会在系统工具栏中显示为任务条，而是在桌面上显示为带有大图标的小框，左键小框会出现关于窗口操作的菜单。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c13f5edab6fd526667707a40a718972bd5073604.jpg)
系统工具栏被白条占据，白条没有右键菜单。
系统工具栏最右边有时间显示，最左边有三个工具栏按钮都具有不同的功能。

Windows 微标按钮有窗口、桌面、关闭Windows、运行和启动任务管理器项目。 没有“应用”项目。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e17fe0d7277f9e2ff55a5b5c1330e924b999f369.jpg)
中间的是查找按钮。 从这里可以打开查找文件或网络的程序或选择最近打开的文件。 

个人菜单是一个文件夹，用户可以将自己的文件或链接指向文件以便快速访问。

该菜单的底部会显示当前打开的所有窗口的列表。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/50cc3442fbf2b211ac23c31ac68065380dd78e4e.jpg)
帮助按钮提供了Windows的一些信息。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4cc7e045ebf81a4c765baa9ddb2a6059242da66a.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f7b124a88226cffcd5cd09e6b5014a90f403eaf1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a529801090ef76c6f2fe4a7f9116fdfaae5167af.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3ce56007f679e45d688d63f2093.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fa55aa10728b471028064c98cfcec3fdfd0323aa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/303b5cc69f3df8dc5d143ec5c111728b461028aa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f8fa1ced54e736d164113d5c97504fc2d462695d.jpg)
一些基本的帮助，版本为4.000.001，帮助中的一些图片表示类似TPC的功能开发过。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dde29afbaf51f3deef98083098eef01f3b2979b5.jpg)
这个关于窗口是3.X的翻版
***
资源管理器本来是另一个项目的东西。结果被Chicago引用了，请参考一楼的故事。
脑洞：（如果注意到金字塔结构与资源管理器的关系，这说明另一个项目凶多吉少

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ca76de004a90f603bec32f133512b31bb151ed6d.jpg)
资源管理器已经基本定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b8ede119367adab49c98a81787d4b31c8601e414.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3efd750f8198618e2345cd046ed2e738ad4e66d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/745c39de8db1cb132e058f47d154564e93584b6f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cd45ac1249540923b405d02a9e58d109b2de496f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7627b238b6003af31ee26f34392ac65c1138b67b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/50cc3442fbf2b211bf76361ac68065380dd78e7b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68c0539a033b5bb5d78c93aa3ad3d539b700bc04.jpg)
特有的关于窗口，上面蓝天白云，下面很像沙漠，【一楼的故事和另一个项目的故事基于这个特有的关于窗口
***
猜一猜另一个项目是什么，他的身份是沙漠的管理者【即埃及的法老[滑稽]
属性的版本选项卡
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9596e234e5dde711aee0efa2abefce1b9c1661ad.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d2b1b189d43f87942222e57ade1b0ef419d53afe.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/83099b029245d68850df1ff0a8c27d1ed01b24fe.jpg)
RTM的Explorer.exe被称为Cabinet.exe。一些图标和RTM不同。，部分程序拥有16位和32位的exe
***
资源管理器的文件夹选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e918ed12632762d028f80aebacec08fa533dc692.jpg)
DOS程序的专有属性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b227302d11dfa9ec511cff436ed0f703908fc1ae.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/150fd5fa43166d22a4b1bbc04a2309f79252d292.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/17d876dea9ec8a13bef7f9b4fb03918fa2ecc0ef.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/03e20a234f4a20a4abd892939c529822700ed092.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/745c39de8db1cb131ba89247d154564e90584b92.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68c0539a033b5bb5c03b8eaa3ad3d539b400bcef.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e1b0ca355982b2b7f25e97903dadcbef74099b92.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f47beb5594eef01f7d39b191ecfe9925bd317dae.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cd45ac124954092389a8cd2a9e58d109b1de4992.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94cbe095a4c27d1e803cc09017d5ad6edcc43845.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e9f52b096e061d95ab93cf6c77f40ad160d9ca87.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4cc7e045ebf81a4c9cf4149ddb2a6059272da692.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e8279a1e4134970a0569eb7b99cad1c8a6865d45.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/97de0758252dd42afbcff9ff0f3b5bb5cbeab892.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ebecf02ad40735fa84eab5ed92510fb30e240845.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a6391c889e510fb369038cc3d533c895d0430c45.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5fc48e25b899a901d160a06211950a7b0308f507.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b7df9500fb30f242a4d1457c495d143af4b0380.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1e2beab0cb13495428e010305a4e9258d3094ad9.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d41a971e3a292df5f7735741b0315c6035a87323.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/42fc1cf50ad162d9578599481ddfa9ec8b13cd75.jpg)
原来白条是有右键菜单的，我记错了，【
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/61cbdf0f7bec54e73689e14ab5389b504ec26a76.jpg)
系统工具栏可以拉到中间，后来的版本不可以
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cca0f3eff01f3a293b8a2e9a9525bc315d607c1d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2b9791256b600c334e13259c164c510fd8f9a176.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/973e1cca0a46f21f7a5ea507fa246b600d33ae76.jpg)
***
引入向上按钮，以文件夹方式展示
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/95cdd1013af33a873efbe14eca5c10385143b5c2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/95cdd1013af33a873ec4e14eca5c10385243b52b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4fd025a6d933c895b5d5792fdd1373f083020034.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d8d6150f0cf3d7cae7fcf922fe1fbe096a63a956.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fccad63433fa828b5aeaaab6f11f4134950a5a8b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a1949728bd4b31cea5752ef8bd6277f9f2ff875.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c7f5c68a87d6277fef79f46c24381f30e824fc75.jpg)
引入改进的多媒体、虚拟内存设置，但样式很3.X
***
新的桌面属性

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bd0ec850f3deb48f8fc2498bfc1f3a292cf57835.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/efa594dfb48f8c5490782d7a36292df5e1fe7f35.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/480e363c269759ee505b419ebefb43166c22df55.jpg)
桌面属性的屏保只有图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b32ad38e8c5494eef589e74c21f5e0fe98257e35.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f47beb5594eef01f3cbff090ecfe9925bd317d35.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cca0f3eff01f3a292a633d9b9525bc315d607c35.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d41a971e3a292df5e8684440b0315c6035a87335.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b0eb5d282df5e0fe90b36154506034a85fdf7235.jpg)
这里还是3.1
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7add4af4e0fe9925b6a7810538a85edf8cb17135.jpg)
***
全新的显示设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fefd0c62f6246b600f9b1434e7f81a4c530fa2ca.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e0186ffb513d26979b10831d59fbb2fb4116d8a1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c27fc11fa8d3fd1f2f14047a3c4e251f94ca5f42.jpg)
引入DPI设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/480e363c269759eefe93eb8bbefb43166f22dfa1.jpg)
鼠标设置改版，引入后两项选项。
·支持切换主要和次要的按钮

·支持测试与调整双击速度
·支持显示鼠标轨迹
·支持调整指针移动速度
·支持调整基本的指针外观
·支持鼠标设备的更改与设置

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f47beb5594eef01f6a99be85ecfe9925be317dd2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08faba5db5e755ee3d6d54fbda03.jpg)
键盘设置改版，引入除第一项之外的选项。
·支持按键重复延迟和按键重复速度的调整，并可以测试重复速度。
·使用鼠标键移动鼠标指针，键入Alt+Shift+NumLock即可开启/关闭鼠标键。
支持数字键或方向键以移动鼠标指针。
可调整鼠标键的指针速度。

·支持调整输入框内的光标闪烁速度。
·支持键盘设备及输入区域的更改与设置。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11c9419659ee3d6d91050c8b4f166d224d4adea1.jpg)
选择字体的界面基本定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/79f5463eb80e7bec6d62a2a1232eb9389a506b2f.jpg)
***
时间设置框架定形，时钟及日历是黑白的，年份用两位数表示，两个名称为“格式”的按钮是灰的。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cde466e83901213fb417c49c58e736d12e2e95bb.jpg)
有一个名为“Metrics”的设置，它似乎是一个更详细的外观属性的实验版本。在后来的版本作为外观属性并入桌面设置。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3deab51a0ef41bd5f1371ab45dda81cb38db3d7b.jpg)
***
基于WFW3.x，所以自带增强的网络功能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a649102738da97745be6a6bbc51f8198418e3d7.jpg)
引入高级系统设置：
已有基本的设备管理，支持按类型或按连接查看
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/20ad422cd42a2834d6d4bc4b57b5c9ea14cebf72.jpg)
启动文件设置，为空白，应该和引导有关？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6f7148ca9773912ceb76921f4198618347ae2d7.jpg)
选择配置文件，为空白，应该和系统配置有关？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4e007cd4ad6eddc437723ebb35dbb6fd506633ca.jpg)
系统限制设置
·文件系统的使用设置。

·支持指定可使用文件控制块的数目。·内存使用设置。

·环境变量，可设定保留空间。

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/746f643a5bb5c9eaf3b589a3d939b6003bf3b326.jpg)
***
设备设置改版

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8861b642ad4bd1132ccb5e7256afa40f4afb0565.jpg)
超级视频编解码器版本为1.5.0.0
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d3e7d77fca806538d6b24d539bdda144ac348208.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d2b1b189d43f8794e6b7a16ede1b0ef41ad53a1f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dc76b659ccbf6c819c65c5a8b03eb13532fa4011.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e17fe0d7277f9e2f8501cb481330e924b999f3b4.jpg)
引入调制解调器设置，布局是3.x风格
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b3f6d47f21fbe09dcde2a5467600c338544ade0.jpg)
***
系统信息不仅有“系统名称版本、内存、资源、所有者＂，而且有清晰的图片。
拥有了启动配置功能(框架)，可建立、删除、编辑启动配置，但是白框内的灰字却表示功能尚未实现。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8de5158a4710b912fb6d20becffdfc0393452233.jpg)
引入搜索这些文件夹的应用程序选项，可添加、删除、删除所有以进行编辑文件夹。但没有搜索按钮。
引入临时目录。
支持简单的编辑环境变量。可建立变量，并设置变量名称和值。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b3f6d47f21fbe09db87155467600c338544ad8f.jpg)
虚拟内存设置更详细
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4f47682542a7d9339c2f3233a14bd11371f001e4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/13b79cf3b211931360eb29f069380cd790238d38.jpg)
引入连接文件夹，支持建立新连接
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8a7402390cd7912342484234a1345982b3b78038.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d10385343361651619f13b07ec880888f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9596e234e5dde711640b95b6abefce1b9f16618f.jpg)
***
计算器由白底变成灰底
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bb06d5109313b07e7bad664900d7912396dd8c50.jpg)
字符映射表由白底变成灰底
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f2e5f412b07eca80d7150fa69d2397dda0448350.jpg)
引入局域网聊天工具，但在一些情况下打不开
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d3e7d77fca806538bffa92529bdda144ac348250.jpg)
应用程序分为16位和32位，一些32位应用程序的名称标有32，比如时钟。
32位的时钟相比16位的时钟添加了格林尼治标准时间选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f08aad8165380cd7250e94acad44ad3458828150.jpg)
***
Media Player界面升级
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31bf67fe9688a18367adbb4e151.jpg)
包括一个名为“Microsoft Music Box”的程序，而不是CD播放器。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91b7ca4ad11373f0a5aa4fdea80f4bfbf9ed04ca.jpg)
没有CD驱动器会打不开Microsoft Music Box
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9d3036db81cb39dba5824717dc160924aa183021.jpg)
Microsoft Music Box的版本为2.0a
***
记事本
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d17bc7ed08fa513d4e844e9f316d55fbb3fbd9be.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/97de0758252dd42aa12723ea0f3b5bb5c8eab8be.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dea568b20f2442a7c614dfe4dd43ad4bd0130249.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1c9453a95edf8db11e005e250523dd54574e74be.jpg)
***
对象包装程序由于9x风格化变得部分字体微小
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94f352fbe6cd7b89871316c2032442a7d8330e6c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/eb90644e78f0f736838160400655b319eac4136c.jpg)
录音机9x风格化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c7f5c68a87d6277fd56d1e7924381f30e824fc6d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6d00c610c33874494f7033d5d0fd9f9d62aa0b2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11fbbef8d72a6059a06fcd5b2434349b023bba6d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e3381bd88d1001e9890e384eb40e7bec55e797b2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/79f5463eb80e7bece0a52fa0232eb9389a506b6d.jpg)
***
包括WINBUG报告，版本为1.14（Chicago Beta）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9d3036db81cb39dbb82a4817dc160924a91830f9.jpg)
***
BUG10？？？[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cb20d41d8701a18bc1b93b0e922f07082938fe12.jpg)
***
当时的硬件配置【1993年】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bb06d5109313b07e5f297a4900d7912395dd8cd4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1976d5b6d0a20cf49104d49e7a094b36aeaf99d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/27fdae3c70cf3bc77040e7addd00baa1cc112a20.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/92ef69f51bd5ad6ed8ba4eab8dcb39dbb7fd3c20.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f1c154fb828ba61e487ae26e4d34970a324e59d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89e3183f6709c93d9d6624b6933df8dcd30054d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f7b124a88226cffc316995f3b5014a90f703ea21.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c722407e9e2f07086f460041e524b899a801f221.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/222d95d2572c11dffe9295626f2762d0f603c221.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11c9419659ee3d6d3685ad8a4f166d224e4ade21.jpg)
***
引入空当接龙，红心大战。空当接龙貌似是58s自带游戏中的唯一的32位程序
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c2f63daea40f4bfbe5cb89150f4f78f0f6361848.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6f7148ca9773912873d9220f4198618377ae249.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d7fe574f251f95ca35c085f7c5177f3e660952ab.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6d00c610c3387449df0383d5d0fd9f9d62aa0ab.jpg)
***
写字板无法打开
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8a7402390cd7912316f19635a1345982b3b78057.jpg)
关机的对话框改进
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7159acee76094b3633bd0aacafcc7cd98c109dbd.jpg)
关闭Windows的对话框，并且图片显示夜空中的弯月。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6d0187ff9925bc31985c10d952df8db1ca137067.jpg)
***
预告：73F～73G
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/42fc1cf50ad162d9528c845d1ddfa9ec8b13cd03.jpg)
美洲狮，美洲虎
【Chicago 73f】
代号：Chicago
阶段：Pre-Beta（Milestone 5）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.73f
编译时间：1993年11月23日
产品密钥：Beta Site ID: 426588; Password: 20e502466
时间炸弹：无

功能重点：
1. Explorer具有了一些变化。
2.常规应用程序没有在程序文件夹中链接到，您可以从Chicago文件夹手动启动它们。
3.引入WinPad和WritePad、拨号程序。
4.应用程序和控制面板项、功能大幅移除及引入。
5.安装程序大幅调整。
6.关机时，会显示带有月亮的MicrosoftCHICAGO徽标，而与之形成鲜明对比的是，启动屏幕带有太阳。
调教度：差
趣味度：A
成功安装使用的虚拟机：Virtual PC和86Box。
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
安装程序引入启动画面。

安装背景更换，安装背景并不是正式版的背景。
首次拥有条约。
帮助与退出按钮移至右上角，而且显示为Windows Setup。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4f47682542a7d93390d40e37a14bd11372f0016f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/25cc6bd6912397dd7b1572405582b2b7d1a28778.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fccad63433fa828bb95d77a7f11f4134960a5a69.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/09a06e22dd54564e801d0e7dbfde9c82d0584f6b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4f47682542a7d93390a40e37a14bd11372f0015f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bb19cc65034f78f0920770b775310a55b2191c5f.jpg)
***
到这里才正式开始。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2ef27a940a7b0208eb51eaa56ed9f2d3552cc8d4.jpg)
检测硬件步骤很讨厌，如果86Box配置不正确会闪退
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8de5158a4710b912fe3323bacffdfc03904522fd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94cbe095a4c27d1e92d4ee8017d5ad6edfc438fd.jpg)
***
安装程序的自定义选项改进
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d01b11c7a7efce1b64ef1f8ea351f3deb68f65a0.jpg)

选择安装目录添加了很长的说明文字，而且支持选择升级安装和全新安装
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d41a971e3a292df5e22d7a51b0315c6036a873f9.jpg)

可以选择组件
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d41a971e3a292df5e2827a51b0315c6035a87322.jpg)

选择硬件添加了图标以及很长的说明文字
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/43cf3cb4c9ea15cef547364dba003af33b87b23b.jpg)
***
要求输入Beta ID及密码的步骤提前，并且可以输名称和公司了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94f352fbe6cd7b89d1ccecc7032442a7db330ec3.jpg)
还有第二次确认
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6fdade399b504fc23a4d6141e9dde71191ef6d5e.jpg)
进度条界面简约化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/70ba421e95cad1c884b12d63733e6709c83d5165.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9e6affdc3cec3fdc9347631da88d43f86942765.jpg)
***
网络安装的图标大了一些
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a9d0df98a9014c08e67ff9e1067b02087af4f420.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1e2beab0cb134954037439205a4e9258d0094a05.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/222d95d2572c11df3b546e676f2762d0f503c2e7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f1c154fb828ba61eb384196b4d34970a314e5905.jpg)
引入预开机界面
***
Cab32取代Cabinet
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6050212209f790523e74977a00f3d7ca7acbd505.jpg)

账户功能上线
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/833aa4fcfc039245e0d1314b8b94a4c27c1e2507.jpg)
***
任务栏托盘默认显示任务列表，但文件夹状态仍然可通过属性调出来
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89e3183f6709c93d5706deb3933df8dcd30054f7.jpg)

引入公文包，桌面上的资源管理器被我的电脑取代，应用文件夹的图标用文本表示。
移除Tracker以及正在施工中的说明程序。
标题栏及小框框的文本加粗。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4aa1d418ebc4b74526a46452c3fc1e178b8215b3.jpg)
***
引入任务栏属性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d01b11c7a7efce1b696d1a8ea351f3deb58f6522.jpg)
任务栏属性的任务栏类型可选择文件夹状态和任务列表状态。
任务栏属性的任务栏放置选项包括“总在最前面、自动隐藏”。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7627b238b6003af3f91b0e24392ac65c1238b6c3.jpg)
***
常规应用程序没有在程序文件夹中链接到，可以从CHICAGO文件夹手动启动它们。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fccad63433fa828bb01440a7f11f4134960a5ab0.jpg)
引入帮助搜索
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/43cf3cb4c9ea15ce88e83d4dba003af33b87b262.jpg)
帮助搜索的索引
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8861b642ad4bd11320896a7656afa40f4afb0527.jpg)
帮助菜单的Windows内容项，在线搜索帮助项被删除，引入帮助项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0cfc09071d950a7b858c938006d162d9f3d3c92b.jpg)
桌面右键菜单引入任务列表，删除始终位于顶部及查看。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2dd6284b20a44623a85978269422720e0ef3d7dd.jpg)
引入简约化的帮助
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5fc48e25b899a901cfeb867211950a7b0008f58a.jpg)
***
其实在58s就有了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ab0c7d4d510fd9f96490892d292dd42a2a34a4e1.jpg)

任务栏还是可以拉到中间的，相比58s还是有一点变化的，如任务栏标题栏的文本消失。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3deab51a0ef41bd597b134b05dda81cb3bdb3d8d.jpg)
***
文件夹状态能右键，根据文件夹状态的右键，可以看出可以按名称、按类型、按大小、按日期排序任务条，而任务列表状态不能右键。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4c23f62297dda1447d96b3f6beb7d0a20ef486c9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/035de527cffc1e17ef1253754690f603728de93f.jpg)
***
公文包
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cde466e83901213f59cd919858e736d12d2e95ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8f0879168a82b9012c9b1d777f8da9773812efb2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11c9419659ee3d6dc28b598f4f166d224e4ade1f.jpg)
我的电脑
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ebecf02ad40735faa3f490fd92510fb30e240867.jpg)

移除启用网络浏览器项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4fd025a6d933c8959cbd463fdd1373f0800200ac.jpg)
拨号文件夹的图标更新
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/50cc3442fbf2b21155195c0ac68065380dd78eb1.jpg)
***
回收站的标题栏图标变成垃圾桶
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a9d0df98a9014c08eea3f1e1067b020879f4f4d4.jpg)
资源管理器移除了3.x时的窗口菜单
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d650c1725b0b0828381d30fded.jpg)
向上按钮由文件夹形式改成按钮形式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4903f7539822720eaccf3abe77cb0a46f31fab63.jpg)
***
界面的滑动条元素更新

DOS程序属性的一些规则更新，并在任务项引入“在终止之前闪动“选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6d00c610c338744408af7385d0fd9f9d62aa019.jpg)
DOS程序属性内存项的框框变宽了许多
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c7b08cf91a4c510f74a9395e6c59252dd52aa57f.jpg)

EXE属性的版本项引入基本文件信息并且界面调整。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a649102738da9775e9d5d6fbc51f8198718e33e.jpg)
***
1.移除以下控制面板项【大部分因为并入其他控制面板项而被移除】：
声音映射器Metrics驱动设置MIDI映射器
386增强模式
虚拟内存
2.引入以下控制面板项：
电话服务多媒体
3.更改了网络安装及调制解调器的图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/512bceed8a136327e8df18779d8fa0ec09fac7be.jpg)
***
很像电影开头商标的壁纸
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b1833e636d12f2e59056b2443c2d5628435686c.jpg)
引入新的壁纸，它表示Chicago的工作正在进行中
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cde466e83901213f638c8b9858e736d12e2e9529.jpg)
DPI并入显示设置，并且在引入颜色条以识别色彩位数，显示设置的界面更紧凑。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/553a51d2d539b600832fcaf3e550352ac45cb783.jpg)
更改显示类型更详细：支持更改适配器类型，监视器类型。并且可以查看基本的驱动程序信息，例如产品公司、版本、驱动文件。更改设备的对话框更宽大并支持选择兼容设备【适用于大部分设备类型】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/06d76ef690529822e935fd87dbca7bcb0b46d462.jpg)
***
时间设置外观改善，日历风格9x化，时钟披上了青绿色，并且年份用四位数表示
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/411d5e00213fb80ea1e7a6933ad12f2eb83894b2.jpg)
声音映射器、MIDI映射器、驱动设置应该并入了多媒体设置。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5b21ca6fddc451dab560cbafbafd5266d21632d1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/678bf92e070828386ab31b50b499a9014d08f12a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/47fc4f391f30e924cf1a5b7540086e061c95f72a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3cee57a0e779e45d688d53f2035.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/86a877395343fbf20da36167bc7eca8067388fd9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3cee52a0e779e45d688d63f2085.jpg)
***
部分程序灰底变成白底
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5fc48e25b899a90135eb9c7211950a7b0008f58a.jpg)
貌似移除了启动配置功能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/25cc6bd6912397dd67375e405582b2b7d1a2871a.jpg)
还移除了这些：搜索这些文件夹的应用程序选项、临时目录、简单的编辑环境变量。
还有虚拟内存的图片正常了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2dd6284b20a446239f7363269422720e0df3d72b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d657d36d5b0b0828381d30fdd3.jpg)
设备管理器的按钮移至右侧并且支持删除设备。
移除启动文件设置、选择配置文件、系统限制设置。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/20ad422cd42a283499d1f74f57b5c9ea14cebf71.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11fbbef8d72a60598f2a205e2434349b023bbab6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e918ed12632762d0711865fbacec08fa503dc642.jpg)
***
调制解调器设置简化并引入安装调制解调器的界面。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bdeb2635970a304e358f61beddc8a786c8175c3e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/745c39de8db1cb13b0e7fd57d154564e90584bda.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a2505d8f2d3572c90045d988613632760d0c382.jpg)
电话服务，可能是从Windows NT中引入的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/92ef69f51bd5ad6eed16a5ae8dcb39dbb4fd3cf8.jpg)
***
磁盘设置58s打不开，73f能打开
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2b946b328744ebf8be72a47bd5f9d72a6159a76d.jpg)
已支持基本的检查磁盘功能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fcc53b6134a85edf7bf23e6745540923dc54756a.jpg)
***
引入拨号程序，已有通话记录、快速拨号功能
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/25cc6bd6912397dd65ff58405582b2b7d2a287e2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6e29c4cd7cd98d10d3e3cf752d3fb80e7aec90b1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ca76de004a90f6032d325c033512b31bb251edee.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7c2c8c279310a55e1171db0bb4543a9832610bc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1c9453a95edf8db13d32bf200523dd54574e7448.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8f0879168a82b901119e00777f8da9773812efbd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d7dfb30635fae6cd40ac682503b30f2443a70f4b.jpg)
媒体播放器支持MIDI音序器、声音等文件。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9ccfc514fc2d5625b7413a9eb1190ef77c66c68.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/97de0758252dd42a82a0c2ef0f3b5bb5c8eab83b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65d9b32b2834349bafafadc1c5ea15ce37d3be3b.jpg)
***
WINBUG报告升级为1.16（Chicago Beta）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ca76de004a90f6032e385f033512b31bb251ede4.jpg)
白底的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4fd025a6d933c89593395b3fdd1373f083020020.jpg)
Winver中显示的是 “386 增强模式 Windows Version 4.0”。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31bd0770f6d8a18367adbb4e155.jpg)
***
引入WinPad，版本为1.1602，似乎是个人计划程序。界面较简陋，应该是在便携式设备中使用。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4f47682542a7d93388ba2637a14bd11372f0015d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6e29c4cd7cd98d10d0eace752d3fb80e7aec90aa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cae7042662d0f7031457569804fa513d2497c587.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b32ad38e8c5494ee1b72cd5d21f5e0fe98257e1c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e4361a1fd21b0ef430ab5a1ad1c451da80cb3e2c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dde29afbaf51f3de5cf27b2098eef01f3b29792c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6d0187ff9925bc31ad0dc3dc52df8db1ca13701c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8be72e550923dd54af0d652cdd09b3de9d82486a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91f4dda0cd11728b5a544e66c4fcc3cec2fd2c6a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/967cb33e8794a4c2555a256f02f41bd5ac6e396a.jpg)
***
引入WritePad，图标是天蓝色的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e3381bd88d1001e9eb8ad64bb40e7bec55e79732.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/746f643a5bb5c9eabbb5c1a7d939b6003bf3b322.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8f0879168a82b901102301777f8da9773b12efda.jpg)
关机时，会显示带有月亮的Microsoft CHICAGO徽标，而与之形成鲜明对比的是，启动屏幕带有太阳。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94f352fbe6cd7b89a411f7c7032442a7d8330e6e.jpg)
***
【Chicago73g】
代号：Chicago
阶段：Pre-Beta（Milestone 5）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.73g
编译时间：1993年12月2日
产品密钥：Beta Site ID: 886293; Password: 637b81f97【不是必需的】
时间炸弹：无

功能重点：
1. 默认的施工中壁纸改为居中。
2. BetaSite ID和Password如果不输入会提示“不是必需的”。
3. WinBug报告版本为1.14。
4.这些迹象可能表示73g曾经对公众发布过。
调教度：差
趣味度：A
成功安装使用的虚拟机：Virtual PC和86Box。
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
Beta Site ID和Password如果不输入会显示“不是必需的”
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/967cb33e8794a4c25b0d2b6f02f41bd5ac6e39b9.jpg)
WinBug版本为1.14
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/66633eef3d6d55fb38e3ba6261224f4a21a4dd47.jpg)
默认的施工中壁纸是居中的。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e0186ffb513d2697de84c41959fbb2fb4216d811.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c760c3c37d1ed21b26cde2a1a16eddc450da3f67.jpg)
***
【Chicago81】
代号：Chicago
阶段：Pre-Beta（Milestone 5）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.81
编译时间：1994年1月20日
产品密钥：Beta Site ID: 193901; Password: 06247b168
时间炸弹：无

功能重点：
1.任务栏上的三个按钮被包含小箭头的开始菜单按扭取代。
2.窗口界面样式更改:左上角的窗口按扭消失，由左上角的图标取代。右上角加入关闭按扭。
3.窗口标题栏图标默认显示经典徽标。
4.引入系统监视器。
5.许多东西改进或更新。
调教度：差
趣味度：A
成功安装使用的虚拟机：Virtual PC和86Box。
注意事项：如果选择S3显卡驱动，安装后会花屏，所以请选择其他显卡驱动
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
安装程序启动界面的提示居中
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a7e5f7ee76c6a7ef3c2c7563f1faaf51f2de6667.jpg)

Cancel被修改成Go Back键。

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e4fb2cfafbedab64590f9085fb36afc378311e6f.jpg)

Userinformation(用户信息)被修改成Userinformation verification(用户信息验证)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a1949728bd4b31cff7e49fe8bd6277f9f2ff82f.jpg)
***
任务栏上的三个按钮被包含小箭头的开始菜单按扭取代【三个按钮的功能合并到开始菜单按扭】。并在开始菜单引入程序文件夹。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5b21ca6fddc451dabc5ad0aebafd5266d1163238.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/303b5cc69f3df8dcf65b53d4c111728b46102802.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1e2beab0cb1349540ca534215a4e9258d0094a35.jpg)
Taskbar(任务栏)这个名称首次出现，任务栏属性引入“重新最小化窗口“项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/141351d02f2eb9387c10a5b7d9628535e4dd6f68.jpg)
搜索文件程序改版。而且任务栏的任务条外观更精致。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bd0ec850f3deb48f7a107e9bfc1f3a292cf57874.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/746f643a5bb5c9eaae82dca6d939b6003bf3b37c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/97de0758252dd42a9e78deee0f3b5bb5c8eab87c.jpg)
***
帮助搜索更名为帮助主题
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d65f3f755a0b0828381e30fd68.jpg)
运行改进。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ec5b49dca3cc7cd95185ea9c3501213fba0e91c5.jpg)
任务栏仍然可以拖出去
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/17d876dea9ec8a13eeb889a5fb03918fa2ecc0cf.jpg)
***
桌面图标的右键菜单定义化【以前图标都是一样的右键菜单】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cae7042662d0f7031e884c9904fa513d2797c5b7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8b1b11084b36acaff6a94fb970d98d1000e99c24.jpg)
窗口界面样式更改:标题栏图标代替以前的3.x式按钮，右上角并引入关闭按扭。一直到发贴时间为止的Windows。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/730ee58aa61ea8d3ee2cac419b0a304e241f585a.jpg)

我的电脑右键菜单定义化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/327f2011b912c8fce9412e88f0039245d788213e.jpg)
***
属性的设置图标步骤简化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a738e51352ac65cd1ebbe36f7f2b21191138afb.jpg)
DOS程序属性在任务选项卡引入“允许屏幕保护程序”项。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7c2c8c279310a55e93305b1bb4543a983261051.jpg)
DOS程序属性在内存选项卡移除指针检测。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dde29afbaf51f3de45e1622198eef01f3b29791e.jpg)
DOS程序属性引入键盘选项卡。包括快捷键选项以及粘贴选项。支持AIT键延迟。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/973e1cca0a46f21f1aa68516fa246b600e33aedf.jpg)
DOS程序属性引入鼠标选项卡。包括窗口行为选项内的快速编辑模式以及专用鼠标。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4cc7e045ebf81a4cfd7a378cdb2a6059242da625.jpg)
DOS程序属性引入计时器选项卡。包括陷阱端口访问，触发模式。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6d00c610c338744418df4395d0fd9f9d62aa025.jpg)
DOS程序属性引入窗口选项卡。包括启用工具栏，在启动时恢复窗口设置。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ab0c7d4d510fd9f979858e2c292dd42a2a34a4df.jpg)
***
程序文件夹的名称为大写。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4c0056accbef7609988e43da22dda3cc7ed99ee0.jpg)
1.移除控制面板项【大部分因为并入其他控制面板项而被移除】：高级系统设置和颜色。
2.引入控制面板项：建立新硬件
3.更改了桌面设置的图标。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d729c645ad3459827ea720d700f431adcaef84b8.jpg)
***
桌面设置背景选项卡重新引入图案
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c2f63daea40f4bfbab625b110f4f78f0f636183e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1a5bc30e4bfbfbedfaabf33a74f0f736adc31ffe.jpg)
桌面设置引入外观选项。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/99c7af94d143ad4b9bf083858e025aafa60f068a.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/03e20a234f4a20a4d163f8829c529822730ed068.jpg)
虚拟内存的硬盘图片被移除，不仅界面更紧凑，而且设置虚拟内存的大小更方便。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edc03e83b2b7d0a2c20ac1d8c7ef760949369aae.jpg)
高级系统设置的设备管理器并入系统设置。没有刷新和打印按钮，也没有按类型按连接查看。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/17d876dea9ec8a13e41293a5fb03918fa1ecc065.jpg)
设备管理器的计算机属性更详细。

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/973e1cca0a46f21f1f519a16fa246b600d33ae00.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b2ebd9086b63f624cf55fd468b44ebf81b4ca365.jpg)
最初的建立新硬件
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2b9791256b600c3321431a8d164c510fd8f9a1b7.jpg)
***
引入系统监控，图标应该是一名服务员。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31bd5fe0a6c8a18367ad8b4e1df.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89e3183f6709c93d6aabc9b2933df8dcd000540b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cb20d41d8701a18bf797d50a922f07082938fe69.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89c917ce3bc79f3de5b82375b6a1cd11738b290b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2ef27a940a7b020805b5f8a46ed9f2d3562cc869.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8808a4cfc3fdfc03bacd24fdd83f8794a5c22637.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/47fc4f391f30e924cffd5b7440086e061c95f714.jpg)
WINBUG报告再次升级为1.16（Chicago Beta）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31bd5290a6c8a18367adbb4e120.jpg)
注册表编辑器还是3.1的样子。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8a7402390cd7912351685331a1345982b0b780e5.jpg)
关闭Windows更改为关闭Chicago
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/141351d02f2eb93844dabdb7d9628535e4dd6f32.jpg)
***
宣布暂停更新至7月
【Chicago 90c】
代号：Chicago
阶段：Pre-Beta（Milestone 5）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.90c
编译时间：1994年3月15日
产品密钥：Beta Site ID: 193901; Password: 06247b168
时间炸弹：无

功能重点：
1.该版本的用户界面对原有的三维效果进行了细节处的更新，系统属性中缺少Windows徽标 。
2.回收站默认禁用。
3.操作系统标注有“Microsoft Chicago”和”Windows 4.00”字样，但在Winver中却显示的是 “Windows 3.99”。
4.任务栏位置默认为屏幕的顶部。
5.开始按钮处包含一个箭头符号。
6.画图的界面元素更新。
7.选项卡式鼠标设置、键盘设置。
8.引入安全模式、启动盘。
调教度：差
趣味度：A
成功安装使用的虚拟机：Virtual PC和86Box。
注意事项：无
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
预告：【Chicago99】
代号：Chicago
阶段：Pre-Beta（Pre-Milestone 6）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.99
编译时间：1994年5月10日
产品密钥：BetaSite ID: 856622; Password: e2bc24d79
时间炸弹：无

功能重点：
1.在第一次登录设置后，您将看到一个问题来重新运行硬件检测，但是您可以选择跳过或执行它，但每次启动它时都会遇到同样的问题。
2.CAB32.EXE（资源管理器）可能会使您崩溃进入命令行，只需键入WIN即可重新启动它。
3.窗口右上角引入帮助按扭。
4.？
5.？

调教度：差
趣味度：A
成功安装使用的虚拟机：Virtual PC和86Box。
注意事项：无
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
安装程序的系统检测有了详细界面及进度条。移除了帮助按钮。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65d9b32b2834349bf294ea7bc5ea15ce34d3beb0.jpg)

安装程序的窗口更宽大，并且欢迎说明更新，说明提示安装需要20分钟。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1e2beab0cb13495434926c9a5a4e9258d3094ab1.jpg)
安装程序的自定义选项简化，选择安装目录的步骤被移至高级选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edbfb61273f08202d63a15c147fbfbeda9641b9d.jpg)
选择组件步骤移除“新建/删除” 按钮，并且一些图标更新。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a8f65097bf40ad1a367431d5b2c11dfabecce47.jpg)
要求输入BetaID及密码步骤的说明更改且引入产品标识号。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/79f5463eb80e7bec4864871f232eb93899506b83.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/327f2011b912c8fca5057233f0039245d488214b.jpg)
***
【巨硬档案0122】
创建一个紧急启动软盘
该磁盘将包含用于紧急情况的系统和磁盘诊断工具。

一张软盘将是必需的，并且不需要格式化。 该磁盘上的任何现有数据都将被销毁
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d696642ce10b0828381e30fd24.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cb20d41d8701a18b37e495b1922f07082938fe33.jpg)
施工中壁纸不再是默认背景，默认背景全青绿色。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a2505d8f2d3572cd2c11b228613632763d0c327.jpg)
进入桌面前会弹出安装调制解调器向导，不过你可以选择取消。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2b9791256b600c3362985936164c510fdbf9a165.jpg)

有时候会弹出设备资源冲突通知。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d2b1b189d43f8794c81ccfd0de1b0ef419d53a66.jpg)
***
任务栏位置默认为屏幕的顶部。我的电脑的图标更新为青色屏幕样式。
桌面上的公文包、网上邻居、回收站、程序文件夹默认不显示。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/36fd2c37acaf2eddb03bce17811001e93b01937f.jpg)
引入配置开始菜单向导，主要是把未添加到开始菜单的程序添加到开始菜单。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/97de0758252dd42ac50387550f3b5bb5c8eab838.jpg)
配置开始菜单向导显然有BUG，把已添加到开始菜单的程序添加到开始菜单，导致重复。
开始菜单的程序文件夹重组，3.x式的程序文件夹组列方式消失。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/27fdae3c70cf3bc7c45b4b12dd00baa1cf112aee.jpg)
正常的开始菜单。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5ab8360ed9f9d72a8a3196e3d82a2834369bbbe9.jpg)
***
在开始菜单引入打印机文件夹。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91b7ca4ad11373f00bc2e961a80f4bfbf9ed0440.jpg)

开始菜单的搜索里的文件、网络资源被取代为文件或文件夹、计算机。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/99c7af94d143ad4b56d3c03e8e025aafa60f0640.jpg)

任务栏属性简化，关于任务栏类型的设置被取消。可能是任务栏的功能合并。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/43bb1ff1f736afc3eae6b99bbf19ebc4b545125f.jpg)
搜索文件的界面更智能，引入帮助菜单、视图菜单。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a738e51352ac65cebfee08df7f2b21191138a4f.jpg)
搜索文件日期的设置定型
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89c917ce3bc79f3da45162ceb6a1cd11708b2995.jpg)
引入搜索计算机。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ca76de004a90f603d3401ab93512b31bb251ed56.jpg)
帮助主题的说明被更改。图标被移除。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/150fd5fa43166d229cb6936a4a2309f79252d205.jpg)
运行被简化。新的打开文件窗口。帮助主题的说明分步骤所以更有帮助的感觉。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3632c0eece1b9d16d5f61b9fffdeb48f8d546414.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d10385343061f01df9f13b07ec8808876.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6fdade399b504fc2ca7231fbe9dde71191ef6d10.jpg)
***
任务栏的状态及功能合并。任务栏右键菜单有最小化所有窗口及任务栏属性。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6e87ecd5b31c87010cd833182b7f9e2f0508ffdc.jpg)
任务栏的任务条右键菜单也和标题栏图标取代了3.x式窗口左上按钮。我的电脑默认显示控制面板和打印机文件夹。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f47beb5594eef01f15aa993becfe9925be317d83.jpg)
桌面右键菜单移除任务管理器。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf4b6e1d717fed3572c10dfcf31.jpg)
桌面右键菜单支持新建文件夹、快捷方式（当时称为链接）、许多新的文件格式。58s～81只支持新建文件夹。链接的显示样式从＞＞更换为更具辨识度的左下黑色小箭头。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c6ec517bdab44aed87fd3f1abf1c8701a38bfb97.jpg)
如果新建文件夹、快捷方式之外的文件格式，会提示功能未实现。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a075d86e950352a3e5ba5f65f43fbf2b3118b08.jpg)
回收站虽然默认禁用，但删除文件会提示你想完全删除文件吗？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d1038534300f507df9f13b07ecb808808.jpg)
当然资源管理器也支持搜索以及新建文件夹、快捷方式（当时称为链接）、许多新的文件格式。资源管理器的视图栏重新调整排序。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68cc7831e924b8991fe0f8c662061d95087bf662.jpg)
资源管理器选项改进。文件夹选项卡提供了带图例的多窗口及单窗口两个单选择。

资源管理器选项的视图选项卡提供了隐藏部分类型的文件及显示所有文件。还提供了在标题栏显示MSDOS路径全名、隐藏已登记的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ca76de004a90f603eddd1cb93512b31bb251edd1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9f52d91f603738d36278cdcbf1bb051fa19ecd1.jpg)
文件类型的MSDOS文件扩展名，显示右侧和左侧窗格的说明栏。
全新的磁盘属性。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/22249002918fa0ecc0e1e4f32a9759ee3c6ddb24.jpg)
***
界面的分隔线元素更新。部分窗口移除帮助按钮，一些属性窗口移除标题栏的扩展名。winver显示的是 “Windows 3.99”。 DOS程序属性的计时器选项卡被移除。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fccad63433fa828b98bc681df11f4134950a5aa2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/16baf559d109b3dea8731196c0bf6c81820a4c71.jpg)
DOS程序属性任务选项卡foreground boost框、background behavior框的滑动条的移除
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b828b601baa1cd11214e87deb512c8fcc1ce2d4d.jpg)
引入管理员配置。图标很像一名间谍。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b1833e636d12f2ea9f35b9e43c2d5628735684b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7625482fb9389b505d2415ac8935e5dde5116e6e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7d9932fab2fb4316a9268e842ca4462308f7d30d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f20f24176d224f4ae6a087ed05f790529922d10d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e8279a1e4134970a7382e5d199cad1c8a5865d54.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8be72e550923dd5466b65296dd09b3de9e824878.jpg)
公文包的9x图标定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8eeffa17fdfaaf51ee837541805494eef21f7ae5.jpg)
***
媒体播放器的9x图标定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4c23f62297dda1445a7f9a4cbeb7d0a20ef486d4.jpg)
引入画图 Chicago版取代3.x的画图，小图标是灰色的，不仅仅是界面元素更新。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dc76b659ccbf6c81b588da16b03eb13531fa4082.jpg)
画笔栏下方的小框适用范围扩大，例如选择画笔形状。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e71ba91a9d16fdfab5d43010b88f8c5496ee7b8d.jpg)
画图 Chicago版支持第二颜色，用取色器右键或右键点击颜色栏的颜色框即可选取第二颜色。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/23d305d1f703918f19abcb345d3d26975beec4c8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7b33f83cf8dcd100f4ea0edf7e8b4710bb122fcb.jpg)
画图引入快捷的取色器、放大工具。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91e714f182025aafde108f35f7edab64024f1a27.jpg)
画图引入状态栏，坐标被集成到状态栏中。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/95cdd1013af33a870182f6e4ca5c10385143b553.jpg)
画图在文件菜单栏引入打印预览、页面设置，发送，设置为桌面背景，快捷打开文件等功能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/47fc4f391f30e9241d986dcf40086e061c95f702.jpg)
画图在编辑菜单栏引入重做、清空功能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91fdd4df9c82d158fed9a84f8c0a19d8be3e42ee.jpg)
画图在视图菜单栏改进缩放功能。并引入缩略图、图片网格、文本工具栏、光标工具栏。状态栏选项。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d9d1db305c6034a87882497fc71349540b2376e5.jpg)
***
缩放功能，可选择100%、200%、400%、600%、800%
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b32ad38e8c5494eeeeb6fee721f5e0fe9b257ea9.jpg)
全屏
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/411d5e00213fb80e739090293ad12f2ebb389484.jpg)
图片网格
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/38049037afc37931898677d7e7c4b74541a91153.jpg)
画图在图像菜单栏引入翻转/旋转、拉伸/扭曲、反转颜色。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ab0c7d4d510fd9f90ffda497292dd42a2a34a458.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8b1b11084b36acafd1dc660270d98d1000e99c02.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dde29afbaf51f3deae96499a98eef01f3b297919.jpg)
画图引入图像属性，可调整像素大小以及颜色。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/eb90644e78f0f7362ffdbcff0655b319e9c413c6.jpg)
调色板。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/141351d02f2eb938975b8a0cd9628535e4dd6f0b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d7ba55564e9258fc3276109082d158cdbf4e3b.jpg)
录音机图标更换。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2dd6284b20a44623cdb0559c9422720e0ef3d7c8.jpg)
***
系统监控的关于框去除了部分文本。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/86a877395343fbf25e8056ddbc7eca8067388f92.jpg)
系统监控能正常监控之外还支持编辑项目。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a1949728bd4b31c1d0d67458bd6277f9f2ff815.jpg)

WinPad升级到1.3500，且界面精美了一些。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2c75e70b19d8bc3e87c8f6348e8ba61eaad34505.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/592cdb3fb13533faba7663d0a4d3fd1f43345b05.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68c0539a033b5bb517d2d3003ad3d539b700bc39.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e0186ffb513d2697e3d4fba359fbb2fb4216d83b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/66633eef3d6d55fb0fe685d861224f4a21a4dd26.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/150fd5fa43166d228f06e66a4a2309f79252d2d5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a649102738da977b61675d5bc51f8198718e30d.jpg)
***
写字板的工具栏图标和按钮更统一方正，默认显示标尺。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9a402dec2e738bd42a9d41cfad8b87d6257ff982.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bcf7f544d688d43fd0dc620c711ed21b0cf43bc8.jpg)
写字板在文件菜单栏引入相关打印的功能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6fdade399b504fc2d83c43fbe9dde71192ef6de6.jpg)
写字板在编辑菜单栏引入链接和对象
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5fc48e25b899a901e999a8c811950a7b0008f592.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e9f52b096e061d95a209c4c677f40ad160d9caf3.jpg)
写字板在视图菜单栏引入视图设置，支持设置自动换行、测量单位。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a9d0df98a9014c08cb22da5b067b02087af4f42d.jpg)
插入菜单栏引入插入新的对象
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b3f6d47f21fbe09a77b31ea67600c338644ad19.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6e87ecd5b31c87013b8a40182b7f9e2f0608ff02.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/678bf92e07082838bf312eeab499a9014d08f102.jpg)
***
引入面目恐怖的微笑兔 “传言”游戏，但打不开。提示派对线路错误。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d0a6ff23720e0cf310aabc050646f21fbc09aae1.jpg)
COMMAND添加了一些提示。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1b41aeeb15ce36d335bc71ce36f33a87eb50b18e.jpg)
***
1. 移除控制面板项：端口
2. 引入控制面板项：密码、电源
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68cc7831e924b8990ac18bc662061d95087bf641.jpg)
屏保设置改进，提供了预览窗口却还是图标形态。引入显示器的节能功能，支持低功耗待机、关闭显示器的电源。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d0cc19972bd40752dd2e0377899e510eb3092f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8eeffa17fdfaaf51e56a7c41805494eef21f7abc.jpg)
桌面设置的外观属性界面调整并引入调色板。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0b0f9cecab64034f042e30f8a3c3793108551d66.jpg)
桌面设置的显示属性图例更新为当时较近的版本。引入全窗口拖动/尺寸。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/38049037afc3793175677bd7e7c4b74542a91132.jpg)
界面字体9x化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf4a3e6aa17fed3572c10dfcf38.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d17bc7ed08fa513d91a09120316d55fbb3fbd938.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f8fa1ced54e736d1284f71f697504fc2d76269e1.jpg)
选项卡式键盘设置取代了之前的键盘设置。
选项卡式键盘设置引入语言选项卡，但只是个空壳。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4e007cd4ad6eddc40cb2490535dbb6fd506633e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5fc48e25b899a901ef70a6c811950a7b0008f5f9.jpg)
***
选项卡式鼠标设置取代了之前的鼠标设置。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/27fdae3c70cf3bc7d9eb3012dd00baa1cf112a5e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/01c0f00b304e251fa8161906ab86c9177d3e5364.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/39c56d54b319ebc4366c8a678e26cffc1f171629.jpg)
选项卡式鼠标设置引入光标动画，但只是个空壳。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d2acb608b3de9c82fc8404716081800a1bd84364.jpg)
调制解调器设置改进。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91acabbe6c81800a29ec75f0bd3533fa838b473c.jpg)
密码设置可以创建新密码。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4c07b0cb7bcb0a463a2577c76763f6246a60af3b.jpg)

可以选择所有用户都获得相同的桌面、用户获得个人桌面。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b227302d11dfa9ec2401aae96ed0f703908fc113.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d6bd3057e10b0828381d30fdd0.jpg)
电源设置可以查看电源状态，配置电源管理，支持在托盘上启用电池计量器。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8eeffa17fdfaaf51e64c7d41805494eef21f7a92.jpg)
***
系统属性中缺少Windows徽标。但显示了粗略的CPU型号。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e17fe0d7277f9e2f9c18e2f61330e924b999f311.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c760c3c37d1ed21b59e7d11ba16eddc450da3f13.jpg)
设备管理器按钮移到下侧，并重新出现刷新按钮，但建立、删除按钮被移除。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3ed8cc5b74543a9002c053212178a82b801140a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/035de527cffc1e170f8873cf4690f603728de90b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0f36b2638535e5ddeb395a217ac6a7efcf1b6228.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4fd025a6d933c895bf586785dd1373f08302001b.jpg)
设备管理器的一些设备的属性可以打开了。例如显卡属性直接就是显示属性，并且有资源属性。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/480e363c269759ee8a2c9f35befb43166f22dfc2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b8ede119367adab4d918e7bd87d4b31c8501e47e.jpg)
例如磁盘的属性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8be72e550923dd54706d5896dd09b3de9d824823.jpg)
***
向导式安装新硬件登场。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6d0187ff9925bc314213fe6652df8db1c91370f3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d41a971e3a292df5fb8d53ebb0315c6036a873f3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f32afb83d158ccbf41654ac415d8bc3eb335416c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b32ad38e8c5494eee8b3f0e721f5e0fe9b257eb4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/03e20a234f4a20a4f89bc3399c529822700ed0b9.jpg)

磁盘设置的大图案没有了硬盘外壳。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d8d6150f0cf3d7cabe46c088fe1fbe096963a996.jpg)

没有图标资源的程序默认图标定形，由带3.1遗留的按钮灰底窗口进化为右上三个按钮的白底窗口样式。没有图标资源的EXE是空白的文本。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c0fe7ed9bc3eb13501344845aa1ea8d3ff1f4456.jpg)
***
90c完
【Chicago99】
安装程序的标题文字大了许多，并且添加了前一步
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ab30d04443a98226b14bd1d98682b9014890ebb8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2b946b328744ebf8d0bf9ec1d5f9d72a6259a77c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0cfc09071d950a7ba2d4b43a06d162d9f0d3c965.jpg)
图标重新绘制成Beta 1风格
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08fafff4f65955ee3d6d57fbda4a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6fdade399b504fc2d60155fbe9dde71192ef6de3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/97de0758252dd42ae77be5550f3b5bb5cbeab8d0.jpg)
自定义步骤支持设置网络
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f2e5f412b07eca808152dd199d2397dda34483eb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d9d1db305c6034a8476a5c7fc71349540b2376bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/79e6d41ab051f8190ee8e7b4d6b44aed2c73e771.jpg)
修改了序列号的格式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9596e234e5dde7119609a708abefce1b9f16616e.jpg)
***
安装提醒出现了图标。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d6b6954ce10b0828381d30fd6b.jpg)
99的新图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68cc7831e924b8993e8e9fc662061d95087bf690.jpg)
这个过程被称为第二阶段。
引入名称为找到新设备的对话框。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a738e51352ac65ccbeb808df7f2b21191138a5c.jpg)
引入自动检测程序【系统检测】。

Windows检测到此计算机中的硬件发生了更改。
您希望Windows现在运行完整的硬件检测吗？这可能需要长达五分钟。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a075d86e950352a1c8fc3f65f43fbf2b0118b5c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b32ad38e8c5494eefff4e9e721f5e0fe9b257e6b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/745c39de8db1cb135392daedd154564e90584b4e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d41a971e3a292df5f2154aebb0315c6036a8736b.jpg)
安装调制解调器向导。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3fca0008c93d70cf012c4cf3f4dcd100b8a12b6b.jpg)
引入新设备安装向导【准确的说是新的安装打印机向导】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7625482fb9389b50b01106ac8935e5dde5116e5c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dfc99fddd100baa1f738aa454b10b912c9fc2e29.jpg)
***
引入欢迎对话框
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/66633eef3d6d55fb14529ed861224f4a22a4ddaa.jpg)
开始按钮的箭头符号消失，任务栏位置恢复为底部。网上邻居重新上线
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6e29c4cd7cd98d10e890e6cf2d3fb80e79ec90fa.jpg)
纸牌被移除。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1976d5b6d0a20cf4d12314217a094b36aeaf9997.jpg)
开始菜单已经支持添加项目
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d53eb6c9a786c91755f8b8c7c53d70cf39c7574e.jpg)
任务栏属性引入开始菜单的设置，主要是添加/删除程序项目
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b8ede119367adab4304cccbd87d4b31c8501e4a2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e9835e13b31bb0518e6564d63a7adab448ede085.jpg)
任务栏引入托盘，在任务栏属性中引入时间和托盘的选择
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/43bb1ff1f736afc31d4de89bbf19ebc4b5451284.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3efd750f81986184edb387a46ed2e7389d4e6a2.jpg)
任务栏的右键菜单引入排列选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b8ede119367adab432d4cabd87d4b31c8601e43a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9d3036db81cb39dbf276b6a8dc160924a918308b.jpg)
***
链接更名为快捷方式、支持创建的文件格式缩减。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e6eacfd2fd1f41348a72d580291f95cad3c85ef8.jpg)
操作系统标注有“Microsoft Chicago”和”Windows 4.00”字样，但在Winver中却显示的是 “Windows 3.95”。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/141351d02f2eb938771faa0cd9628535e7dd6fd0.jpg)
管理员配置更名为系统策略编辑器
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5ee3ed83b9014a909d069443a5773912b21bee0e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f8fa1ced54e736d1c8c551f697504fc2d7626974.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f0a59f188618367aaf7bac2322738bd4b11ce550.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c7f5c68a87d6277fe0ffe1c624381f30eb24fc51.jpg)
***
引入碎片整理程序
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e4361a1fd21b0ef422ce44a0d1c451da80cb3e1b.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4e007cd4ad6eddc46dc1680535dbb6fd5366331b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/035de527cffc1e17ec1050cf4690f603718de993.jpg)
引入网络监视器
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4903f7539822720ea85a3e0477cb0a46f01fabaa.jpg)
系统监视器图标更改
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e17fe0d7277f9e2f7bcac1f61330e924ba99f343.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4c0056accbef760992b2456122dda3cc7ed99e8d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5fc48e25b899a901ceca87c811950a7b0008f543.jpg)
引入公文包的向导
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a649102738da97752ba59d5bc51f8198418e3a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/592cdb3fb13533fa913d4cd0a4d3fd1f43345bbe.jpg)
引入超级终端，取代终端机。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f6f45df23a87e950f4b52d921c385343f9f2b4a0.jpg)
***
画图图标更改
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b7df9500fb30f240bb035fdc495d143ac4b031f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d17bc7ed08fa513db228b220316d55fbb0fbd940.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ef371e300a55b319b6ec5b8b4fa98226cefc1728.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/191a5a6c55fbb2fbdaa986ec434a20a44423dc40.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e4361a1fd21b0ef42c2946a0d1c451da83cb3e04.jpg)
WinPad升级到1.3705
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b006dd062d9f2d3df04fd11a5ec8a136227cc29.jpg)
写字板的图标定型
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/66633eef3d6d55fb259fafd861224f4a22a4dded.jpg)
打开CMD会产生花屏。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7159acee76094b367b0bc213afcc7cd98f109dad.jpg)
时间设置引入时区，控制面板移除字体和磁盘。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b3f6d47f21fbe09cd221bea67600c338544adc2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0fbe47a5462309f70d7e75ec7e0e0cf3d6cad635.jpg)
***
引入芝加哥城市壁纸，自带两张键盘壁纸。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/95cdd1013af33a875437dbe4ca5c10385143b5e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf489598c17fed3572c13dfcf89.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/222d95d2572c11df216464dd6f2762d0f503c289.jpg)
壁保可以直接预览了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f6093567d0160924954479e5d80735fae4cd34e4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/06d76ef690529822efcce33ddbca7bcb0846d443.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7159acee76094b3679b0c013afcc7cd98c109d20.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/745c39de8db1cb13b64be7edd154564e93584b20.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/16baf559d109b3de9aa23f96c0bf6c81810a4c20.jpg)
支持显示平滑字体
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f32afb83d158ccbf65a16ec415d8bc3eb0354120.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9da0314f9258d109b75d734cdd58ccbf6e814d83.jpg)
键盘设置的语言
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3304e5035aafa40f1b541423a764034f7af019b7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4fd025a6d933c89598d94285dd1373f08002009a.jpg)
新的区域设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91acabbe6c81800a135b53f0bd3533fa808b4783.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3ed8cc5b74543a9dfbc203212178a82bb01149a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/750e81cc7b899e514b30e0ea4ea7d933ca950d83.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08fade92c95955ee3d6d57fbdab0.jpg)
***
调制解调器设置改进。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/745c39de8db1cb13b48bf9edd154564e90584b60.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a7e5f7ee76c6a7ef24616dd8f1faaf51f1de66fb.jpg)

密码设置引入远程管理
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/27fdae3c70cf3bc7825f0912dd00baa1cf112ae2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9da0314f9258d109b1956d4cdd58ccbf6e814dcb.jpg)
引入access utility和accstat32，貌似和辅助程序有关
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/792fd1fc5266d01633465ad69b2bd40737fa35e2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/833aa4fcfc039245ff4526f18b94a4c27f1e2555.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11fbbef8d72a605989b826e42434349b013bba9e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d17bc7ed08fa513dab13ab20316d55fbb0fbd98d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5ab8360ed9f9d72acbccd7e3d82a2834369bbb9e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dba428c3d5628535064115df9cef76c6a5ef63a5.jpg)
***
代理程序？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a2505d8f2d3572c91ec5c228613632763d0c33c.jpg)
网络备份代理发行？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/222d95d2572c11df28df7fdd6f2762d0f603c23c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b227302d11dfa9ec082096e96ed0f703908fc13c.jpg)
新的绿方块编辑器
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/17d876dea9ec8a13e014971efb03918fa1ecc03c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/512bceed8a136327e6e302cd9d8fa0ec09fac73c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e918ed12632762d072306441acec08fa503dc63c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cae7042662d0f70317bc552204fa513d2797c53c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/23d305d1f703918f27dffd345d3d269758eec43c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/22249002918fa0ec80c9a4f32a9759ee3c6ddb3c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08fad80ed35955ee3d6d54fbda3c.jpg)
***
虚拟内存设置改进。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a9a4522bc65c1038e9060e3cbe119313b27e89ce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/86a877395343fbf20e5466ddbc7eca8067388fce.jpg)

引入WinPopup
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7159acee76094b3662eadb13afcc7cd98f109dce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8b1b11084b36acafe198560270d98d1003e99cce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/36fd2c37acaf2edd73898917811001e93b0193ce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d1038534340b447df9f13b07ec88088cf.jpg)
拨号改进
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7add4af4e0fe99254eb3a9ae38a85edf8fb17183.jpg)
关机对话框界面改进
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2b9791256b600c33265c1d36164c510fd8f9a119.jpg)
Beta 1开机界面
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89c917ce3bc79f3de19927ceb6a1cd11708b29cd.jpg)
***
【Chicago 116】
代号：Chicago
阶段：Beta 1（Milestone 6）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.116
编译时间：1994年6月1日
产品密钥：Beta Site ID: 856622; Password: e2bc24d79
时间炸弹：无

功能重点：
1.字体查看程序
2.拨号改进
3.注册向导
4.？
5.？

调教度：差
趣味度：B
成功安装使用的虚拟机：Virtual PC和86Box。
注意事项：无
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
安装程序的Windows Setup改为Chicago Setup
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dfc99fddd100baa17016275a4b10b912c9fc2e0a.jpg)
默认壁纸设置为以城市风光为背景的UNDER CONSTRUCTION。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91f4dda0cd11728b87f0edc3c4fcc3cec1fd2c63.jpg)
欢迎程序的大文字变成白色
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d9d1db305c6034a8cd83da60c71349540b2376e7.jpg)
***
引入测试版说明
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/01c0f00b304e251f39b18819ab86c9177d3e5386.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d729c645ad345982eda28d7300f431adcaef8418.jpg)
引入字体管理器，支持字体预览和打印
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0cfc09071d950a7b1442222506d162d9f0d3c9d5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4e007cd4ad6eddc49da7d81a35dbb6fd50663380.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11c9419659ee3d6d7cb1eb2a4f166d224d4aded5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d0cc19972bd407e387bf1c77899e510db30980.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/480e363c269759ee15270c2abefb43166f22dfd5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e918ed12632762d0d65dc85eacec08fa533dc6e1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a1949728bd4b31c807ff85a8bd6277f9c2ff881.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94f352fbe6cd7b8947d25662032442a7db330e8e.jpg)
***
拨号改进
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3fca0008c93d70cf943bc1ecf4dcd100b8a12b07.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d53eb6c9a786c917d57e38d8c53d70cf39c757c3.jpg)
WINBUG报告升级为1.20。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a1949728bd4b31c862ffe5a8bd6277f9f2ff831.jpg)
引入在线注册向导
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1e2beab0cb134954866582855a4e9258d3094ac9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ed9abac551da81cbf198e92c5e66d0160b2431ce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/13b79cf3b2119313e473955169380cd790238d10.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e0186ffb513d269778df62bc59fbb2fb4216d83c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/150fd5fa43166d22687b7f754a2309f79152d23c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/92ef69f51bd5ad6e1eb2300b8dcb39dbb4fd3cf9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f0a59f188618367a20282b3c22738bd4b11ce5a0.jpg)
***
引入多线程演示程序
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e8279a1e4134970a91de47ce99cad1c8a5865d93.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/38049037afc37931eff1d1c8e7c4b74541a911af.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ec5b49dca3cc7cd9e88363383501213fba0e919e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65ebf2cbd1c8a7866d6f1bef6b09c93d72cf50fb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/efa594dfb48f8c54e97094ce36292df5e2fe7fa1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bcf7f544d688d43f3e5ec013711ed21b0cf43b55.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6fdade399b504fc2babde1e4e9dde71192ef6d62.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/efa594dfb48f8c54e93194ce36292df5e2fe7f62.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4f47682542a7d9331b5fb592a14bd11371f00155.jpg)
***
【Chicago 122】
代号：Chicago
阶段：Beta 1（Milestone 6）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.122
编译时间：1994年6月10日
产品密钥：Beta Site ID: 957289; Password: 72ff2e560
时间炸弹：无

功能重点：
1.WINBUG报告升级到1.21。

调教度：差
趣味度：B
成功安装使用的虚拟机：Virtual PC和86Box。
注意事项：无
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31b401a9fc88a18367ad8b4e1d7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fa55aa10728b4710178caf2dcfcec3fdfe0323a1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e6eacfd2fd1f41340c68579f291f95cad3c85eed.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/913cc087c9177f3ec446aeec7ccf3bc79d3d56d2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/97de0758252dd42a11bb534a0f3b5bb5cbeab892.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a8f65097bf40ad1697a95025b2c11dfabecceae.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e918ed12632762d0e4a0f65eacec08fa533dc6ae.jpg)
***
【Chicago 180】
代号：Chicago
阶段：Beta 1（Milestone 6）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.180
编译时间：1994年9月10日
产品密钥：Beta Site ID: 957289; Password: 72ff2e560
时间炸弹：无

功能重点：
1.？

调教度：差
趣味度：B
成功安装使用的虚拟机：Virtual PC和86Box。
注意事项：无
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
新的安装程序界面。添加左栏图和背景更换，窗口由白底变成灰底
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/38049037afc3793125f3abc0e7c4b74541a911b0.jpg)
引入Plus附加包
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d2b1b189d43f8794a21e65c7de1b0ef419d53a6e.jpg)
选择目录步骤默认显示
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a7e5f7ee76c6a7ef0cbd85cff1faaf51f1de66b1.jpg)
用户名和Beta Site ID步骤被分离为两个步骤
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f6f45df23a87e950a1f6de851c385343f9f2b46f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3632c0eece1b9d16395cb788ffdeb48f8e5464b1.jpg)
安装程序引入早期的安装选项/安装方式步骤
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6fdade399b504fc26ed29dece9dde71192ef6dbb.jpg)
检测计算机步骤界面变为统一窗口样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fcc53b6134a85edf5e01d3ca45540923df5475bb.jpg)
检测计算机步骤界面变为统一窗口样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/36fd2c37acaf2edd0e106400811001e93b01936f.jpg)
出现安装阶段的说明
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0bc2cbae2edda3ccd20595c90de93901233f926f.jpg)
退岀被移到右下角，分步骤的图标消失
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a649102738da97704e4abc2bc51f8198418e301.jpg)
***
启动软盘类型的选择
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11c9419659ee3d6d320ca9224f166d224d4ade02.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6f7148ca977391288c2ab88f4198618347ae26c.jpg)
早期的缺少安装文件提示界面
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/32fa6bf2d7ca7bcb7fe3e9c6b2096b63f424a8b0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5ab8360ed9f9d72ae2fc3ef4d82a2834369bbbb0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4ab2951ebe096b638fb570b900338744e9f8aca4.jpg)
红色提示变成黄色描线圆圈+黑色的感叹号
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4cc7e045ebf81a4c2e9ec220db2a6059272da6a4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dea568b20f2442a7c295d34cdd43ad4bd31302b0.jpg)
***
引入配置系统程序
请等待Windows完成设置计算机的即插即用设备
这可能需要几分钟的时间
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bdeb2635970a304ec07f8a13ddc8a786cb175ceb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e6eacfd2fd1f413471d22c97291f95cad3c85e63.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b8ede119367adab40a1d32aa87d4b31c8501e47b.jpg)
现在将运行以下项目以完成设置过程：
转换程序管理器组
设定时区
安装打印机

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e8279a1e4134970ad79639c699cad1c8a5865d63.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9e6affdc3cec3fd01ff8e9cda88d43f8594270f.jpg)
引入第三阶段，第三阶段主要设置配置系统程序的步骤，比如90c的配置开始菜单向导进化成第三阶段的转换程序管理器组步骤
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/768ebdb54aed2e73c924afc58b01a18b85d6fa7b.jpg)

设置时区步骤，需要运行时间设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/42fc1cf50ad162d9a5234bf51ddfa9ec8813cd7b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a2505d8f2d3572c482fb5358613632760d0c37b.jpg)
打印机安装向导更换了新图片
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b006dd062d9f2d30fdc0d06a5ec8a136127cc7b.jpg)
***
安装打印机向导的选择设备步骤界面9x化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c7f5c68a87d6277fdcdb25d124381f30eb24fc07.jpg)
安装打印机向导一直以单窗口运行
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/43cf3cb4c9ea15ceb5dcf6e0ba003af33b87b21a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94de4f35349b033bdbbaea3319ce36d3d439bd1a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9ccfc514fc2d5623406c604eb1190ef74c66cc6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9596e234e5dde71124dc551fabefce1b9f1661c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ab30d04443a98226e5a13dce8682b9014890ebe8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e0186ffb513d2697071a1fb459fbb2fb4116d807.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/90566bf531adcbefe80668efa0af2edda2cc9f1a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9f52d91f603738d98671acbbf1bb051f919ec1b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7627b238b6003af3bddaca89392ac65c1238b6e8.jpg)
回收站回归到桌面。网上邻居的图标重新绘制为背景深蓝色天空的窗口和深青色电脑屏幕。出现了指示开始按钮的图标，是穿着蓝色西装的男人手
***
移除早期的在线注册向导。
新的“Under Construction”壁纸，色调比122的“Under Construction”壁纸更亮。

开始菜单出现了炫酷的左栏和默认较大的图标，并且条目间更宽大
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f47beb5594eef01f8415082cecfe9925be317dcf.jpg)
引入备份程序、新的CD播放器、新的记事本、直接电缆连接向导、Remote Access(远程访问、216之后的拨号网络)、磁盘碎片整理程序、磁盘扫描程序

Mixer Controls更名为音量控制。网络监视器图标重绘
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5b21ca6fddc451da80961c02bafd5266d21632ef.jpg)
一些菜单出现图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e9f52b096e061d95432527d177f40ad160d9cae9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e3381bd88d1001e99d2704e6b40e7bec55e79731.jpg)
任务栏设置出现清除文件菜单功能
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/512bceed8a13632736ded2da9d8fa0ec09fac719.jpg)
开始菜单小图标和大图标的设置，一般默认为大图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6d00c610c33874498a63f955d0fd9f9d52aa0e9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/20ad422cd42a2834489526e257b5c9ea14cebf19.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fefd0c62f6246b6065e5aa9de7f81a4c530fa261.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f6f45df23a87e9504b37e8851c385343faf2b428.jpg)
***
帮助主题的三个按钮右移。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d0a6ff23720e0cf3f72915120646f21fbc09aa76.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8808a4cfc3fdfc0305f75551d83f8794a6c22645.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/43bb1ff1f736afc3ae1d658cbf19ebc4b645123f.jpg)
新的运行界面
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ef371e300a55b31931e8d89c4fa98226cefc173f.jpg)
引入字体文件夹
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/06d76ef6905298226ced622adbca7bcb0846d476.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/833aa4fcfc0392454e3a57e68b94a4c27f1e2545.jpg)
CAB32.exe变成Explorer.exe
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65d9b32b2834349b37d8356cc5ea15ce34d3be76.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/83099b029245d6884d8d044da8c27d1ed01b2445.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b6f7148ca97739125458df88f4198618347ae2d7.jpg)
Winver中显示的是 “Windows 4.0”并变成灰底。关于框更宽大
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5ee3ed83b9014a9015141c54a5773912b21bee23.jpg)
***
磁盘属性引入工具选项卡
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf4a131a400fed3572c13dfcf74.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/411d5e00213fb80e6697fb3e3ad12f2ebb38948e.jpg)
磁盘碎片整理程序界面小修小改，图标定形。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a8f65097bf40ad1ce39340a5b2c11dfabecce74.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9ccfc514fc2d562a0a54a04eb1190ef74c66c9b.jpg)
新的DOS程序属性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f8fa1ced54e736d10f5516e197504fc2d762698e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/891e72cf36d3d5394fce952a3687e950372ab05a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1b41aeeb15ce36d32df719d936f33a87eb50b15a.jpg)
***
Explorer更新了图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7159acee76094b36512ae804afcc7cd98f109d91.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d7ba55564e9258fa2b74079082d158cdbf4e35.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/01c0f00b304e251fabe81611ab86c9177e3e5335.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/70ba421e95cad1c8e7a40ece733e6709c83d5135.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89c917ce3bc79f3db15a17d9b6a1cd11708b2991.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7159acee76094b365156e804afcc7cd98f109d0d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91b7ca4ad11373f0f7209d76a80f4bfbfaed0435.jpg)
***
系统监视器出现数字样式？
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/112ee6ca39dbb6fd323419cf0524ab18952b37e5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0bc2cbae2edda3cc817a44c90de93901233f92b7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1292b7170924ab18f3791dde39fae6cd79890be5.jpg)
WINBUG报告版本升级到1.23。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d0a6ff23720e0cf31242b2120646f21fbc09aa9c.jpg)
最早的备份程序
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e1b0ca355982b2b7242ac52d3dadcbef74099b9c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edc03e83b2b7d0a2f97cf874c7ef760949369a9c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8be72e550923dd54713a5b81dd09b3de9e824887.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f1c154fb828ba61e9e7734c64d34970a324e59b7.jpg)
***
色调暗了许多
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/17d876dea9ec8a13cabaad09fb03918fa2ecc0a9.jpg)
公文包默认使用详细信息视图并定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cae7042662d0f7033d126f3504fa513d2497c5a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2c75e70b19d8bc3e9acce3238e8ba61eaad3450c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/553a51d2d539b600e33fea5ee550352ac45cb758.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94de4f35349b033b8868193319ce36d3d739bd69.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cd45ac1249540923c2ad86979e58d109b1de490c.jpg)
一些图标接近定形、超级终端更新
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d9d1db305c6034a844265d68c71349540b23760c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/327f2011b912c8fc84371324f0039245d488210c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/141351d02f2eb9389a9d9f1bd9628535e7dd6f58.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a7e5f7ee76c6a7efc4d64dcff1faaf51f1de6658.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08fa6e87194d55ee3d6d57fbda4e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d17bc7ed08fa513d662d6634316d55fbb0fbd94e.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e0186ffb513d2697185402b759fbb2fb4116d84e.jpg)
***
WinPad也发生了变化，版本升级到1.4610，风格从移动电话风格转为了平板电脑风格
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/13b79cf3b2119313c4a8f55a69380cd793238d62.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c2d2a8fd1e178a82a89c754afa03738dab77e8a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31ba8ccc7c38a18367ad8b4e1a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/79e6d41ab051f8199c8509a0d6b44aed2c73e7a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65ebf2cbd1c8a786004940e46b09c93d72cf50ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91fdd4df9c82d1587bca535b8c0a19d8be3e4281.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf4384c5d03fed3572c13dfcfa9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/973e1cca0a46f21fed9454b9fa246b600e33aea9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bb19cc65034f78f0f269901975310a55b1191cea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ef371e300a55b319e19b889f4fa98226cdfc17ea.jpg)
***
命令提示符引入工具栏
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/750e81cc7b899e51fde54efe4ea7d933ca950de2.jpg)
控制面板引入应用程序安装向导、辅助选项、声音
移除密码

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3632c0eece1b9d166757ed8bffdeb48f8e5464b9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f86dce004c086e06361448a10e087bf408d1cb95.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e9835e13b31bb051ee98c4c23a7adab448ede095.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d7ba55564e925861a4f1049082d158cebf4eb9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d01b11c7a7efce1b04bbbf20a351f3deb68f65b9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/411d5e00213fb80ef128163d3ad12f2ebb389450.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8be72e550923dd54f8e3d082dd09b3de9e8248b9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9e6affdc3cec3fd2b44d09fda88d43f859427d3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/61cbdf0f7bec54e7ba146df4b5389b504dc26a51.jpg)
***
应用程序安装向导
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/411d5e00213fb80ef3ef103d3ad12f2eb8389417.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0bc2cbae2edda3ccfef6c9ca0de93901203f923b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3632c0eece1b9d1665e2eb8bffdeb48f8d54642c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f0a59f188618367acd860e3722738bd4b11ce5c6.jpg)
多了一张图
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cae7042662d0f703a694e43604fa513d2797c52f.jpg)
屏保预览正常了许多
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/512bceed8a13632757cbb3d99d8fa0ec09fac72f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/411d5e00213fb80ef3b9103d3ad12f2ebb3894e1.jpg)
字幕屏保已更新
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11c9419659ee3d6d6be0f6214f166d224e4ade2f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4a2505d8f2d3572c20d9ed368613632763d0c312.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b006dd062d9f2d3671e5505a5ec8a136127ccc6.jpg)
***
新的键盘设置、引入语言与输入法设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f20f24176d224f4a620303f905f790529a22d1b3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ec5b49dca3cc7cd90f7544333501213fba0e91f1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31ba2c3bdc38a18367ad8b4e1a6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6050212209f79052def237d400f3d7ca79cbd564.jpg)
新的调制解调器安装向导
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4f47682542a7d9333a3d9499a14bd11371f001bc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4fd025a6d933c89522ebe891dd1373f0800200bc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11fbbef8d72a60597cfd91f02434349b013bba64.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/efa594dfb48f8c54088bb5c536292df5e2fe7ff1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e17fe0d7277f9e2f279a6de21330e924ba99f3a6.jpg)
***
新的调制解调器设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d3e7d77fca8065387c06d7f99bdda144af348265.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89c917ce3bc79f3d30c896dab6a1cd11738b2920.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b227302d11dfa9ecbb8725fd6ed0f703938fc1a0.jpg)
新的鼠标设置，支持设置光标外观
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3ce12e9bbd99e45d688d53f2020.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d7dfb30635fae6cd9074d88b03b30f2440a70f09.jpg)
文件对话框外观变得精细了一些
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3304e5035aafa40fb206bd37a764034f7af01909.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/191a5a6c55fbb2fb7d822bf8434a20a44423dca0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ec5b49dca3cc7cd90cc147333501213fba0e9165.jpg)
新的多媒体设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/035de527cffc1e17837cffdb4690f603718de90a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9ccfc514fc2d5620be4a307eb1190ef74c66c65.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1976d5b6d0a20cf449068c357a094b36aeaf99bf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edc03e83b2b7d0a27b5f7677c7ef760949369abf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c27fc11fa8d3fd1ffb98d0d03c4e251f97ca5fb8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/01c0f00b304e251f2b669612ab86c9177d3e53b8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0253be32c895d1435fb496c97ff0820258af070b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3ce1251bbd99e45d688d63f20b8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fa55aa10728b471077d38f26cfcec3fdfe032355.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3ce1225bbd99e45d688d63f206c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9e6affdc3cec3fd2edbd59fda88d43f8594276c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/90e26e25ab18972b33c67220eacd7b899c510a55.jpg)
***
新的网络设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d53eb6c9a786c917be002fd3c53d70cf39c757ca.jpg)
新的向导式安装新硬件
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11fbbef8d72a605973289cf02434349b023bba11.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf420162503fed3572c13dfcf53.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/27fdae3c70cf3bc75903b006dd00baa1cf112aca.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3fca0008c93d70cffef9d7e7f4dcd100b8a12bca.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4c23f62297dda144df311158beb7d0a20df48611.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5d616d7a02087bf4200f2503fed3572c13dfcf6a.jpg)
区域设置改进
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c13f5edab6fd5266322841fea718972bd60736ca.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/25cc6bd6912397ddd041e5ee5582b2b7d1a28711.jpg)
***
声音设置被分离出多媒体设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8c4b0b80800a19d80ea3f9ef3ffa828ba41e46a9.jpg)
系统属性引入文件系统设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2b946b328744ebf84b9019d5d5f9d72a6259a768.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/70ba421e95cad1c8180081cd733e6709cb3d5192.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65d9b32b2834349b59e7136fc5ea15ce34d3be68.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89c917ce3bc79f3d3f5a99dab6a1cd11708b2992.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/141351d02f2eb938128c0718d9628535e7dd6f68.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a6391c889e510fb3e3b90a7dd533c895d3430ca9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7add4af4e0fe992523ed14ba38a85edf8fb17168.jpg)
***
新的设备属性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/112ee6ca39dbb6fdb22799cc0524ab18952b37d5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ebecf02ad40735fa011d325392510fb30d240864.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e4361a1fd21b0ef4c28de4b4d1c451da83cb3eec.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c13f5edab6fd5266315740fea718972bd60736d5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bb19cc65034f78f00ce6e61975310a55b1191c64.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0253be32c895d1435d1398c97ff0820258af07ec.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7c2c8c279310a554c58a21ebb4543a9802610d5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/99c7af94d143ad4b204b3a2a8e025aafa60f06ec.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cd45ac12495409237bc31f949e58d109b1de49a3.jpg)
***
新的关闭WINDOWS对话框
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94cbe095a4c27d1e05bb472e17d5ad6edfc438b4.jpg)
【Chicago 189】
代号：Chicago
阶段：Beta 1（Milestone 6）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.189
编译时间：1994年9月21日
产品密钥：Beta ID：101907密码：999b70c9e
时间炸弹：无

功能重点：
1.？

调教度：差
趣味度：B
成功安装使用的虚拟机：Virtual PC和86Box。
注意事项：无
安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.在DOS下输入fdisk进入fdisk主页并按1创建分区，然后在fdisk主页按2设置主分区。
3.输入format c: 命令格式化分区。
4.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7d9932fab2fb43166b5f30902ca446230bf7d389.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/891e72cf36d3d5399e07ba293687e950342ab013.jpg)
正式定名Windows 95，安装程序的窗口外观和元素更立体
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0fbe47a5462309f79bc0e7f87e0e0cf3d5cad6a6.jpg)
四种安装方式都可以选择
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/22249002918fa0ecf6862ee72a9759ee3f6ddb89.jpg)
安装程序的步骤调整
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/20ad422cd42a2834159c83e157b5c9ea14cebf13.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edc03e83b2b7d0a232f3b177c7ef76094a369a13.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/50cc3442fbf2b211a0becfa4c68065380ed78eb9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/65d9b32b2834349b2046246fc5ea15ce34d3be89.jpg)
检测到硬件会显示出来供选择
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9da0314f9258d109c7a3e358dd58ccbf6e814d89.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89c917ce3bc79f3d77db51dab6a1cd11738b2913.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a6391c889e510fb3a43fcb7dd533c895d0430c2f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7c2c8c279310a550c52621ebb4543a9802610df.jpg)
窗口和进度条的背景为灰色。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2c75e70b19d8bc3ec31bba208e8ba61ea9d3453a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/592cdb3fb13533faf6a52fc4a4d3fd1f40345b3a.jpg)
安装程序的背景清晰了许多
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fa55aa10728b4710353c4126cfcec3fdfd03233a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3ce4cd375d99e45d688d53f203a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e17fe0d7277f9e2fdb64a1e21330e924ba99f3f9.jpg)
新的开机屏幕，蓝天白云背景的Windows 95字样
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/22249002918fa0ecfc96d8e72a9759ee3f6ddbf9.jpg)
配置系统程序
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ed9abac551da81cba7963f275e66d0160b2431d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5b21ca6fddc451da1c86b001bafd5266d21632d9.jpg)
***
新的欢迎程序。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91f4dda0cd11728bcdfb33c8c4fcc3cec1fd2c7f.jpg)
引入Windows Tour
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ca76de004a90f603ba1c23ad3512b31bb251eda6.jpg)
Windows Tour内的开始菜单左栏是蓝色的Windows字样与徽标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fa55aa10728b471032f94226cfcec3fdfe03237f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0b0f9cecab64034fc1627deca3c3793108551da6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edc03e83b2b7d0a2383dbb77c7ef760949369a5d.jpg)
***
移除Chat。拨号程序和多线程演示程序图标重绘
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a6391c889e510fb3a6dec97dd533c895d3430c0e.jpg)
引入DriveSpace
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edbfb61273f08202eb9528d547fbfbeda9641bce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0b0f9cecab64034fcfe37beca3c379310b551d27.jpg)
搜索程序出现右下角的放大镜图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11fbbef8d72a6059375958f02434349b013bba80.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d7ba55564e9258b6f538049082d158cebf4e08.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08faa34eaa4d55ee3d6d57fbda80.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9d3036db81cb39db2aeedebcdc160924aa183027.jpg)
Windows 95的帮助初具规模
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a00afe24bc315c606a54d50581b1cb134b547708.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/22249002918fa0ecf9c0dde72a9759ee3f6ddbcf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8c4b0b80800a19d8d24a3def3ffa828ba41e4680.jpg)
快捷方式小箭头的白框样式。
***
用火烧毁回收站内的文件
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1976d5b6d0a20cf4019944357a094b36aeaf99c0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edbfb61273f08202f0c737d547fbfbeda9641bfc.jpg)
DriveSpace
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b006dd062d9f2d3b6e68205a5ec8a136127cc5f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91e714f182025aaf0f65d821f7edab64014f1afe.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68c0539a033b5bb5d82186143ad3d539b400bc5f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d6f7150df50b0828381d30fdff.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08fabaacb54d55ee3d6d57fbdaa6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/11c9419659ee3d6dba6a21214f166d224d4adea6.jpg)
***
默认壁纸是安装程序的背景

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6050212209f790526f58e6d400f3d7ca79cbd58f.jpg)
调色板的界面几乎定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f7b124a88226cffca4861e58b5014a90f403eaa6.jpg)
拨号程序界面调整，比如小数字键盘和快速拨号互相换家
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/745c39de8db1cb1310909df9d154564e90584b50.jpg)
可用Windows 键打开开始菜单
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e8279a1e4134970a5f8ab1c599cad1c8a5865d50.jpg)
写字板的设置引入许多选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9da0314f9258d109ec1a0858dd58ccbf6e814d50.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a00afe24bc315c606101ca0581b1cb134b5477bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7d9932fab2fb43169cb3db902ca446230bf7d3a6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/1c9453a95edf8db193badd8e0523dd54544e74bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/967cb33e8794a4c2f6da46c102f41bd5af6e3950.jpg)
***
辅助选项引入键盘重复设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0fbe47a5462309f764d50ef87e0e0cf3d5cad69c.jpg)
设备的图标由天蓝色变成深蓝色
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d10385343e2e825cb9f13b07ecb80882e.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fefd0c62f6246b60f2aa1f9ee7f81a4c530fa2ae.jpg)
设备管理器的图标消失
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/89e3183f6709c93d044da31d933df8dcd3005496.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dea568b20f2442a747b1504fdd43ad4bd3130296.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/fa55aa10728b4710c4c65026cfcec3fdfe032360.jpg)
系统属性的虚拟内存和文件系统设置独立至性能选项卡，虚拟内存设置布局调整。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4fd025a6d933c89571c13591dd1373f080020096.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/035de527cffc1e173d0021db4690f603718de997.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e918ed12632762d017a30b55acec08fa533dc6b5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/68c0539a033b5bb5c0678e143ad3d539b400bc99.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5b21ca6fddc451da0d4ea301bafd5266d2163291.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cae7042662d0f703702f3a3604fa513d2497c5b5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8be72e550923dd54003a0882dd09b3de9e824880.jpg)
***
【Windows 95 Build 216】
代号：Chicago
阶段：Beta 2（Milestone 7）
架构：x86（16-Bit混合）
安装的语言：英文
版本字串：4.0.216
编译时间：1994年10月28日
产品密钥：Beta Site ID: 508078; Password: 257625f24

功能重点：
1.时间炸弹
2.一系列界面、元素、图标的调整
3.回收站正式定名
4.安装程序会为你介绍Windows 95的新特性
5.开机屏幕显示为Beta 2
6.账户功能和注册向导重新上线

7.引入硬件配置文件的支持
8.WinPad1.0.4915

9.移除多线程演示程序和剪贴板
10.引入传真封面编辑器
11.引入传真查看器
12.引入注册微软网络程序
13.引入邮件文件转换器
14.引入Microsoft Exchange

建议虚拟机：86Box。

安装方式：

建议使用Virtual PC或86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.如果已创建并激活分区。可直接输入format c: 命令格式化分区。
3.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2dd6284b20a44623d7413b889422720e0ef3d743.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/6050212209f790527894d9d400f3d7ca79cbd543.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7f7f68ea0ec08fa82e68d4d55ee3d6d57fbda68.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f20f24176d224f4afcd9edf905f790529a22d18a.jpg)
安装程序的窗口下面出现了一条灰色的分隔线
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0bc2cbae2edda3cc67a726ca0de93901233f928a.jpg)
安装程序在复制文件的过程中会介绍Windows 95的新特性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d0cc19972bd407b7da4b1777899e510eb30934.jpg)
Windows 95可以让当时硬件的性能，发挥到极限
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9e6affdc3cec3fd904a3f9fda88d43f859427dd.jpg)
Windows 95让你轻易上手，Windows 95提供各种工具，大大提高你的工作效率
开始菜单让你简单的启动程序
我的电脑可以让你使用电脑上所有的文件
任务栏可以让你切换程序
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0cfc09071d950a7bc0c1d62e06d162d9f0d3c95e.jpg)
介绍联机注册后的优越性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/91acabbe6c81800a52c812e4bd3533fa838b4724.jpg)
在第一次启动时出现“请稍候，安装程序正在准备您的Windows环境”界面
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cae7042662d0f7035f730d3604fa513d2497c509.jpg)
***
开机屏幕显示为Beta 2
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a1949728bd4b31c37d011518bd6277f9c2ff866.jpg)
时间炸弹触发后的开机失败的提示
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a9d0df98a9014c08d2d5ad4f067b020879f4f460.jpg)
缺少文件的对话框
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/95cdd1013af33a8712f685f0ca5c10385143b5b3.jpg)
网络设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c13f5edab6fd5266aae8b9fea718972bd607360a.jpg)
网络设置的计算机名称和工作组
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f6093567d0160924d7e627f1d80735fae4cd340a.jpg)
网络设置的共享设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/39c56d54b319ebc42dbbf3738e26cffc1c17160a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/13b79cf3b2119313b3d97a5a69380cd793238db3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a9a4522bc65c1038ac904b28be119313b27e8960.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e9f52b096e061d95b625b0d277f40ad160d9caeb.jpg)
账户功能重新上线
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0a1949728bd4b31c28ee10518bd6277f9c2ff804.jpg)
***
可以通过点击地图选择时区
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/303b5cc69f3df8dc8943027bc111728b451028d7.jpg)
欢迎程序的Windows 95字样字体平滑化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d1038534303ea0acb9f13b07ecb80882d.jpg)
Windows Tour改名为Windows 95 Tour
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d8d6150f0cf3d7caac8eb29cfe1fbe096963a9d2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/23d305d1f703918f6484b0205d3d26975beec4fd.jpg)
开始菜单的左栏背景是纯灰色的并写上Windows 95字样（Beta 2风格）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/a529801090ef76c686f676c19116fdfaae51672d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/50cc3442fbf2b211695608a4c68065380ed78ed2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cd45ac1249540923ea6aee949e58d109b1de49ca.jpg)
***
任务栏属性定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7c2c8c279310a553f9e571ebb4543a980261093.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0b0f9cecab64034fff774beca3c3793108551d93.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7b33f83cf8dcd100efe871cb7e8b4710bb122fdd.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/553a51d2d539b600d774865de550352ac45cb79c.jpg)
帮助主题支持搜索帮助

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/112ee6ca39dbb6fd3e216dcc0524ab18952b37d3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4e007cd4ad6eddc438063d1135dbb6fd50663368.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/49d7ba55564e9258e7fd0f049082d158cebf4e00.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/9da0314f9258d109842a2058dd58ccbf6e814d00.jpg)
运行定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f2e5f412b07eca809d71b10d9d2397dda34483de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c722407e9e2f07088072a1eae524b899ab01f2df.jpg)
***
磁盘属性的工具选项卡界面定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0b0f9cecab64034ffdc649eca3c3793108551dc2.jpg)
磁盘修复工具的界面定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3379ce763912b31b290646c38a18367ad8b4e1ec.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8c4b0b80800a19d880b80fef3ffa828ba41e4692.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3ed8cc5b74543a90c10712612178a82bb0114c2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cd45ac1249540923ec8ae8949e58d109b1de496a.jpg)
写字板出现启动画面。foundation classes版本3.0
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/746f643a5bb5c9eaf3c48909d939b6003bf3b31f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/94de4f35349b033bbfbf763019ce36d3d439bd1f.jpg)
兔子的界面
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f86dce004c086e06b0e3caa10e087bf408d1cb83.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7d9932fab2fb4316a86d8f902ca446230bf7d3e4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edc03e83b2b7d0a2f2d2f177c7ef76094a369a33.jpg)
CD播放器定形
***
超级终端的新界面

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a075d86e950352a2d60d2e25f43fbf2b0118bc9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d17bc7ed08fa513d9ba89b34316d55fbb0fbd9d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/75dea15d10385343154c70cb9f13b07ec880884b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/25cc6bd6912397dd56c56fee5582b2b7d2a28796.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/06d76ef690529822b831ce29dbca7bcb0846d4d4.jpg)
画图的新图标，装着彩笔的黄色油桶。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4c0056accbef76094b426e7522dda3cc7ed99e80.jpg)
WinPad1.0.4915
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ed9abac551da81cb5c1e74275e66d0160b243151.jpg)
控制面板出现字体文件夹、打印机文件夹并重新上线密码项目，应用程序安装向导演变成添加/删除程序项目
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/833aa4fcfc0392458f6e16e58b94a4c27f1e2572.jpg)
辅助选项出现“在程序里显示额外的键盘帮助”选项
***
添加/删除程序项目
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/39c56d54b319ebc4374089738e26cffc1f171611.jpg)
安装程序之后组件支持可选安装。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7add4af4e0fe99259df09aba38a85edf8fb17155.jpg)
添加/删除程序的启动盘选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dfc99fddd100baa18610b5514b10b912c9fc2e15.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b0eb5d282df5e0feb9e47aeb506034a85cdf7255.jpg)
单选按钮的元素由菱形变成圆形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/07e4de13c8fcc3ce92fc3bd99e45d688d53f2015.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f6093567d0160924ce3c50f1d80735fae7cd3430.jpg)
拉条宽大了许多
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f1c154fb828ba61e91123bc54d34970a324e5955.jpg)
键盘设置的语言设置布局更科学
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cde466e83901213fbde0bd3658e736d12d2e957a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9ccfc514fc2d5628bdb2307eb1190ef74c66c7a.jpg)
点击箱子会出现小丑的动画
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/dea568b20f2442a7b6170f4fdd43ad4bd0130230.jpg)
***
网络设置的共享选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/cde466e83901213fbad4b23658e736d12d2e956e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b7c2c8c279310a55cc9b221ebb4543a980261096.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/06d76ef690529822b1c8c529dbca7bcb0846d453.jpg)
密码设置定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e4361a1fd21b0ef4420f64b4d1c451da83cb3e6e.jpg)
引入标准的管理员账户
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ca76de004a90f603f92260ad3512b31bb251ed44.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/5ee3ed83b9014a907facba57a5773912b11bee44.jpg)
国际设置引入地图

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c0fe7ed9bc3eb135016a4851aa1ea8d3ff1f44a4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b0eb5d282df5e0fe850c76eb506034a85fdf723d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/730ee58aa61ea8d3cb8f8bee9b0a304e271f58a4.jpg)
声音设置的布局更科学
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7add4af4e0fe9925a11896ba38a85edf8cb1713d.jpg)
***
系统属性的主页简化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/25cc6bd6912397dd4ca761ee5582b2b7d2a28770.jpg)
设备管理器重新拥有了图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d1d7f0dca144ad34b6617e6ddca20cf433ad8570.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c2f63daea40f4bfb8f3f67be0f4f78f0f5361866.jpg)
添加对硬件配置文件的说明
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4aa1d418ebc4b7453c3c4efcc3fc1e17888215a1.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/035de527cffc1e17095075db4690f603718de967.jpg)
WinPopup定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c2d2a8fd1e178a823dd3864afa03738dab77e867.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/592cdb3fb13533fab2886bc4a4d3fd1f40345b17.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3fca0008c93d70cf044851e7f4dcd100b8a12b9b.jpg)
新的关闭对话框，已定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f32afb83d158ccbf45ce4ed015d8bc3eb33541db.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3ed8cc5b74543a9fc04012612178a82b8011436.jpg)
9.移除多线程演示程序和剪贴板
10.引入传真封面编辑器
11.引入传真查看器
12.引入注册微软网络程序
13.引入邮件文件转换器
14.引入Microsoft Exchange
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e772ae167f3e6709f4acbe1537c79f3dfadc55a5.jpg)
Microsoft Exchange安装向导
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bb06d5109313b07e2fa7aae200d7912396dd8c3c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/25cc6bd6912397dd4b0e62ee5582b2b7d2a287df.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/2dd6284b20a44623b3fb5f889422720e0df3d719.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0bc2cbae2edda3cc840643ca0de93901233f9274.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3c2dea1101e93901da1877d477ec54e737d1963c.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/0253be32c895d143c7651ec97ff082025baf073a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/edbfb61273f0820235496ad547fbfbeda9641b72.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f3e8e000a18b87d6b32e51f50b0828381d30fde6.jpg)
网络监视器
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/c7f5c68a87d6277f0b7ec8d224381f30eb24fce6.jpg)
系统监视器定形
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a738e51352ac65ccf2c9c99f7f2b21192138a21.jpg)
传真封面编辑器
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/b2ebd9086b63f624ad76c3e98b44ebf81b4ca323.jpg)
欢迎程序的第二次启动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/7a738e51352ac65ccfa99c99f7f2b21191138aa6.jpg)
传真查看器
***
【Windows 95 Build 222】
代号：Chicago
阶段：Beta 2（Milestone 7）
架构：x86（16-Bit混合）
安装的语言：德语
版本字串：4.0.222
编译时间：1994年11月9日
产品密钥：Beta ID：101907 密码：94730fb34
功能重点：
1.德语的默认壁纸，采用宇宙与地球在一起的背景
2.荷兰语的普通安装背景壁纸上加了一些版本信息
3.WINBUG报告版本为1.31
4.安装程序添加了一些对网络和硬件相关的步骤
建议虚拟机：86Box。

安装方式：

建议使用86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.如果已创建并激活分区。可直接输入format c: 命令格式化分区。
3.插入WIindows ME 启动盘输入光驱盘符并输入setup。
***
安装程序添加了一些对网络和硬件相关的步骤
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4903f7539822720e2058b61677cb0a46f01fabb9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e8279a1e4134970a927544c399cad1c8a5865dc9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/e9f52b096e061d9507e363d477f40ad160d9caae.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/3b3f6d47f21fbe0959c897f867600c338544adb9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/891e72cf36d3d539f17a5b2f3687e950372ab088.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/f9ccfc514fc2d562f64f8401eb1190ef74c66c88.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d7dfb30635fae6cdabb2ff8d03b30f2440a70fc9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/8b1b11084b36acaf4d76c21070d98d1003e99cb9.jpg)
德语的默认壁纸，采用宇宙与地球在一起的背景
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/150fd5fa43166d226a3141784a2309f79252d289.jpg)
WINBUG报告版本为1.31
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/d3e7d77fca806538597af0ff9bdda144af3482bb.jpg)
***
【Windows 95 Build 224】
代号：Chicago
阶段：Beta 2（Milestone 7）
架构：x86（16-Bit混合）
安装的语言：英语
版本字串：4.0.224
编译时间：1994年1月9日
产品密钥：Beta ID：101907 密码：94730fb34
功能重点：
1.注册Microsoft 网络程序的新图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/bcf7f544d688d43f3ff3c11e711ed21b0cf43bfd.jpg)

2.WINBUG报告版本为1.32
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/ec5b49dca3cc7cd9efad64353501213fba0e914b.jpg)

3.系统策略编辑器重新上线
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5659241446/4ab2951ebe096b63d8390dbc00338744eaf8ac2b.jpg)

建议虚拟机：86Box。

安装方式：

建议使用86Box上执行此操作。
1.插入DOS-DOS 6.22的启动盘。
2.如果已创建并激活分区。可直接输入format c: 命令格式化分区。
3.插入WIindows ME 启动盘输入光驱盘符并输入setup。
