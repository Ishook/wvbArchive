我先说一下为什么没有人安装Windows Whistler Server呢？今天我准备尝试更新Windows Server 2003史。
请问一下，有人看吗？[滑稽]
***
首先是5.1.2267.1
Windows Whistler Server build 2267
阶段：Technical Beta
架构：x86
版本：Advanced Server
字串：5.1.2267.1.idx01.000910-1316
日期：2000年09月11日
密钥：没有适用于此beta的密钥
事项：无
[喷]这个可还行吧
***
开始更了！
首先就是熟悉的蓝白的安装界面[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/42fc1cf50ad162d90fbf23f61fdfa9ec8813cdf9.jpg)
我勒个去！[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/768ebdb54aed2e736338c7c68901a18b85d6fa79.jpg)

是不是未分区啊？！
***
祈祷ing[开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d7dfb30635fae6cdc3e1e98b01b30f2440a70ffc.jpg)
我去！[怒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/b2ebd9086b63f62470cf74e98944ebf8184ca3bb.jpg)
***
我知道了，把系统选择为Windows Server 2000不久可以了[惊讶]！继续！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/07e4de13c8fcc3ce58b887d99c45d688d63f20d1.jpg)
没有盘符？现在DOS下分区
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/f243b7a30cf431ad88530dd34536acaf2cdd9848.jpg)
***
算了，明天继续，分区在PE下看看行不行
复制文件中[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d1d7f0dca144ad3450fb026ddea20cf433ad858d.jpg)
然后是一点也不正经的磁盘检查[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/edbfb61273f08202d1f314d545fbfbeda9641be8.jpg)
***
接下来就是安装向导了。。诶，这个我还是怎么熟悉？[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/94de4f35349b033baa0d79301bce36d3d739bd4d.jpg)
安装程序居然卡住了？！[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/edc03e83b2b7d0a2070b8077c5ef760949369a0b.jpg)
这个步骤要卡这么长的时间啊[喷]
***
重启之后……
几秒钟？几分钟才对吧！[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/91b7ca4ad11373f00aaee875aa0f4bfbf9ed04b8.jpg)
终于好了，原来装Management and Monitoring Tools耗得时间最长！[喷]幸亏这次不勾选这个了[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/a9a4522bc65c1038a95e4828bc119313b17e892a.jpg)
终于可以了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/bcf7f544d688d43fe0841018731ed21b0ff43b24.jpg)
***
打开MSN之后：我又不住在淮南！[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/1b41aeeb15ce36d325b103da34f33a87eb50b19d.jpg)
还有经典的开始菜单以及登录样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/c13f5edab6fd5266a215bffea518972bd5073617.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/6e29c4cd7cd98d1011bd8fdb2f3fb80e79ec90e0.jpg)

这个关机/重启/注销都要注明原因差评！[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d2acb608b3de9c82ec7d7a656281800a18d84331.jpg)

合影！[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/e918ed12632762d035812755aeec08fa533dc697.jpg)
***
最后：Windows Server天天想要搞得套路:
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/fefd0c62f6246b60d2a4319ee5f81a4c530fa2ac.jpg)
按Ctrl+Alt+Delete以登录[滑稽]
***
接下来是5.1.2296.1

Windows Whistler Server build 2296
阶段：Beta 1
架构：x86
版本：Advanced Server
字串：5.1.2296.1.beta1.001024-1157
日期：2000年10月25日
密钥：没有适用于此beta的密钥
事项：无
***
开机音终于变得清晰了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/746f643a5bb5c9eaf0ef8809db39b6003bf3b336.jpg)
还有，这个是啥？服务器设置向导[疑问]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/2b9791256b600c3350ec5522144c510fdbf9a1bd.jpg)
打开WMP之后，Beautiful　Way就来了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/f32afb83d158ccbf5b443ed017d8bc3eb3354151.jpg)

装个显卡试试？
***
啊，上一次要写原因的，这次居然不用了？[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/c7b08cf91a4c510f031568f06e59252dd62aa579.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/b8ede119367adab4d0e9eea985d4b31c8601e411.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/0a1949728bd4b31c18cc1e5189d6277f9c2ff85a.jpg)
以上是其他细节的截图。但是为什么要默认的显示经典主题呢？[喷]
而且还要手动开启桌面体验（不知道怎么弄），并出现疑似联机的功能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/8b1b11084b36acaf2d2a1c1672d98d1003e99c03.jpg)
合影[胜利][滑稽][胜利]两个名字集齐。[笑眼]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/f08aad8165380cd764705707af44ad345b8281e0.jpg)
***
在看我的帖子的回[滑稽]
开始安（sheng）装（ji）！[滑稽]这个居然开始有CD界面了？[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/b7c2c8c279310a55dbe9351eb94543a980261004.jpg)
看看能不能尝试一下升级安装[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/e0186ffb513d2697f91be3b75bfbb2fb4116d802.jpg)
输入完序列号了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3b3f6d47f21fbe09d9f029fe65600c338544ada0.jpg)
***
这个新的安装程序的界面和以前的不同了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3b1833e636d12f2e57787b8a41c2d562873568d5.jpg)

对了，上面部分的是16位色[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/f6093567d0160924e1f977f1da0735fae4cd3475.jpg)
***
夭寿了！回收站成精了！[怒]成塑料袋了[喷]！同时也出现了一些Windows XP的图标。[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/f7b124a88226cffc742f6858b7014a90f403eacd.jpg)

运行的图标变成了奔跑的人形[滑稽]开始菜单的右边变成了Windows 2000 Advanced Server

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3b006dd062d9f2d3d817f205a7ec8a136127ccc8.jpg)

好了，直接合影[喷]
***
接下来的几天就来搞Windows Whistler Server BETA 2了
[滑稽]
告辞
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/0fbe47a5462309f733957df87c0e0cf3d5cad65c.jpg)
***
明天上午要更新：
5.1.2340.1
5.1.2433.1
明天下午要更新：
5.1.2455.1
5.1.2462.1
还有pandownload下载403怎么解决[喷]
***
接下来是：5.1.2430.1
Windows Whistler Server build 2430
阶段：Beta 2
架构：x86
版本：Datacenter Server
字串：5.1.2430.1.main.010130-1821
日期：2001年01月30日
密钥：F6PGG-4YYDJ-3FF3T-R328P-3BXTG
事项：无
Datacenter Server？数据中心服务器？[喷]
***
这个CD界面，跟Windows XP的是有的一批[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/e9835e13b31bb051e9aec3c3387adab448ede04c.jpg)
不能直接升？！[喷]全新安装！[升起]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/150fd5fa43166d2270f4657f482309f79252d24b.jpg)
***
这个安装程序差不多和Whistler 2462~2465是一样的[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/4c23f62297dda144dcfb1e59bcb7d0a20ef48664.jpg)
[怒]
川普：mmp！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/90566bf531adcbef016d03eda2af2edda1cc9ff1.jpg)
***
等待ing[睡觉]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/973e1cca0a46f21ff9b422b8f8246b600e33ae4a.jpg)
这个界面也是醉了[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3b7df9500fb30f24ab7693e8c695d143af4b0366.jpg)
这里已经有了更多的Windows XP图标[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/e4361a1fd21b0ef4ce99e6b5d3c451da83cb3ed9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/b828b601baa1cd11b4b70ccbb712c8fcc1ce2dc9.jpg)

还有，关机/重启/注销都已经要求注明原因了？[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d53eb6c9a786c917c3012cd2c73d70cf39c757d4.jpg)
***
控制面板和资源管理器被丑化差评[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3b1833e636d12f2e3a83d08b41c2d56287356848.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/61cbdf0f7bec54e7b76a64f5b7389b504dc26a48.jpg)

IE的图标也不知道丑化成什么样子了[喷]，但是界面有大改变好评！[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/191a5a6c55fbb2fb755321f9414a20a44423dcd2.jpg)

最后合影！[胜利][滑稽][胜利]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/efa594dfb48f8c5407a3bcc434292df5e2fe7fda.jpg)
***
接下来是5.1.2433.1

Windows Whistler Server build 2433
阶段：Beta 2
架构：x86
版本：Advanced Server
字串：5.1.2433.1.main.010206-1822
日期：2001年02月06日
密钥：DW3CF-D7KYR-KMR6C-3X7FX-T8CVM
事项：无
[太开心]估计要慢慢的Windows XP化了？
***
又来这一套？！[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/0bc2cbae2edda3cc0b34c0cb0fe93901233f927a.jpg)
从60~90分钟一直变成了46分钟，什么鬼？！[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/17d876dea9ec8a134b412c0bf903918fa2ecc0f3.jpg)

然后…………[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/c760c3c37d1ed21bdf68550ea36eddc453da3fa9.jpg)

Emmm，还可以吧[惊讶]
***
登陆界面终于变成彩色的了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d1d7f0dca144ad343154e36cdea20cf433ad8563.jpg)
资源管理器和IE的图标变小了[冷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/fa55aa10728b47107bf09927cdcec3fdfe032377.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/ab30d04443a9822636b14ccc8482b9014890ebdb.jpg)
但是这改动的也太小了吧[喷]上合影！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/112ee6ca39dbb6fd870182cd0724ab18952b37fc.jpg)
***
居然没人了[喷] @人 
@孙必林 
@夏日玫瑰 
@兰兰和随随
***
接下来的是5.1.2455.0

Windows Whistler Server build 2455
阶段：Beta 2
架构：x86
版本：Server
字串：5.1.2455.0.main.010307-1659
日期：2001年03月08日
密钥：DW3CF-D7KYR-KMR6C-3X7FX-T8CVM
事项：无
[滑稽]被@的人 过来看一下啊
***
这都弹了几次这样的窗口了[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/75dea15d10385343c2c9c7ca9d13b07ec88088c8.jpg)
安装程序窗口的左边已经变了好评[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/1a5bc30e4bfbfbed609d779476f0f736adc31f0e.jpg)
***
安装时间有点漫长，先搞点事情[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/dea568b20f2442a7626eb14edf43ad4bd31302ea.jpg)
***
新的开机画面好评[真棒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d7dfb30635fae6cdcedde48a01b30f2440a70fe1.jpg)

但是这个也只改了个开机画面吧[冷]合影！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/09a06e22dd54564ee78dabd2bdde9c82d3584f62.jpg)
--------------------------------------------------------------------------------------------------------------

甲：像你这样只改开机画面的，除了我要，还有谁要？
乙：放屁，就算你不要，也有……
广告：蟑螂要（药）、老鼠要（药）、白蚁要（药）、蚂蚁要（药）、跳蚤要（药），药效真起效
甲：哈哈哈哈哈[笑眼]
乙：草！
***
然后是5.1.2462.0

Windows Whistler Server build 2462
阶段：Beta 2
架构：x86
版本：Advanced Server；Datacenter Server；Server
字串：5.1.2462.0.main.010315-1739
日期：2001年03月08日
密钥：
Advanced & Datacenter Server:
QB2BW-8PJ2D-9X7JK-BCCRT-D233Y
Server:
F6PGG-4YYDJ-3FF3T-R328P-3BXTG
事项：无
语言：

Chinese (Simplified, PRC)
Chinese (Traditional, Taiwan)
English (United States)
German (Germany)
Japanese (Japan)
Korean (Korea)
***
首先是，图标慢慢的趋向于Windows XP的样式了[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/b32ad38e8c5494eeae3eb8f223f5e0fe98257e36.jpg)
但是这个改的跟没改一样[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/2ef27a940a7b020890dd890a6cd9f2d3562cc83f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/ed9abac551da81cb9a6334265c66d0160b24314d.jpg)
***
然后是5.1.2463.0
Windows Whistler Server build 2463
阶段：Beta 2
架构：x86
版本：Server
字串：5.1.2462.0.main.010328-1824
日期：2001年03月29日
密钥：DW3CF-D7KYR-KMR6C-3X7FX-T8CVM
事项：无
语言：English (United States)

上个版本居然是刷版本号的，气死我了[怒]
***
草，16色[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d2acb608b3de9c82d5f123646281800a1bd843be.jpg)

哈哈哈哈哈哈哈哈哈哈哈，终于不是16位了（smg？[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/fccad63433fa828ba94f4508f31f4134950a5ae6.jpg)
***
接下来是5.1.2465.0

Windows Whistler Server build 2464
阶段：Beta 2
架构：x86
版本：Server
字串：5.1.2465.0.main.010410-1500
日期：2001年04月11日
密钥：CXGDD-GP2B2-RKWWD-HG3HY-VDJ7J
事项：无
语言：English (United States)
居然又换了一个序列号[冷]
***
我去，登不上去了[喷]！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/23d305d1f703918fff6f13265f3d26975beec491.jpg)
***
重新格盘安装之后：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/480e363c269759ee5d354a27bcfb43166f22dfee.jpg)

Windows XP的主题居然出来了[花心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/91e714f182025aafb9d95427f5edab64014f1a63.jpg)

图标也越来越Windows XP化了，同时，经典徽标已经被取代了[笑眼]
最后合影[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/68c0539a033b5bb549dd371238d3d539b400bccd.jpg)
***
今天的更新借宿，明天看看我能不能在一天之内搞定BETA 2呢？
接下来是5.1.2467.0
Windows Whistler Server build 2467
阶段：Beta 2
架构：x86
版本：Server
字串：5.1.2467.0.main.010418-1202
日期：2001年04月19日（就差8天？[喷]）
密钥：CXGDD-GP2B2-RKWWD-HG3HY-VDJ7J
事项：无
语言：English (United States)
***
安装程序已经Windows XP化了[真棒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/efa594dfb48f8c54c9d772c334292df5e2fe7fcf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/9596e234e5dde711c3cbf41aa9efce1b9c166132.jpg)

当然，安装程序依然是蓝白安装程序[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/94cbe095a4c27d1e4e358c2815d5ad6edfc438c4.jpg)
还有没有改的开机画面[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/61cbdf0f7bec54e77c3dadf2b7389b504dc26a7a.jpg)

还有，为什么我在电脑上发完一条回复就要自动的返回顶部呢？[喷]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/191a5a6c55fbb2fbbfdfebfe414a20a44423dc58.jpg)
emmm，就是把开始菜单XP化后就没有了[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/91b7ca4ad11373f036c3dc73aa0f4bfbf9ed0457.jpg)

然后这么快就结束了[喷]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/9596e234e5dde711dabbfd1aa9efce1b9f1661e2.jpg)
沙雕百度，你居然在吞我楼[喷]
***
接下来是5.1.2493.0

Windows Whistler Server build 2493
阶段：Beta 2
架构：x86
版本：Advanced Server
字串：5.1.2493.0.main.010612-1737
日期：2001年06月13日
密钥：CXGDD-GP2B2-RKWWD-HG3HY-VDJ7J
事项：无
语言：English (United States)
到这之后就是35xx了吧
***
估计是版本不一样就不能直接升级了？[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/4e007cd4ad6eddc4c69c0d1737dbb6fd506633dc.jpg)
***
这里变成了Windows XP
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/86a877395343fbf291431fcfbe7eca8067388fe0.jpg)
到那里却变成了Windows 2002 Advanced Server了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/0a1949728bd4b31c55c82d5789d6277f9c2ff858.jpg)
***
新的开机画面，但是此时上面没有字[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/22249002918fa0ece706dde1289759ee3f6ddb0b.jpg)
***
安装之后：服务器设置向导左侧的已经换了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/43cf3cb4c9ea15ce23295ae5b8003af33887b208.jpg)
同时右下角的水印已经变成了Windows XP Advanced Server了[太开心]
***
激活Windows也变成了Windows XP的风格了[太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3b3f6d47f21fbe096a4a66f865600c338644ad3f.jpg)
开始菜单的图标已经变成了Windows XP的样式了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3c2dea1101e93901190c28d275ec54e734d196c1.jpg)

合影，我感觉这个越来越向Windows XP的方向发展了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/f0a59f188618367a132fda3120738bd4b11ce5aa.jpg)
***
补充：窗口右上角的部分变成了Windows XP的徽标了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3deab51a0ef41bd53cd04d185fda81cb3bdb3d54.jpg)
自此，Whistler Server已经进入了尾声，在Window Whistler Server 3505之后，将要进入Windows .NET Server时期了[滑稽]
OK，接下来是5.1.3505.0
Windows Whistler Server build 3505
阶段：Beta 2
架构：x86
版本：Advanced Server
字串：5.1.3505.0.idx02.010627-0843
日期：2001年06月28日
密钥：CXGDD-GP2B2-RKWWD-HG3HY-VDJ7J
事项：无
语言：English (United States)
版本跳到35xx，说明已经开始分支研发.NET Server和Longhorn，从此，Windows Server 2003已经不再属于Windows XP了[滑稽]
***
序列号的样式是黄色，但是内容变成了25个Z（ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ）了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/f9ccfc514fc2d562a1fb4b01e91190ef74c66c64.jpg)
新的开户画面，已经改成Windows Advanced Server Liminted Edition（限量版？！[喷]）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/91b7ca4ad11373f009e2f573aa0f4bfbf9ed0476.jpg)
***
OK，接下来是5.1.3531.0
Windows .NET Server build 3531
阶段：Beta 2
架构：x86
版本：Enterprise
字串：5.1.3531.0.idx02.010730-1811
日期：2001年07月31日
密钥：CXGDD-GP2B2-RKWWD-HG3HY-VDJ7J
事项：无
语言：English (United States)

为什么连个人影都没有[喷]
***
这个版本是不能被升级的，所以我又得全新安装了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/49d7ba55564e9258ed5b07029282d158cebf4ee0.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/d17bc7ed08fa513de0a8ee32336d55fbb0fbd9d6.jpg)
又来一个刷版本号的[喷]
***
Windows Server 2003 5.1.3541 [Beta2]
架构：x86
版本：Enterpris
日期：2001年08月11日
密钥：CXGDD-GP2B2-RKWWD-HG3HY-VDJ7J 
语言：En_Us
***
平淡的安装...
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/91b7ca4ad11373f0e0bf8d8bab0f4bfbfaed0413.jpg)
***
Setup没有脱离XP的风格.
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/3deab51a0ef41bd5e4a70ae05eda81cb38db3d27.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/a9d0df98a9014c08e14fc7b1057b02087af4f4a0.jpg)

曾经记得有人说过:""有一些Build看起来差不多,其实在内核上可能就有巨大的变化,就是看不出来而已.
***
3541完.
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6194208392/32fa6bf2d7ca7bcbb818293bb1096b63f724a8bd.jpg)