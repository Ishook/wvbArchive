MC早期镇楼
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/5fc48e25b899a901188478d310950a7b0008f593.jpg)
***
二楼目录请勿回复
很多早期版本链接不存在，等我翻帖子找吧
版本0.2.2
特点：
1.可以移动，可以飞行，可以全屏，可以穿墙了！（WASD移动，鼠标看四周，空格跳跃，长按空格飞行，SHIFT加快下降速度。
F1开启飞行，F2开启全屏，F3开启穿墙。。。←_←）
2.窗口标题栏是fps
3.无法暂停和最小化（没有鼠标），esc是退出
4.没有主菜单
5.有一个音效
***
系统请忽视
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/f9ccfc514fc2d5623286f908ea1190ef74c66cba.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/3b006dd062d9f2d30fd10a0aa4ec8a136127cc0c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/dba428c3d56285355d6efbc49def76c6a5ef63ba.jpg)
本人电脑无法全屏sorry
有边界（printscreen'抽风了）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/8861b642ad4bd1136ecf9fd757afa40f49fb05cd.jpg)
***
版本0.3
特点：
1.可以放置方块破坏方块了！（WASD移动，鼠标看四周，空格跳跃，长按空格飞行，SHIFT加快下降速度。
左键破坏，右键放置方块）
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/13b79cf3b21193132233ea5568380cd793238ddc.jpg)

只有一种能放置的方块
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/0253be32c895d143b5a9f1c67ef0820258af0768.jpg)

再挖会掉虚空
***
停更半小时谅解
时间到了，开更
版本Alpha0.4（贴吧上说是0.31）
特点：
1.加入闪屏
2.加入一开始的摁键选择
3.草方块材质变化
4.WASD移动，鼠标看四周，空格跳跃，长按空格飞行，SHIFT加快下降速度。
左键破坏，右键放置方块
注意，进入游戏后先按一下shift或把默认输入法改为英文（注意不要进去了再调，否则调不起来），以确保在英文状态
【最近终于开始有后面的样子了】
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/1e2beab0cb134954b66cf3815b4e9258d3094ade.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/b6f7148ca977391296688084f5198618347ae2fa.jpg)

一开始往下掉
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/3379ce763912b31b9622c8cc8b18367ad8b4e1fa.jpg)

地高度太矮，很快就挖空，另外准星改了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/43bb1ff1f736afc36fe22580be19ebc4b5451259.jpg)

还会掉里面。。。。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/91fdd4df9c82d15809cd5c548d0a19d8be3e42f9.jpg)

全屏可以了！
世界又变小了！
***
版本Alpha0.3.2（怎么还说0.4）
特点：
1.没啥，只是一开始放草方块再弄一遍放石头了
***
无聊弄个截图吧[喷]我什么话也不想说
（上面是我发的第1个表情）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/0bc2cbae2edda3ccee79bec50ce93901233f92af.jpg)
***
停更半小时
版本0.3.3（0.4依旧什么鬼）
特点：
1.有chunk了
2.启动画面背景没了（文件还有什么鬼）
3.跑出边界死机
4.基岩变成四个连一块的材质
***
什么鬼（又抽了）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/913cc087c9177f3ea3468ce87dcf3bc79d3d56de.jpg)

终于知道是中间滚轮切换了！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/4c0056accbef7609300fea7a23dda3cc7ed99ec0.jpg)

运动轨迹什么鬼？
***
版本Alpha0.3.4（依然0.4）
特点：
1.主菜单又恢复了
2.提示文件加长了
3.区块完善了
***
跑到一半应用程序错误了，杀软弹窗了，我机智的esc【进入正题】这个版本没啥好看的，“墙”没有了而已（差点死机）
版本：真●0.4
特点：
1.挖到基岩底下感觉不同了。
2.穿墙修复。
3.区块又改进了。
【题外话】如果挖掉基岩掉虚空了，再飞可以飞回来。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/678bf92e07082838063aa4f1b599a9014d08f111.jpg)
有时会出现hit block（以为是him block）
***
版本0.4.1（0.5？）
特点：
背包和物品栏增加了！
esc不会退出游戏！
自带材质包
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/94f352fbe6cd7b8949345566022442a7db330ef4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/d53eb6c9a786c917d1933ddcc43d70cf39c757bc.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/e1b0ca355982b2b7b12257213cadcbef74099b8f.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/a9a4522bc65c1038013ea727bf119313b27e898c.jpg)
***
等明天再更，再见
85给我上米青了？
在这里给小桥做个广告！
今天继续更，照例开更半小时停更半小时
版本1.0（愚人节特别版）
特点：
不多说了，材质改的无力吐槽
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/9da0314f9258d1096021835adc58ccbf6e814d09.jpg)

（上图有对未成年人的不良信息，被感染楼主不负责任。）
***
版本Alpha（老忘加）0.4.2
特点：
1.地形生成器（每个chunk都是一样的地形）
2.新的方块
3.多面材质
4.亮度和方块更新（BU）
5.小细节修复（如版本号，还有，调试输出需要按F3切换，而穿墙控制键变成了F4
）
6.一大堆新(b)特(u)性(g)！！！

(1) 站在水下会发现水面变成了透明的。。。
(2) 玻璃依然会阻挡光线。。。（反正玻璃看起来也不是透明的）
(3) 跳跃仍然没有修复（自己太懒就别说了）
(4) 选定方块时看不见边框了。。。++
(5) 这个不算是“新(b)”特(u)性(g)了：窗口在移动或最小化后再还原时会变成一个点。。。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/dc76b659ccbf6c81579b3900b13eb13531fa409b.jpg)
。。。这个老早以前就有了，貌似是fbgfx的问题。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/cb20d41d8701a18bbf050ea7932f07082a38fe65.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/f3e8e000a18b87d61eacb7f70a0828381d30fd65.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/c7f5c68a87d6277fa4fc2ed025381f30eb24fc65.jpg)
***
楼主去吃（w）饭（c）
版本0.4.3
特点：
1.用显示列表渲染区块，将速度加快了好多
2.设置菜单（从上往下分别是：
是否开启垂直同步
视野距离（这里有个算法的小变动，使这个值不能是1。默认为2）
云的宽度，单位为1方块
选择方块的距离（这东西在建筑时很有用，建东西时不用走过去再搭，懒人专用。但注意值调大后不要点到没加载的区块上去，否则会闪退）
选择方块的精度（不建议在15以下，也不建议在默认值100以上。。。就是说前面提到的球形坐标上那条线每次延伸的长度，值越大越精准，但是也越慢[慢也慢不了多少]）
走路的速度（神机建议调小些））
3.光照&萤石
4.玻璃透明
5.标题颜色会变
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/0bc2cbae2edda3ccfbf6b3c80ce93901203f9239.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/06d76ef6905298222416392bdaca7bcb0b46d422.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/ec5b49dca3cc7cd9053f3f313401213fb90e9139.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/746f643a5bb5c9ea7a9f030bd839b60038f3b3db.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/6e29c4cd7cd98d1088c607d92c3fb80e7aec9039.jpg)
***
版本0.4.4
特点：
1.背景换了
2.透明的水
3.更好的地形
4.沙子
5.血量条
6.材质换了
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/20ad422cd42a283468f447e356b5c9ea17cebff9.jpg)

负数也不会死
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/cd45ac124954092377c812969f58d109b1de49ae.jpg)

还有loading界面和
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/07e4de13c8fcc3ce11b2b9db9f45d688d63f20d9.jpg)

暂停！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/20ad422cd42a28346f5946e356b5c9ea17cebf54.jpg)

很好很好
***
版本0.4.5
特点：
1.破坏延迟
2.半透明按钮
3.改名NEWorld！
4.背景换了
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/dba428c3d56285356ed7aec99def76c6a6ef631c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/d41a971e3a292df57bdad0fdb1315c6035a87336.jpg)
***
版本0.4.6
特点：
1.优化，fps*10！
2.N段跳
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/7159acee76094b36dbd46505aecc7cd98f109d8d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/8b1b11084b36acaf56a6e81471d98d1003e99c8d.jpg)

这已经有点像最后的样子了！
***
【番外篇】
破坏效果动图
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/5ee3ed83b9014a90f24a3e55a4773912b11beed3.jpg)
***
版本MMC_A0.4.7_Preview_20140820（第一个预览版）
特点：
1.F3+H有惊喜
2.跳跃有bug所以说进去游戏会开着飞行
***
版本0.4.7
特点：
1.好不容易修复好跳跃系统，不过还是有极小的几率卡到方块里。。
2.重大更新：碰撞箱系统重写！
3.采用世界领先（才怪）的AABB（轴对齐包围盒）技术！
4.加入走路惯性！
5.主菜单界面加入了不必要的优化。。。其实就是鼠标离开的时候停止屏幕刷新，但是CPU占用依然很高（这坑爹的= =到时候一定换成glfw）
***
这个版本就不截图了吧
版本MMC_A0.4.8_Preview_20140906
特点：
加了水下特效
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/47fc4f391f30e924aae9ffd941086e061f95f7fa.jpg)
版本MMC_A0.4.8_Preview_20140908
特点：
水下特效换了
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/bcf7f544d688d43f4303fc1a701ed21b0cf43ba1.jpg)
版本MMC_A0.4.8_Preview_20140908_r2
特点：
1.再次修复材质对齐问题 
2.可以通过Textures\Blocks\options.txt指定Terrain.bmp的大小和材质大小
【ps】终于学会软回车了
***
这个版本不仔细看看不出差别来，我就不截图了吧
版本MineMinecraft 0.4.8 中秋节专版
特点：
处处有中秋节的味道，请亲自去品尝。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/678bf92e070828381401b2fcb599a9014d08f13b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/d9d1db305c6034a8d0aad669c61349540b237687.jpg)
***
版本MMC_A0.4.8_Preview_20140921
特点：
1.新的方块
2.区块系统重写
3.启动画面有了渐变
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/cae7042662d0f7038da5fe3405fa513d2797c53c.jpg)
版本MineMinecraft 0.4.8国【】庆【】节【】专版
特点：
有国【】旗和红色方块，另外这是65周年的
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/0fbe47a5462309f7b98bf8fa7f0e0cf3d5cad663.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/480e363c269759ee23163723bffb43166f22df8d.jpg)
***
版本MineMinecraft 0.4.8 重阳节专版.
特点:
在高度大于等于二十的地方会生成茱萸。
***
如图所示（自己有茱萸方块）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/6015693675/ab30d04443a9822627cd7acf8782b9014890ebc4.jpg)
***
版本MMC_A0.4.8_Preview_20141012
特点：
很多东西都消失了，据说是弄了glfw的庆祝版本（真的很生存啊，很多东西都获得不了了）
既然如此坑爹，跳过吧
***