大家都知道Server 2008是Vista的服务器版，和Vista形同姐妹，Server 2008的支持到2020年1月14日结束，还有3年多时间。[哈哈]之前我记得吧友说过Server 2008 Datacenter不好激活。今天在整理电脑文件的时候发现了以前收藏的若干枚系统密钥，其中有Server 2008 Datacenter的VOL密钥，我拿来测了一下，有两枚Server 2008 Datacenter VOL密钥是有效的，它们是HRCRQ-CGWJ4-TCK27-BC4FX-FYBBF（剩余410次）、VVJFB-6VCHB-9D8GM-YQC97-VV4GH（剩余399次） [真棒][真棒][真棒]看下图：
图在这[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4849113851/91f4dda0cd11728bf8f4e0e5c0fcc3cec1fd2c15.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4849113851/a9d0df98a9014c0879e34462027b020879f4f416.jpg)
没人[委屈]
