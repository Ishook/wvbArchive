时隔15天 我们技术人员经过连夜攻关 终于发布了Yon PE V1.0.
这次和前版相比 已经有了很大的改进.
前帖地址![](http://bbs.pcbeta.com/viewthread-1719571-1-1.html
相比前版Alpha V0.8改进如下
1.修复EFI问题
2.更新引导菜单
3.在Legacy引导模式中会出现Grub引导菜单
4.应@Hikari_Calyx的要求 在BCD上添加了DisableIntegrityCheck参数 值为True.
5.多内核整合到单包
6.带U盘写入程序
7.完美调整好外置模块（Yon PE外置程序整合器，yonpe.ini 由@SYC编写）
8.支持本地安装Yon PE
在此 我发下贡献链接和Yon PE截图:
开发人员名单：
 Kth1438bdl
 Orange Master.
 Ricky8955555
 Kitori_Shrimp
 iTechDeveloper
 SYC
 Cghvbnv22
 Bilihei
还有更多截图在压缩包里，链接二楼
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4822440823/2c75e70b19d8bc3e2c42512d8a8ba61eaad34580.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4822440823/65ebf2cbd1c8a78663601de96f09c93d72cf5080.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4822440823/9d3036db81cb39db7cb130b1d8160924a91830dd.jpg)
链接： 链接：![](http://pan.baidu.com/s/1mhEIEe8 密码：4udt
