通过的绝大部分U盘全家福镇楼，一家人就要整整齐齐[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/f08aad8165380cd790f422dfac44ad345882810b.jpg)
先说一下，我这个人不太喜欢用移动硬盘储存文件，因为不方便携带，到今天为止也只有一个80G的机械移动硬盘，而且是家里淘汰下来的，存ISO文件用，所以这么多年都是使用U盘的[滑稽]
从2012年开始，我便拥有了自己的第一个U盘Kingston DT 2，刚开始是为了存文件用，不过后来从2015年开始就用来探索wtg，期间买过很多U盘，一直服役至今，不过，探索wtg的路很漫长，也花了不少钱[滑稽][钱币]
所以今天我就来给大家介绍一下这些年使用过的U盘吧[滑稽]
传统格式：
品牌
型号
容量
性能
现在用途
主要使用时间
价格
补充：部分U盘会顺便介绍wtg的那些事儿[滑稽]
***
1、Kingston DataTraveler SE9H 16G
性能：垃圾性能，盗版货泛滥
现在用途：已淘汰给家长
主要使用时间：2012年
价格：网上现价大概在60左右

介绍：这是我的第一个U盘，小学时用的，主要就是存文件，也就是一些班群里下发的文档，已于2013年送给家长

图片可以见网上，因为不在身边[阴险]
***
2、Kingston DataTraveler G3 16G
性能：自己的第一个USB3.0，不过当时没有相应的接口，也并没有什么卵用，不过现在看来还是很垃圾

主要使用时间：2013年
现在用途：PE或在多台电脑之间传小文件，前不久用过Hackintosh 的 Clover

介绍：自己的第一个拥有USB3.0的U盘，当时还不清楚具体的性能，但总感觉在当时3.0的性能就是好，原本正面有镭射字样，随着时间的流逝抹掉了，只留下了背面的字样
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/7625482fb9389b5059db6e608835e5dde6116ed5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/592cdb3fb13533fac3921d1ca5d3fd1f40345bd5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/3deab51a0ef41bd5ca7766c65cda81cb38db3dd5.jpg)
***
3、Kingston DataTraveler Locker+G3 16G
性能：这款U盘主打加密??，性能谈不上好，更何况几乎是乞丐版，性能也好不到哪里去，官网数据写20MB/s，当然指的是大文件咯，小文件不知道慢到哪里去了[阴险]

主要使用时间：2014年
现在用途：已送给家长
价格：有点贵，还保留有小票，110，有点亏

介绍：买这个的原因是当时学校电脑病毒泛滥成灾，其实是快捷方式病毒，普通U盘加密bitlocker其实可以轻松解决，不过但是我还是想装个B，于是就买了这个，日晒雨淋，光滑的金属表面起了铁疙瘩，强迫症简直受不了，不过读写时有镭射灯亮好评[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/3379ce763912b31b2ad3441b8b18367adbb4e1bf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/d0a6ff23720e0cf30648c7c90746f21fbf09aabf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/27fdae3c70cf3bc7ce9444dedc00baa1cc112a65.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/0253be32c895d143d1e26d117ef082025baf0765.jpg)
***
自2015年开始，我就走上了探索wtg之路，至于说为什么要搞，我也不清楚，可能是对这方面比较感兴趣吧，最有可能就是我当时想在学校电脑里运行属于自己的系统来装波B[滑稽]
不过，由于缺乏对wtg的专业认识，加上对外消息不灵敏，我探索wtg这条路走得很久，直到2017年才算圆满成功
我有必要先说说为什么这样，首先，我当时认识wtg是从控制面板里的自带工具认识的，不过，大家看看下面这张图
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/9596e234e5dde7118972cbc4aaefce1b9c166151.jpg)

看出来了吧，不兼容WTG，不过却没有说明为什么，左下角有个按钮，当时我点进去看了，MS官网列出了几条要求：
1、MS官方认证的U盘
2、容量大于32G
于是，在接下来的2年时间了，我一直都尽力去满足MS所说的要求，却还是无法实行，直到2016年底，我才认识了这个wtg论坛：https://bbs.luobotou.org/ 我才明白了原因，那是因为我不知道的一个问题，大家再看看下面的这张图
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/94f352fbe6cd7b89edb8b1b1022442a7d8330e25.jpg)

普通的U盘会被系统识别为U盘（Win10下）或可移动磁盘（旧系统），这种被识别的类型注定了不能通过官方工具制作，之所以MS不会提到，那是因为经过MS认证的U盘都会被系统识别为硬盘，而普通的U盘要被系统识别为硬盘需要通过刷固件等方式才行，不过即便如此，这些U盘性能很差，能装不代表能用，于是我在2017年买入新U盘才完美解决问题
其实在认识这个论坛以前，我也有自己的第三方WTG方式，那就是大家都熟知的，通过强制灌入install.wim文件来强行启动，不过当时来看，真的很慢，开机要开1个小时，在OOBE就卡死，玩个锤子啊[喷]
接下来我给大家介绍一下探索WTG的路上所买的U盘吧[滑稽]
***
4、Kingston DataTraveler Micro 3.1 32G
性能：这个所谓的USB3.1实际上是假的，因为它用的协议是USB3.1 gen1，理论上和3.0没什么区别，真正的3.1是从gen2开始的
主要使用时间：2015年
现在用途：PE、clover、传文件
价格：70
购买这个U盘的目的是为了实现MS的要求：容量大于32G，结果还是无法通过官方工具制作，强行灌入install.wim，开机开半天，OOBE直接卡死[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/4903f7539822720ec01517c876cb0a46f31fab1b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/c722407e9e2f07088c22de32e424b899a801f2d7.jpg)
***
通过几次发现Kingston都是?????，高价低配，于是我再也没买过Kingston的，从而转向sandisk，sandisk就有点像现在的小米，主打性价比
5、sandisk extreme CZ80 64G
性能：那是我第一次使用性能好的U盘，这也是对于我来说第一个较好运行wtg的U盘，读240多，写135
主要用途：wtg、存电影、ISO等
主要使用时间：2016年
价格：245

介绍：这是我首次跨入高性能U盘，这次我还觉得真值了，并且在上面成功运行了wtg，虽然打游戏、P图，剪片子还是做不到，不过能够上网聊天在当时来说已经很足够了，我还成功地在班级电脑里运行了Win8 CP，好评，不过后来在萝卜头那里了解到，这个U盘由于主控问题，擦写时间长了就会产生垃圾块导致掉速，需要多次慢速格式化或多次填充文件才能恢复，所以后来也不敢用这个搞wtg了，存文件还是不错滴[滑稽]
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/0253be32c895d143db8513117ef082025baf0702.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/768ebdb54aed2e73101a711e8a01a18b86d6fa03.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/17d876dea9ec8a13d6c9a0d2fa03918fa1ecc023.jpg)
16年底，认识了萝卜头论坛，也认识了chipfancier这个品牌，于是从那时起就只买这个品牌了，直到今天也是如此
不过在此之前，先补充一下还有一个用来存文件的CZ73
6、sandisk ultra flair CZ73 32G
性能：U盘主控中4K速度最快的！
用途：存文件，备份
时间：16年底17年初
价格：60
这个可真的是良心产品，到今天依然很好用[滑稽][大拇指]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/39c56d54b319ebc431a780ab8f26cffc1f17161e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/23d305d1f703918f180ecbf85c3d269758eec41f.jpg)
***
7、chipfancier se 32G
性能：读250多，写100多，AS SSD 跑分 300+
用途：wtg
时间：2017至今
价格：200
介绍：这是我能够完美运行wtg的U盘，价格不贵，性价比很高，就是容量小了点，而且运行时温度很高
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/750e81cc7b899e516236ca264fa7d933c9950db9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/e9835e13b31bb0516a9c431a3b7adab44bede0ba.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/f6f45df23a87e950d36d035e1d385343faf2b484.jpg)
***
8、chipfancier pro 128G 2016款
性能：读420写360 asssd跑分500+
用途：wtg（可用于游戏、图形等程序）
时间：至今
价格：520
介绍：把大型游戏装在U盘上，插到别人的电脑里运行，游戏在U盘里运行考验U盘速度，实际效果很好，加载速度不输于机载固态硬盘，就是跑时温度很高，曾用测温枪录得夏天户外运行，最高可达120度，待机常年温度也在60度以上，冬天暖手宝必备[滑稽][茶杯]

出厂自带硅脂，颜色为白色，灰色硅脂是我后来自己加上去的[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/d53eb6c9a786c9174221ac0bc43d70cf3ac757d3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/1b41aeeb15ce36d30e267d0237f33a87e850b1dc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/ab30d04443a982264ee3d5158782b9014b90ebdc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5840023548/d0a6ff23720e0cf315d5b0c90746f21fbf09aadc.jpg)