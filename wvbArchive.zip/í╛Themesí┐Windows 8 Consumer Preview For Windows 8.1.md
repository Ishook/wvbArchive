一楼防吞
前言：自己对照着Win8 CP一点一点更改的趋于完美的主题，
除了某些实在没办法改的部分之外，其余的基本改到全同的级别了。
效果预览：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5306423074/b828b601baa1cd115ab5ab15b212c8fcc2ce2dfd.jpg) 
***
任务栏细节（只有合并图标才有，在Win7确认）：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5306423074/fa55aa10728b4710935724f9c8cec3fdfd032384.jpg) 
***
这也是CP不同于RP的地方，其余的废话我也不多讲了。
下载地址：https://pan.baidu.com/s/1nuNfSM1 密码: jgvy
***
自带的内容：
CP默认壁纸，Win7音效（测试版就是这样的），Aero拟物指针。
建议搭配食用的物质：OldNewExplorer
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5306423074/94cbe095a4c27d1ee50ce4f210d5ad6edcc438d7.jpg) 
***
再贴个比较完整的效果图，
