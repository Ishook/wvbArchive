这是Windows Vista Ultimate (PRODUCT)RED 版本的扩展内容安装包，也是Windows Vista (PRODUCT)RED 版本和普通旗舰版的区别。（也就是说装上这个就是(PRODUCT)RED版本了）其中包含一组壁纸（包括dreamscene视频壁纸）、一些小工具、一组屏保和一个主题。实际上这个安装程序好像并没有安装限制，我在win10下也可以安装。但是像小工具和dreamscene这种显然是自带了版本限制[滑稽]

链接楼下发 晒一组壁纸
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/13b79cf3b2119313fa8ea2ca68380cd793238df4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/9da0314f9258d109392ff4c8dc58ccbf6e814df5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/d0a6ff23720e0cf3f23913810746f21fbc09aaf7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/68c0539a033b5bb5f3e97c843bd3d539b700bc87.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/49d7ba55564e92585927da949182d158cdbf4eaa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/891e72cf36d3d539884553b93787e950342ab041.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/36fd2c37acaf2eddf8fd1593801001e9380193b5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/0b0f9cecab64034fa1f89e7ca2c379310b551d8c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/c2d2a8fd1e178a825f3223dafb03738da877e8b0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/0f36b2638535e5dd8b5df9a57bc6a7efcf1b6248.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/edc03e83b2b7d0a258cd58e7c6ef76094a369abd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5912874625/c7f5c68a87d6277f64136e4225381f30e824fcb9.jpg)
***
推荐安装在安装了Dreamscene梦幻桌面的Windows Vista Ultimate上[勉强]
这个东西是我在my digital life上闲逛看到的[笑眼] 原帖的只有备用链接还能用了
这个东西本来是挂在Digital River公司服务器上供Vista红版用户下载的，结果2015年的时候撤下了[狂汗] 所以可以说是绝版了
***