![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5054310889/38049037afc37931d5c2d8f4e2c4b74541a911be.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5054310889/23d305d1f703918fb4086317583d26975beec403.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5054310889/16baf559d109b3de1061bab5c5bf6c81820a4c02.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5054310889/90e26e25ab18972b12e55e17efcd7b899c510a01.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5054310889/b6d00c610c338744db5e71a1580fd9f9d52aa04d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5054310889/2b9791256b600c33a8b28015134c510fdbf9a11d.jpg)
1.整合了Media Center+Tablet PC组件
2.补丁打到14年5月为止
3.顺便整合xpize 5 Release 6包
***
4.Internet Explorer和WMP各自升级到8和11
5.增加了各个主题(其中就有Watercolor)
镜像格式：Wim
镜像大小：2G左右
安装方法：使用imagex或者第三方工具恢复还原即可
本系统基于happymax1212制作的Windows XP 媒体中心版 SP3
感谢@happymax1212 提供资源
WaterColor主题(适合于Windows NT5系版本)
链接: https://pan.baidu.com/s/1c2N5WCK 密码: i5ax
顶
Windows Watercolor Milestone 1链接: https://pan.baidu.com/s/1pLHJTFl 密码: hafr
[疑问]
