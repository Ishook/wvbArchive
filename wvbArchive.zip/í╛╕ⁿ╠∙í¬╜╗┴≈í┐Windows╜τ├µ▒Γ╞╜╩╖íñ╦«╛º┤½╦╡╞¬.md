续篇终于开贴了，这里将更新Win7～Win10 xxx的界面发展史
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2dd6284b20a44623fe7e05379122720e0df3d721.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bdeb2635970a304e578300afd8c8a786c8175c33.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dedb600928381f303fe42dfca0014c086c06f0d8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/90e26e25ab18972b48d8a09fefcd7b899c510afe.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a2505d8f2d3572cf21e3c898313632760d0c3d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e1b0ca355982b2b7fac29a9138adcbef77099b7f.jpg)
***
以下是即将更新的列表
***
普通列表
【极光灿烂】6429～6608
【光的深处】6730～6801
【海的鱼儿】6910～7000
【白色珍珠】7000～7055
【花岗白岩】7057～7231
【四色风景】7232～7600
特殊列表
***
【Vista的十周年生日礼物】5212～5824【定为1.29～2.1】更新
欢迎催更并向楼主提出怎么改进[滑稽]
普通列表
Windows 7列表
【极光灿烂】6429～6608
【光的深处】6730～6801
【海的鱼儿】6910～7000
【白色珍珠】7000～7055
【花岗白岩】7057～7231
【四色风景】7232～7600
Windows 8列表
【蜜汁区域】7700～7901
【台球盛会】7927～7973
【五光十色】7989～8064
【蓝绿冲汇】8102～8158
【古色古香】8161～8250
【完美融合】8331～8424
【七彩画纸】8431～9200
【蓝天雏菊】9289～9379
【青蓝沙滩】9403～9428
【几何分形】9431～9600
特殊列表
【Vista的十周年生日礼物】5212～5824【定为1.29～2.1】更新
【极光灿烂】
Windows 7 Build 6429
界面吐槽：和Vista没有区别，可能是在开发状态
架构：
阶段：Pre-Milestone 1
详细版本：6429.fbl_multimedia_media.070514-1730
编译日期：2007年5月14日
泄漏情况：未泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d0a6ff23720e0cf32209e7ae0346f21fbc09aadb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cca0f3eff01f3a2966147c9b9025bc315e607cf8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a7e5f7ee76c6a7ef8fa10173f4faaf51f1de66d1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0cfc09071d950a7bd77ae69103d162d9f3d3c90a.jpg)
【极光灿烂】
Windows 7 Build 6469
界面吐槽：阉割了控制面板主页的左侧栏，所谓的超级任务栏并不超级
架构：x86
阶段：Pre-Milestone 1
详细版本：6.1.6469.1.fbl_find_dev(wexbuild).071002-1531
编译日期：2007年10月2日
泄漏情况：2011年4月26日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/86a877395343fbf2a0133176b97eca8064388f99.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0f36b2638535e5dddffd318a7fc6a7efcc1b6283.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c0056accbef7609697a0fca27dda3cc7dd99e63.jpg)
【极光灿烂】
Windows 7 Build 6471
界面吐槽：超级任务栏与快速启动栏融合，边栏被阉割成小工具
架构：
阶段：Pre-Milestone 1
详细版本：6.1.6471.？
编译日期：2007年？月？日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9596e234e5dde711ee092aa0aeefce1b9f166186.jpg)
[怒]你们就不能讨论Windows的界面特点功能与历史吗
明天更65XX
【极光灿烂】
Windows 7 Build 6519
界面吐槽：控制面板左侧栏变为蓝色，超级任务栏出现混搭风格，侧边栏消失，另外还出现了昙花一现的华丽的启动界面
架构：x64, x86
***
阶段：Milestone 1
详细版本：6.1.6519.1.winmain.071220-1525
编译日期：2007年12月20日
泄漏情况：2008年6月13日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a9d0df98a9014c08c391dffe037b02087af4f43d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d9d1db305c6034a875724fdac21349540b2376ca.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68c0539a033b5bb52c7cd7a53fd3d539b700bc3c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cb20d41d8701a18b2478e514972f07082a38fed4.jpg)
【极光灿烂】
Windows 7 Build 6568
界面吐槽：超级任务栏改进，而且有气泡好评，另外个人文件夹图标样式被替换为6608样式
架构：
阶段：Milestone 2
详细版本：6.1.6568.1.winmain.080302-1858
编译日期：2008年3月2日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1c9453a95edf8db1e0b28d3f0023dd54544e74c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3632c0eece1b9d16e68f6b3afadeb48f8d546412.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/75dea15d103853431478767a9a13b07ecb808828.jpg)
【极光灿烂】
Windows 7 Build 6608
界面吐槽：标识基本替换为Windows 7，登陆界面低级错误差评，很少有人使用的操作中心出现，另外非常经典的6608样式个人文件夹图标正式面世，超级任务栏和6568差不多
架构：x86
阶段：Milestone 2
详细版本：6.1.6608.1.winmain_win7m2.080511-1400
编译日期：2008年5月11日
泄漏情况：已泄露，泄露日期未知 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/09a06e22dd54564ebe581962bade9c82d0584fa5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1292b7170924ab18fed5136c3cfae6cd79890b9b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68cc7831e924b8990fff8b6367061d95087bf6a4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/92ef69f51bd5ad6ebd0f96b188cb39dbb4fd3ce8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39dbd20a950dd9160924a918309c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d7ba55564e9258fff374b59582d158cebf4e9f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/913cc087c9177f3e21c30e5679cf3bc79d3d56ef.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f8794fe1dba75db1b0ef419d53a84.jpg)
6608的超级任务栏 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7159acee76094b365193e7b6aacc7cd98c109d5a.jpg)
【光的深处】
Windows 7 Build 6730界面吐槽：华丽的启动界面消失，OOBE徽标巨大，有新的开始菜单，Aero透明度极低还发亮光是想瞎掉人的眼睛吗
架构：x86
阶段：Milestone 3详细版本：6.1.6730.1.winmain.080612-1840
编译日期：2008年6月12日泄漏情况：2011年4月26日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2acb608b3de9c823a3fc1d36581800a18d8430d.jpg)
【光的深处】
Windows 7 Build 6748
界面吐槽：开始菜单的头像进里面了
架构：x86
阶段：Milestone 3
详细版本：6.1.6748.0.winmain.080710-2059
编译日期：2008年7月10日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f47beb5594eef01fee1f3f99e9fe9925bd317d5c.jpg)
【光的深处】
Windows 7 Build 6780界面吐槽：安装界面背景变为海蓝色，同时有清新的新启动界面，WD的色调变为蓝青色，WMP升级为12，并且色调变浅。帮助主题色调完全变白。资源管理器的特效基本阉割完成。欢迎中心的图标换了。同时新画图、新写字板、新计算器面世
架构：x86阶段：Milestone 3详细版本：6.1.6780.0.winmain_win7m3.080829-1900
编译日期：2008年8月29日泄漏情况：2009年4月12日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/411d5e00213fb80ec663468b3fd12f2eb8389435.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d0cc19972bd4071580f4a172899e510eb3091f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e17ca3aab6d4390f603718de9de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c23f62297dda144068d4beebbb7d0a20ef486df.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a6391c889e510fb32ab550cbd033c895d0430c36.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f08aad8165380cd739a285b1a844ad3458828127.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b7c2c8c279310a558afaf9a8be4543a980261080.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f8794ab406f72db1b0ef41ad53a27.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6fdade399b504fc211f59759ecdde71191ef6d3d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/11c9419659ee3d6d2639a0974a166d224d4adee0.jpg)
新画图 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a6391c889e510fb32d1c57cbd033c895d0430c5d.jpg)
新写字板
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9835e13b31bb051be6593743f7adab44bede01a.jpg)
***
新计算器 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/833aa4fcfc039245dfccc1538e94a4c27c1e2561.jpg)
【光的深处】
Windows 7 Build 6801界面吐槽：评分机制升级为7.9分架构：x64, x86
阶段：Milestone 3详细版本：6.1.6801.0.winmain_win7m3.080913-2030
编译日期：2008年9月13日泄漏情况：2008年10月30日公开发布
【海的鱼儿】
***
Windows 7 Build 6910界面吐槽：6910的超级任务栏与跳转列表是分开的，极光最终消失，BETA鱼上线架构：x64, x86阶段：Pre-Beta
详细版本：6.1.6910.0.winmain.080915-1555编译日期：2008年9月15日泄漏情况：2016年12月19日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9f52d91f603738d925e257eba1bb051f919ec4f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da977053baf77b951f8198718e34f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b6f7148ca97739128e32ac3df1198618377ae24f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3379ce763912b31b8e78e4758f18367adbb4e14f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9835e13b31bb051c7309a743f7adab44bede04f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/79e6d41ab051f819c6312a16d3b44aed2f73e74f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3efd750f81986187753c6d843ed2e738ad4e64f.jpg)
【海的鱼儿】
***
Windows 7 Build 6936
界面吐槽：操作中心改进，媒体中心有新的启动界面，帮助与支持变简洁了
架构：x64
阶段：Pre-Beta
详细版本：6.1.6936.0.winmain.081023-1800
编译日期：2008年10月23日
泄漏情况：2008年12月15日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9e6affdc3cec3fdd20b7c2bdf88d43f869427a8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/42fc1cf50ad162d97be7ba4218dfa9ec8b13cd5d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/32fa6bf2d7ca7bcbac841f71b7096b63f424a8e3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cb20d41d8701a18bff74ca11972f07082a38fec3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9a402dec2e738bd4c714696fa88b87d6267ff9a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2dd6284b20a44623967d7d3c9122720e0df3d72b.jpg)
【海的鱼儿】
***
Windows 7 Build 6948
界面吐槽：这个图片来自Win7RTM的帮助与支持
架构：x64
阶段：Pre-Beta
详细版本：6.1.6948.fbl_shell_dev.081112-1755
编译日期：2008年11月12日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43bb1ff1f736afc3235de53bba19ebc4b6451214.jpg)
【海的鱼儿】
***
Windows 7 Build 6956
界面吐槽：Win7启动界面定形，超级任务栏正式登场！操作中心图标简易化，新增家庭组。帮助与支持图标缩小。计算器改进。Windows Defender背景色变丑。
阶段：Pre-Beta
详细版本：6.1.6956.0.winmain.081122-1150
***
编译日期：2008年11月22日
泄漏情况：2008年12月6日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd95a56f2873001213fb90e916f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c23f62297dda1446765aaecbbb7d0a20df48672.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d9d1db305c6034a8a5077fdfc21349540b2376f9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f6f45df23a87e950893e353219385343faf2b4bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3e8e000a18b87d6540f6d410e0828381e30fd11.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0f36b2638535e5dd010e63817fc6a7efcf1b6240.jpg)
【海的鱼儿】
***
Windows 7 Build 6965
界面吐槽：检测手机好评
阶段：Pre-Beta
详细版本：6.1.6965
编译日期：？
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/efa594dfb48f8c547b9c057133292df5e1fe7f13.jpg)
你们必须回复，这贴才会更新
【海的鱼儿】
***
Windows 7 Build 7000
界面吐槽：安装程序启动界面定型
阶段：Beta
详细版本：6.1.7000.0.winmain_win7beta.081212-1400
编译日期：2008年12月12日
泄漏情况：2009年1月9日公开发布 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e918ed12632762d075966ae1a9ec08fa503dc63e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cde466e83901213f6b9880825de736d12e2e953f.jpg)
白色珍珠篇明日更新
图片上传一半就失败[喷]
【白色珍珠】
Windows 7 Build 7022
界面吐槽：控制面板左侧的蓝条被移除，控制面板左侧的选项背景从深色换成了浅色。家庭组图标定形，媒体中心更方便，欢迎中心背景也变为浅色。画图和写字板的图标更简洁
阶段：Pre-RC
详细版本：6.1.7022.0.winmain.090115-1850
编译日期：2009年1月15日
泄漏情况：2009年2月9日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/746f643a5bb5c9ea0107a2a2dc39b60038f3b3f4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d729c645ad34598298d645d305f431adcaef840c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68cc7831e924b8997108d97967061d950b7bf6b5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f20f24176d224f4ad5e4d35200f790529922d16c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43bb1ff1f736afc3cd3d9f24ba19ebc4b64512b7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fa55aa10728b47103a655d8dcacec3fdfd03231a.jpg)
【白色珍珠】
Windows 7 Build 7032
界面吐槽：Aero还是Vista的效果，标题栏上的反馈按钮被去除
阶段：Pre-RC
详细版本：6.1.7032.0.winmain.090129-1812
编译日期：2009年1月29日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8c4b0b80800a19d8de9b2a443afa828ba41e46c8.jpg)
【白色珍珠】
Windows 7 Build 7048
界面吐槽：控制面板选项向中间集中。Aero三个按钮变大。控制面板左侧栏下面变成淡蓝色。欢迎中心变成入门。Windows Defender颜色变浅。媒体中心全新的启动界面。PowerShell改进。部分图标元素win7化
阶段：Pre-RC
详细版本：6.1.7048.0.winmain.090219-1845
编译日期：2009年2月19日
泄漏情况：2009年3月7日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/95cdd1013af33a87f90cab5bcf5c10385243b507.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/32fa6bf2d7ca7bcbff1a6c6eb7096b63f724a800.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2b946b328744ebf8e421cf7ed0f9d72a6159a711.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a7e5f7ee76c6a7eff1470367f4faaf51f2de6607.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3304e5035aafa40feff2659ca264034f79f019b4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c7b08cf91a4c510f2463765b6959252dd62aa5c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e17fe0d7277f9e2fcd79b6491630e924b999f31d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/06d76ef69052982283079282deca7bcb0b46d4b5.jpg)
【白色珍珠】
Windows 7 Build 7051
界面吐槽：确定按钮的特效被简化
阶段：Pre-RC
详细版本：6.1.7051.0.winmain.090224-1840
编译日期：2009年2月24日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/973e1cca0a46f21f4d02c912ff246b600d33aeb7.jpg)
【白色珍珠】
Windows 7 Build 7055
界面吐槽：OOBE阶段和登陆界面由清爽的背景换成一看就非常油腻而刺眼的背景[喷]。部分图标元素Win7化
阶段：Pre-RC
详细版本：6.1.7055.0.winmain.090303-2130
编译日期：2009年3月3日
泄漏情况：已泄露，泄露日期未知 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab0c7d4d510fd9f92be1c3282c2dd42a2a34a4f7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/95cdd1013af33a87e29c965bcf5c10385143b5f7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dc76b659ccbf6c81d713bda9b53eb13532fa4044.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e4fb2cfafbedab64a258dc81fe36afc378311eba.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0f36b2638535e5ddd208349e7fc6a7efcf1b6244.jpg)
【花岗白岩】
Windows 7 Build 7057
界面吐槽：Feedback被完全移除。登录界面的用户名下面有了阴影，同时登录按钮（密码框边上的“→”）从深蓝变成了浅蓝色。Aero的阳光效果被砍，Aero由玻璃变成了亚克力板
阶段：Pre-RC
详细版本：6.1.7057.0.winmain.090305-2000
编译日期：2009年3月5日
泄漏情况：2009年3月12日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0fbe47a5462309f775f630537b0e0cf3d5cad6c8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/36fd2c37acaf2edd82e8dba8841001e93801934f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc7f50b5fadd800baa1cc112a59.jpg)
【花岗白岩】
Windows 7 Build 7062
界面吐槽：远程桌面背景变为浅色
阶段：Pre-RC
详细版本：6.1.7062.0.winmain.090312-1900
编译日期：2009年3月12日
泄漏情况：2015年1月17日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9a402dec2e738bd40a592e70a88b87d6267ff969.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/891e72cf36d3d539b47f93823387e950342ab022.jpg)
【花岗白岩】
Windows 7 Build 7068
界面吐槽：安装界面也换成了非常油腻而刺眼的背景[喷]
阶段：Pre-RC
详细版本：6.1.7068.0.winmain.090321-1322
编译日期：2009年3月21日
泄漏情况：2009年3月28日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/06d76ef690529822975ea682deca7bcb0b46d47c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/38049037afc37931aa341968e2c4b74542a9110c.jpg)
【花岗白岩】
Windows 7 Build 7077
界面吐槽：媒体中心细节修改以及更简洁的任务栏按扭(7100又换回原来有反射光效果的任务栏按扭)
阶段：Pre-RC
详细版本：6.1.7077.0.winmain_win7rc.090404-1255
编译日期：2009年4月4日
泄漏情况：2009年4月8日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b0208bcafa6a06bd9f2d3562cc807.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/891e72cf36d3d539498496823387e950342ab028.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c7f5c68a87d6277f250cab7921381f30e824fc4f.jpg)
【花岗白岩】
Windows 7 Build 7100
界面吐槽：又换回原来有反射光效果的任务栏按扭一直到7601
阶段：RC
详细版本：6.1.7100.0.winmain_win7rc.090421-1700
编译日期：2009年4月21日
泄漏情况：2009年5月5日公开发布 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/768ebdb54aed2e734752266a8e01a18b86d6fa37.jpg)
【四色风景】Windows 7 Build 7232
界面吐槽：非常油腻而刺眼的安装背景就是翻过转然后加个劣质的微标就成默认壁纸了
(公认的Windows史上最丑默认壁纸)(甚至被GHOST系统商利用过)
***
阶段：Pre-RTM
详细版本：6.1.7232.0.winmain.090610-1900
编译日期：2009年6月10日
泄漏情况：2009年6月16日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dedb600928381f303cbc2eefa0014c086c06f0c1.jpg)
【四色风景】
Windows 7 Build 7600.16385
界面吐槽：宇宙中的四色风景
阶段：RTM
详细版本：6.1.7600.16384.win7_rtm.090713-1255
编译日期：2009年7月13日
泄漏情况：2009年7月16日泄露，2009年10月22日发布 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3379ce763912b31b0e5e646f8f18367adbb4e1b8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/50cc3442fbf2b21189f32b08c38065380ed78e88.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a460bf7257f6263f6246960af91.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b7c2c8c279310a5503fe70b2be4543a980261097.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5ab8360ed9f9d72a644fb95bdd2a2834359bbb46.jpg)
Windows 7完
【蜜汁区域】
Windows Build 7700
界面吐槽：除了壁纸变回清爽的感觉，其余没有变化
阶段：Post-RTM或？？？
详细版本：6.1.7700.0.winmain.100122-1900
编译日期：2010年1月22日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/22249002918fa0eceb2fcc4b2f9759ee3f6ddb86.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3304e5035aafa40fee1e669ba264034f7af01995.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab0c7d4d510fd9f9d584fd2f2c2dd42a2a34a4de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f879427d3e368db1b0ef41ad53ab9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e173f5824774390f603718de983.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/38049037afc37931a64c2d6fe2c4b74542a91141.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a529801090ef76c6990b506d9416fdfaad516794.jpg)
【Vista的十周年生日礼物】
***
Windows Vista Build 5212
界面吐槽：重启后首个出现Sidebar的版本，这个Sidebar只有四个小工具，但这个Sidebar能占大部分屏幕[滑稽]
阶段：Beta 1
详细版本：6.0.5212.0.winmain.050726-1915
编译日期：2005年7月26日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91acabbe6c81800a173b52bdb83533fa808b4798.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8c4b0b80800a19d8b3dd5fb63afa828ba41e4698.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3ea1d6dd798b8ba61eaad34598.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c0fe7ed9bc3eb13522196c08af1ea8d3ff1f4498.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/592cdb3fb13533fa9068489da1d3fd1f43345b98.jpg)
【Vista的十周年生日礼物】
***
Windows Vista Build 5284
界面吐槽：出现ehome分支特有的安装程序，据称“无人值守”，里面还有非常简陋的德州扑克游戏
阶段：Beta 1
详细版本：6.0.5284.0.vbl_media_ehome.051218-1800
编译日期：2005年12月18日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/92ef69f51bd5ad6ee8dba35988cb39dbb7fd3c5c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4e007cd4ad6eddc467c5734830dbb6fd5366335c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5b21ca6fddc451dab6d4cb58bffd5266d116325c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ed9abac551da81cb01c4447e5b66d0160824315c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39db8fe2a0e5d9160924aa18305c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/112ee6ca39dbb6fd687922950024ab18962b375c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c13f5edab6fd5266eb09fba7a218972bd507365c.jpg)
【Vista的十周年生日礼物】
***
Windows Vista Build 5310
界面吐槽：Sidebar和媒体中心重绘，出现了一些特效，IE7新增一些功能
阶段：Beta 2
详细版本：6.0.5310.0.vbl_media_ehome_dev.060207-1800
编译日期：2006年02月07日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2acb608b3de9c82d255393c6581800a18d84342.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/79e6d41ab051f819e108c3f9d3b44aed2f73e74e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4903f7539822720e900e234972cb0a46f01fabb3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/512bceed8a136327e5c70280988fa0ec09fac755.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d0cc19972bd40708f1134e72899e510eb30940.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/745c39de8db1cb13b234fca0d454564e93584b1e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a529801090ef76c640cd3b989416fdfaae516758.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0cfc09071d950a7b7f088e7703d162d9f3d3c9be.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ed9abac551da81cb0cd9437e5b66d016082431bf.jpg)
没人看？
【Vista的十周年生日礼物】
***
Windows Vista Build 5329
界面吐槽：桌面上出现了ehome分支特有的一些WMC组件，气泡特效好评，Windows Anytime Upgrade高能！
阶段：Beta 2
详细版本：6.0.5329.0.vbl_media_ehome.060301-2145
编译日期：2006年03月01日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8c4b0b80800a19d841a1b1b13afa828ba41e46dd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3e4faa337e8b8ba61eaad345dd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c0fe7ed9bc3eb135cc65820faf1ea8d3ff1f44dd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/592cdb3fb13533fa822ba69aa1d3fd1f43345bdd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fccad63433fa828ba7bea857f41f4134950a5add.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f1c154fb828ba61eaa73fd9b4834970a324e59dd.jpg)
【Vista的十周年生日礼物】
***
Windows Vista Build 5337
界面吐槽：WMP界面细微修改！墨球、益达、截图工具首次加入，画图拟物化
阶段：Beta 2
详细版本：6.0.5337.0.vbl_media_ehome.060313-2100
编译日期：2006年03月13日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5ab8360ed9f9d72af9122283dd2a2834359bbb2b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd94ebb06473001213fba0e918b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c0056accbef7609f5bfab0127dda3cc7ed99ee9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab30d04443a98226865219b98382b9014890eb96.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f47beb5594eef01fe5832a5be9fe9925be317d8a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e0186ffb513d269725a53ac35cfbb2fb4216d82b.jpg)
【Vista的十周年生日礼物】
***
Windows Vista Build 5355
界面吐槽：OOBE不会让你强制选壁纸，小工具开始丰富多彩！，全新的帮助！传真有了插图，高能的语音控制教程！
阶段：Beta 2
详细版本：6.0.5355.0.vbl_media.060329-2048
编译日期：2006年03月29日
泄漏情况：2016年12月19日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cca0f3eff01f3a29f39de9509025bc315e607cc8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b6d00c610c33874479aa13e2580fd9f9d62aa032.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b7c2c8c279310a55f174e26abe4543a9802610d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd94ca708473001213fba0e919f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9f52d91f603738de75d30bcba1bb051f919ec0a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b1833e636d12f2e734f92fe46c2d562873568df.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2dd6284b20a446238a9b99fc9122720e0ef3d7d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2b946b328744ebf8893658a1d0f9d72a6259a7da.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91b7ca4ad11373f0b45a5301ad0f4bfbfaed043f.jpg)
【Vista的十周年生日礼物】
***
Windows Vista Build 5360
界面吐槽：远程桌面换皮，安装程序改造
阶段：Beta 2
详细版本：6.0.5360.0.vbl_media_ehome.060411-1930
编译日期：2006年04月11日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4903f7539822720e2608b17a72cb0a46f01fab65.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a1949728bd4b31c7afac73b8ed6277f9c2ff866.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/42fc1cf50ad162d9e22f319c18dfa9ec8813cd66.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/990db02b6059252def3c4f843d9b033b5ab5b978.jpg)
【Vista的十周年生日礼物】
***
Windows Vista Build 5371
界面吐槽：安装程序改善，小工具大量加入，安全中心变绿，部分图标更新，Mail工具栏变蓝
阶段：Beta 2
***
详细版本：6.0.5371.0.vbl_media_ehome.060418-1930
编译日期：2006年04月18日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a2505d8f2d3572cbfac633d8313632760d0c3ff.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94de4f35349b033b8189053b1cce36d3d739bdc0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a00afe24bc315c601517950e84b1cb134b547742.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d53eb6c9a786c9173efaacd8c03d70cf39c7574f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d01b11c7a7efce1b8ed0362ba651f3deb68f6549.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68cc7831e924b8990bf887d967061d95087bf605.jpg)
2016年12月19日泄露的其他53XX
6.0.5378.0.vbl_media_ehome.060426-1930
6.0.5382.0.winmain_beta2.060506-1900
6.0.5384.3.winmain_beta2.060517-1235
【Vista的十周年生日礼物】
***
Windows Vista Build 5435
界面吐槽：个性化设置图标定型，图标继续NT6化
阶段：Pre-RC 1
详细版本：6.0.5435.0.vbl_media_ehome_dev.060523-2105
编译日期：2006年05月23日
泄漏情况：2016年12月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fccad63433fa828b97337802f41f4134960a5a30.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a738e51352ac65cf15e8392f2f2b21191138aea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/66633eef3d6d55fb04e393c764224f4a21a4dd24.jpg)
【Vista的十周年生日礼物】
***
其余泄露版本影响不大，所以十周年生日礼物完结
民众：[怒]
蓝色Basic界面首次出现在Windows Vista Build 5466
极光壁纸首次出现在Windows Vista Build 5840.16389
预告：Windows 8 Build 7850～7901
【蜜汁区域】
Windows 8 Build 7850
界面吐槽：填字壁纸首次出现。界面最直观的变化是右下角账户头像，其次窗口右上角按钮变得巨大(不过大小比不过win10)，出现了向上按钮，内置PDF Reader和Metro 相机。首次出现微软机密水印、简陋的资源管理器Ribbon UI和新版任务管理器
阶段：Milestone 1
详细版本：6.1.7850.0.winmain_win8m1.100922-1508
编译日期：2010年9月22日
泄漏情况：2011年4月12日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/efa594dfb48f8c544569e3cc33292df5e2fe7f94.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b7c2c8c279310a558b85f817be4543a9802610a0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68c0539a033b5bb55dad061d3fd3d539b400bcd4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3deab51a0ef41bd5bed0ce1758da81cb3bdb3d42.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91b7ca4ad11373f0ab104c7cad0f4bfbfaed041e.jpg)
简陋的新版任务管理器，连雏形都没有出现 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/25cc6bd6912397dd0729bbe75082b2b7d2a287f2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4903f7539822720e76b7c11972cb0a46f01fabc9.jpg)
只有框架的Metro 相机
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f6f45df23a87e950a2c2de8f19385343f9f2b475.jpg)
PDF Reader连框架都没有[喷]，一片空白 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6e29c4cd7cd98d10b3ea20d2283fb80e7aec9008.jpg)
Ribbon UI功能，这个算是完成度较高的功能 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b0eb5d282df5e0fe56c8a6e2556034a85cdf7272.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d9d1db305c6034a88d329762c21349540b237672.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/141351d02f2eb93822755411dc628535e4dd6f2a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/973e1cca0a46f21fc43370b0ff246b600e33aec7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39dba6d849b5d9160924aa183029.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3304e5035aafa40f6caee03ea264034f7af019d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f8fa1ced54e736d19812a2eb92504fc2d76269c1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e772ae167f3e67093a1b6b1c32c79f3df9dc552b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5b21ca6fddc451da8f412208bffd5266d2163296.jpg)
右下角账户头像功能 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/141351d02f2eb93822945411dc628535e7dd6f49.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/83099b029245d688d0fa9c47adc27d1ed01b2449.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8b1b11084b36acaf823db81f75d98d1003e99c6d.jpg)
忘了说还有一种变化：内置IE9 Beta 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b8ede119367adab4099632a082d4b31c8501e480.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3e53542f298b8ba61eaad345ee.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b02082c8f16026bd9f2d3552cc880.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c5c182dce71190efc940bb3cc71b9d16fffa608b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4e007cd4ad6eddc45da79d1830dbb6fd50663381.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c13f5edab6fd5266c1aa15f7a218972bd6073640.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a7e5f7ee76c6a7ef0fa181c5f4faaf51f1de6647.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d0a6ff23720e0cf3a24267180346f21fbc09aa95.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89c917ce3bc79f3d0ebfcdd3b3a1cd11708b29e8.jpg)
【蜜汁区域】
Windows 8 Build 7867
界面吐槽：CES 2011大会展览Build，有些展览图流传，据说这个Build开始支持ARM架构以及用来宣传IE 9浏览器
阶段：Milestone 1
详细版本：6.1.7867.0.winmain_win8m1.101020-1800
编译日期：2010年10月20日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cca0f3eff01f3a29eb56c12d9025bc315e607ca8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9596e234e5dde71129555715aeefce1b9f166147.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8861b642ad4bd1136e7fa3d153afa40f49fb0593.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b006dd062d9f2d30195300ca0ec8a136127cc46.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c5c182dce71190efcc65863cc71b9d16fffa60a8.jpg)
【蜜汁区域】
Windows 8 Build 7901
界面吐槽：新版任务管理器已有雏形！
阶段：Milestone 2
详细版本：6.2.7901.fbl_uex_icp.101213-1800
***
编译日期：2010年12月13日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ca76de004a90f60342c38ca43012b31bb251edd3.jpg)
【台球盛会】
Windows 8 Build 7927
界面吐槽：OOBE自动显示Aero，无显卡驱动程序也能玩Aero，IE 9界面略微缩水，首次拥有简单的扁平主题和Aero Lite主题，默认壁纸变为绿色，简陋的应用管理目录，神仙鱼锁屏界面和新OOBE，新版任务管理器首次公开，Metro 控制面板和相机雏形已现，系统重置应用框架已现，Ribbon UI功能拥有一些新的图标
阶段：Milestone 2
详细版本：6.2.7927.0.fbl_srv_wdacxml.110214-1930
编译日期：2011年2月14日
泄漏情况：2011年8月29日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f47beb5594eef01fde7b2f29e9fe9925be317de0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9596e234e5dde71148b5741aaeefce1b9f1661e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/990db02b6059252d743e2ae83d9b033b5ab5b922.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43bb1ff1f736afc33e6a0889ba19ebc4b54512e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d0a6ff23720e0cf35d8e7c170346f21fbc09aad2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fefd0c62f6246b609efd8098e2f81a4c530fa264.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c23f62297dda144188b515ebbb7d0a20ef48655.jpg)
新的神仙鱼登陆界面，(虽然有些粗糙，但美观度完爆渣7登陆界面) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5d616d7a02087bf461736b05fbd3572c13dfcfb0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/730ee58aa61ea8d307bd48e89e0a304e271f58b0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9835e13b31bb051aa718fc43f7adab448ede0fe.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68cc7831e924b899cd6845d467061d95087bf6ff.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fefd0c62f6246b609ceb8e98e2f81a4c530fa26e.jpg)
新版神仙鱼OOBE(有些粗糙，但能基本使用) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c722407e9e2f0708778f15ece024b899ab01f24d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a467b3eb5d56263f6246a60af37.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/95cdd1013af33a874da13ff6cf5c10385143b507.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1b41aeeb15ce36d34a3ebddc33f33a87e850b11d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4fd025a6d933c895e1f4a697d81373f08002004c.jpg)
说说和普通Aero的区别
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43cf3cb4c9ea15cead80dbe5bf003af33887b2e1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/17d876dea9ec8a130eab6c0cfe03918fa2ecc09a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/61cbdf0f7bec54e7f5a421f2b0389b504dc26a83.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a738e51352ac65cb3b35d9ff2f2b21191138a99.jpg)
***
已有雏形的新版任务管理器
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cd45ac12495409233e6a59929b58d109b1de49d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d01b11c7a7efce1b5226f226a651f3deb68f65c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c27fc11fa8d3fd1fb7cd99d6394e251f97ca5f0f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ca76de004a90f6033b74a7ab3012b31bb251ed0f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f6093567d01609248b1d98f7dd0735fae7cd3412.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b6f7148ca9773912f9edbf8df1198618347ae20c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e4fb2cfafbedab643610682cfe36afc37b311ef4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f8fa1ced54e736d1ed6aa9e492504fc2d76269d2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab30d04443a982268ffa0ecb8382b9014b90eb1c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91e714f182025aaf95d95b27f2edab64014f1a63.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b6f7148ca9773912fb1aa18df1198618377ae217.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91f4dda0cd11728b40c6a9cec1fcc3cec1fd2c63.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b227302d11dfa9ece34e72fb6bd0f703938fc1eb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3efd750f81986187a27cb6843ed2e7389d4e6eb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8eeffa17fdfaaf512223a453855494eef21f7a0b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3deab51a0ef41bd5bb93cd1858da81cb3bdb3d0a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dea568b20f2442a7f193d949d843ad4bd31302b5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94f352fbe6cd7b89badb1e6f062442a7db330e9f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94cbe095a4c27d1ec06a1f2812d5ad6edfc43886.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6fdade399b504fc210fd94e9ecdde71192ef6db5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9e6affdc3cec3fdf6c68099df88d43f85942752.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6e29c4cd7cd98d10b8722bdd283fb80e79ec90a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8861b642ad4bd1135f1690de53afa40f49fb0573.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/61cbdf0f7bec54e788ac3cf2b0389b504dc26a8b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e71ba91a9d16fdfa622ce002bd8f8c5496ee7b8b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f1c154fb828ba61e47eceec34834970a324e59d5.jpg)
帮助与支持扁平化 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e8279a1e4134970ac26531c39ccad1c8a6865d39.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3fca0008c93d70cfc64c8ce1f1dcd100b8a12b99.jpg)
【台球盛会】
Windows 8 Build 7955
界面吐槽：和7927差不多，仅仅是OOBE阶段加入KEY界面，神仙鱼OOBE加入KEY界面并改进配置界面
阶段：Pre-Milestone 3
详细版本：6.2.7955.0.fbl_srv_wdacxml.110228-1930
编译日期：2011年2月28日
泄漏情况：2011年4月25日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a00afe24bc315c60e025460384b1cb134b54779b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f6f45df23a87e950a24cde8019385343f9f2b4fc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e71ba91a9d16fdfa67e8eb02bd8f8c5496ee7b4f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d53eb6c9a786c9178bb07fd5c03d70cf39c757a4.jpg)
【台球盛会】
Windows 8 Build 7962
界面吐槽：出现了新的输入法切换方式
阶段：Milestone 3
详细版本：6.2.7962.0.？
编译日期：？
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b7f7f68ea0ec08fa39463f4b50ee3d6d57fbda89.jpg)
【台球盛会】
Windows 8 Build 7963
界面吐槽：这个Build主要改进文件资源管理器，Ribbon UI完善并且文件资源管理器Win 8化
阶段：Milestone 3
详细版本：6.2.7963.0.winmain.110310-1721
编译日期：2011年3月10日
泄漏情况：2015年7月2日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/23d305d1f703918ffe742926583d26975beec4ae.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/36fd2c37acaf2edd04905d05841001e93b0193ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ed9abac551da81cb30f797215b66d01608243139.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5ab8360ed9f9d72a1f0504f1dd2a2834369bbbea.jpg)
【台球盛会】
Windows 8 Build 7973
界面吐槽：没有什么变化
阶段：Milestone 3
详细版本：6.2.7973.0.winmain.？
编译日期：？
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9f52b096e061d95450e20d472f40ad160d9ca83.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bb06d5109313b07e5f0a47e405d7912395dd8c98.jpg)
【台球盛会】
Windows 8 Build 7973 fbl_core2_sid_data
***
界面吐槽：这个Build继续完善Ribbon UI和Metro 控制面板，并且IE9升级到RTM版本，帮助风格有所变化，OOBE背景变为有渐变的纯色
阶段：Milestone 3
详细版本：6.2.7973.0.fbl_core2_sid_data.110330-1700
编译日期：2011年3月30日
泄漏情况：2015年9月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7add4af4e0fe9925fb35ff873da85edf8cb17125.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5b21ca6fddc451da07c89a3cbffd5266d1163224.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68cc7831e924b89962d9eeef67061d95087bf672.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d41a971e3a292df5a5fa3ac2b5315c6035a87325.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9f52b096e061d95c5aca0ef72f40ad160d9ca71.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3fca0008c93d70cf551f3ddaf1dcd100b8a12b71.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/efa594dfb48f8c54d63752f833292df5e2fe7f72.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43cf3cb4c9ea15ce300a76debf003af33887b272.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dde29afbaf51f3de8a9e28b39deef01f3b29792a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/191a5a6c55fbb2fba7f3cec5464a20a44423dc07.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b1833e636d12f2e89c238b746c2d56287356813.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc7f2d25c3bd800baa1cf112a08.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8eeffa17fdfaaf51cfe81168855494eef21f7ad7.jpg)
这些功能区7955是大部分都没有图标的，7973把这些功能区的图标全完善了 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d7ba55564e92589e0115399582d158cdbf4e21.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d7dfb30635fae6cdf4d33bb606b30f2440a70ff3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b3f6d47f21fbe099a1253c362600c338544ad8b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89c917ce3bc79f3d958574e7b3a1cd11708b29f2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/11c9419659ee3d6db5a1171c4a166d224d4adefc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b3f6d47f21fbe099a2753c362600c338544ade6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b1833e636d12f2e923c33b746c2d56284356825.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd9af33a90e3001213fba0e91c4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6fdade399b504fc2fbfa2dd2ecdde71192ef6db1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8c4b0b80800a19d8e91d19d23afa828ba41e46c4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d0cc19972bd407bfc74e2a72899e510db309de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6e29c4cd7cd98d1022d491e6283fb80e79ec90de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4f47682542a7d9335ab679a4a44bd11371f001c4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4aa1d418ebc4b745e5312ac1c6fc1e17888215b1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b227302d11dfa9ec5b31cac06bd0f703938fc1c4.jpg)
图案密码好评！[真棒] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/eb90644e78f0f73630e0d0d60355b319e9c413c4.jpg)
【台球盛会】
Windows 8 Build 7973 fbl_core1_kernel_npc
界面吐槽：和fbl_core2_sid_data的区别是，拥有了全新的betta鱼启动界面！
阶段：Milestone 3
详细版本：6.2.7973.0.fbl_core1_kernel_npc.110330-1809
编译日期：2011年3月30日
泄漏情况：2015年9月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bb19cc65034f78f06a1b052470310a55b1191cce.jpg)
【台球盛会】
Windows 8 Build 7975
界面吐槽：Metro主题界面微调
阶段：Milestone 3
详细版本：6.2.7975.0.winmain.110402-1400
编译日期：2011年4月2日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8f0879168a82b901e3b75de47a8da9773b12efc1.jpg)
由于7985流传图像视频特别高糊，所以跳到7989
【五光十色】
Windows 8 Build 7989
界面吐槽：默认壁纸更换，填字数由7973的14个增长到7989的17个，而且新增触摸键盘，有黑白两色(白色需要解琐)，Aero Lite主题改进，Ribbon UI和Metro控制面板、Metro IE、OOBE继续完善
***
阶段：Milestone 3
详细版本：6.2.7989.0.winmain.110421-1825
编译日期：2011年4月21日
泄漏情况：2011年6月18日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/01c0f00b304e251fc1fb652fae86c9177d3e53ca.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e3381bd88d1001e9212e95d8b10e7bec56e797c8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b8ede119367adab4e1679a9482d4b31c8501e4ac.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91fdd4df9c82d15889fdd866890a19d8be3e42db.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8b1b11084b36acaf3dd1172b75d98d1000e99c2d.jpg)
填字数统计
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f8fa1ced54e736d1372303df92504fc2d462692e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b1833e636d12f2ea03521b746c2d5628435682e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/83099b029245d688b2883e73adc27d1ed01b2450.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/141351d02f2eb938815df525dc628535e4dd6f2e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f2e5f412b07eca8098d2b730982397dda344830c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dc76b659ccbf6c81c0e1a23fb53eb13531fa400c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e1b0ca355982b2b7d500b71338adcbef74099bbb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e0186ffb513d2697914f868a5cfbb2fb4116d8bb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c27fc11fa8d3fd1f08942ced394e251f97ca5fb9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ca76de004a90f603e93915903012b31bb251ed56.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/973e1cca0a46f21f67d4d784ff246b600e33ae7f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/512bceed8a136327a2644be4988fa0ec0afac756.jpg)
解琐后的触摸键盘，色调变成了白色，并且有了简单的教程
解琐后的触摸键盘，表情变清晰了，而且支持单手模式 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7b33f83cf8dcd100ed7c70f67b8b4710bb122f7e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7159acee76094b36a571933aaacc7cd98f109d7f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f8fa1ced54e736d13c5606df92504fc2d7626991.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f32afb83d158ccbf57f83fed10d8bc3eb3354192.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3deab51a0ef41bd5cada622358da81cb3bdb3d55.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d17bc7ed08fa513de55ce609346d55fbb0fbd96d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ca76de004a90f603e55069903012b31bb251ed7f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43cf3cb4c9ea15cedf0b15debf003af33887b272.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9f52d91f603738d3f60f8f5ba1bb051f919ec31.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d1d7f0dca144ad34a76c7250d9a20cf433ad8508.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/480e363c269759eefe4b941cbbfb43166f22dfc0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b828b601baa1cd1126f085f7b012c8fcc1ce2d9c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dfc99fddd100baa19ea7b06c4e10b912cafc2e57.jpg)
OOBE出现了预配置阶段
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68cc7831e924b89902908eef67061d95087bf6ab.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5fc48e25b899a901e089ace114950a7b0008f59b.jpg)
【五光十色】
Windows 8 Build 7994
界面吐槽：看不出任何变化，绿色填字可能是fbl_srv_wdacxml分支的专利
阶段：Milestone 3
详细版本：6.2.7994.0.fbl_srv_wdacxml.110427-1030
编译日期：2011年4月27日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2dd6284b20a44623c03053b59122720e0ef3d761.jpg)
【五光十色】
Windows 8 Build 8032
界面吐槽：默认壁纸再次更换，填字数由7989的17个增长到21个！版本标识已更改为Windows Developer Preview，向上按钮更改好评[真棒]据说这个版本具有完全的Metro组件，开始屏幕颜色是蓝色的
阶段：Developer Preview
详细版本：6.2.8032.0.fbl_core2_sid_data.110623-2054
***
编译日期：2011年6月23日
泄漏情况：未泄露，极少部分人私藏 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9da0314f9258d10998815765d858ccbf6e814df8.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e6eacfd2fd1f4134afbffda92c1f95cad3c85e56.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e8279a1e4134970a09fbe8f89ccad1c8a5865d56.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f2e5f412b07eca808871c730982397dda34483e3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91e714f182025aafd243801cf2edab64014f1aed.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f8794f260b6f9db1b0ef419d53abb.jpg)
Windows 8 Build 8049
界面吐槽：默认壁纸色调变为紫色，填字数增长到36个！，理论这个版本应该具有完全的Metro组件
阶段：Developer Preview
详细版本：6.2.8049.0.fbl_eeap.110718-0510
编译日期：2011年7月18日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f8794f7c7b3f9db1b0ef41ad53a26.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dde29afbaf51f3dea09542b39deef01f3b297933.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bd0ec850f3deb48f99045a09f91f3a292ff578e9.jpg)
下周预告
8056～8158
干货的盛宴！
人呃，不会这么冷清吧
最新预告
14日：
【五光十色·紫】8056～806X
【蓝绿冲汇·上篇】8102～8130
15日：
【蓝绿冲汇·下篇】8148～8158
【古色古香】8161～8234
16日：
【古色古香·斗鱼】8250
【完美融合·混沌】8318～8383
21日：
【完美融合·郁金香】8400～8424
【七彩画纸·雏菊】8431～9347
Windows 8 Build 8056
界面吐槽：这个版本可以同时拥有完全的Metro开始屏幕和原生开始菜单，Aero Lite主题继续改进，安装程序彻底去除经典主题，OOBE的背景略微损坏。IE升级了10 DP。Metro登陆界面背景由神仙鱼变为纯色紫，Metro登陆界面精细化，任务管理器合并资源占用查看器并定型。Ribbon UI仍然在完善中。正式首次出现琐屏界面，死屏加了个哭脸，首次集成微软账户，支持自动选择主题色。网络Metro化。Metro OOBE背景由有渐变的蓝色变为无渐变的紫色，Metro OOBE更完善。触摸键盘去除了白色主题并加入表情输入，单手模式更完善。
阶段：Developer Preview
详细版本：6.2.8056.0.fbl_grfx_dev1.110727-1728
编译日期：2011年7月27日
泄漏情况：2015年9月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94cbe095a4c27d1e3ffd3bf511d5ad6edcc43819.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8de5158a4710b9122afef5cfc9fdfc039245223d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d7ba55564e92586f2d85df9682d158cdbf4edf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/11c9419659ee3d6d1bbf84fa49166d224e4adeff.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8de5158a4710b9122ab7f5cfc9fdfc0393452286.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da977187c851aba51f8198718e3a1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43bb1ff1f736afc36bb93c54b919ebc4b64512ba.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3efd750f8198618104eecb540ed2e738ad4e6ef.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dea568b20f2442a7dbcffe94db43ad4bd0130236.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a46ae0e89086163f6246a60afcc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3fca0008c93d70cfecfca73cf2dcd100bba12bf6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e0186ffb513d269713d2056c5ffbb2fb4216d8f7.jpg)
输入密钥界面出现了触摸键盘图标，但是无法打开
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a738e51352ac65c68396b42f1f2b21193138a3c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cca0f3eff01f3a2980bad9ff9325bc315d607c82.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/20ad422cd42a28345e7b3a3a51b5c9ea14cebf13.jpg)
任务管理器合并了资源占用查看器并定型 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a9d0df98a9014c085a6c2794007b02087af4f4a5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ed9abac551da81cbd6888cfc5866d0160824318e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3e725c09fb888ba61ea9d345a4.jpg)
资源占用查看器定型 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c5c182dce71190efd65d9deec41b9d16fcfa6056.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da9772444891aba51f8198718e389.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3e72ab09fb888ba61ea9d34551.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/768ebdb54aed2e73ad83891d8d01a18b86d6fa8a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b2ebd9086b63f624302c30328d44ebf81b4ca387.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/22249002918fa0ec4bee6d3c2c9759ee3c6ddbcf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/90e26e25ab18972b201409fbeccd7b899f510ace.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e179fbf85004090f603728de9f0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/730ee58aa61ea8d33b547d359d0a304e241f5886.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f1c154fb828ba61e6dbbc11e4b34970a314e599b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91e714f182025aafa06577faf1edab64024f1aa4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3304e5035aafa40f4e5ac7eca164034f79f01953.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c13f5edab6fd526620563525a118972bd50736f3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cde466e83901213f298447ed5ee736d12e2e9545.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/03e20a234f4a20a40b5f34f69a529822730ed0b7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c5c182dce71190efea8799eec41b9d16fcfa60fc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ebecf02ad40735fa127f458894510fb30e24086d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8be72e550923dd54e2fcac59db09b3de9d82486d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f8fa1ced54e736d1bca0873991504fc2d4626941.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1c9453a95edf8db1647f76550323dd54574e74a7.jpg)
Win8Aero秒杀Win7
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9f52b096e061d953b3c3d0971f40ad163d9cafa.jpg)
网络Metro化并且托盘中的网络图标Win8化 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/16baf559d109b3de296d9059c6bf6c81810a4c22.jpg)
虽然彻底去除了拟物元素，但是网络图标和Win7很像，因为方方正正的，之后的网络图标会越来越圆润化【比如9600的网络图标】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e918ed12632762d0ca31ae8eaaec08fa503dc6ed.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b8ede119367adab457016f7281d4b31c8601e427.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91b7ca4ad11373f07efb18aeae0f4bfbfaed0434.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94f352fbe6cd7b896caa4db2052442a7d8330e36.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f32afb83d158ccbfd9afc40b13d8bc3eb03541e1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e3381bd88d1001e9be1c653eb20e7bec55e797d0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f32afb83d158ccbfd99dc40b13d8bc3eb03541d7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b828b601baa1cd11a3900311b312c8fcc2ce2dd6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8be72e550923dd54f8acd659db09b3de9d82481d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd909a844e83301213fb90e916b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cde466e83901213f30ae3eed5ee736d12e2e9553.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5ab8360ed9f9d72a3a31602cde2a2834359bbb9b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c0fe7ed9bc3eb1358a58c78aac1ea8d3fc1f445d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c6ec517bdab44aed3418ced5b91c8701a08bfba6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/20ad422cd42a28346a23463a51b5c9ea14cebf6b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b7c2c8c279310a55b0d4acc5bd4543a983261007.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b7c2c8c279310a55b126a3c5bd4543a9832610f1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/592cdb3fb13533fa3547ee1fa2d3fd1f40345b07.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bcf7f544d688d43f5058ecc3771ed21b0ff43b07.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/50cc3442fbf2b211f814f97fc08065380cd78e3a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b006dd062d9f2d379e159dea3ec8a136227cc00.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a46b83ff7086163f6246a60afd3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fcc53b6134a85edf2857831243540923dc547519.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b6d00c610c338744b935524d5b0fd9f9d62aa000.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4903f7539822720e4b3e9fcb71cb0a46f31fab00.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c722407e9e2f070837625631e324b899a801f295.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/36fd2c37acaf2edddf8c37d8871001e9380193f3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a7e5f7ee76c6a7ef5f5bd617f7faaf51f2de66f3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4cc7e045ebf81a4c00e292f8dd2a6059242da620.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab30d04443a98226ccba52168082b9014b90ebf9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f879477ff301fd81b0ef41ad53af0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/39c56d54b319ebc4b7930fa88826cffc1f171608.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9835e13b31bb051f508cb193c7adab44bede0cc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0bc2cbae2edda3cc07afc0110be93901203f92a9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9f52d91f603738da0eb7413b91bb051f919ec57.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a7e5f7ee76c6a7ef4144d017f7faaf51f2de6692.jpg)
经典Build集·8056完！【五光十色·紫】
Windows 8 Build 8064
界面吐槽：抠门的私藏者，连Build字串都不透露
阶段：Developer Preview
详细版本：6.2.8064
编译日期：2011.8.8附近
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f1c154fb828ba61e1b2bb31e4b34970a314e592b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5b21ca6fddc451da5b3377dabcfd5266d116322b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b0eb5d282df5e0fe039ff230566034a85fdf7275.jpg)
Windows 8 Build 8059
界面吐槽：
阶段：Developer Preview
详细版本：6.2.8059.0.winmain.110729-1857
编译日期：2011年7月29日
泄漏情况：微软官方介绍了8059的桌面特型以及比对Win7的优势性，但未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39db6c870267da160924aa1830b5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e772ae167f3e670974ba20ce31c79f3df9dc55ba.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/512bceed8a1363274957a7029b8fa0ec09fac7ba.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/47fc4f391f30e924a32ff90046086e061c95f769.jpg)
【蓝绿冲汇·上篇】
Windows 8 Build 8102.101
吐槽：由于2011年的win8泄露少而且泄露的Build新功能很少，所以微软在即将发布的Build 8102上非常慷慨的放开了当时已经开发完成的所有win8特性。比如主色调由8056的紫色变成了绿色，默认壁纸是Win7默认壁纸的镜像翻转并去除了logo〖这壁纸很难看、闪瞎眼！〗用户头像Metro化〖颈椎病〗分屏首次出现，这个Build内置许多有趣的第三方应用！，死屏定型，Metro完善中…Metro界面在当时正式出现，关机步骤复杂化。但仍然可启用原生开始菜单。Aero在变化中…许多默认应用出现。基本主题巨像RTM默认主题。启动界面标着Windows Developer Preview
阶段：Developer Preview
详细版本：6.2.8102.101.winmain_win8m3.110830-1739
编译日期：2011年8月30日
泄漏情况：2011年9月13日公开发布 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/25cc6bd6912397ddc0cef7355382b2b7d1a28745.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8eeffa17fdfaaf517554ee8e865494eef11f7a45.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/678bf92e0708283810bab325b299a9014d08f145.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fccad63433fa828b0094f2d2f71f4134960a5a45.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4f47682542a7d933171f8b42a74bd11372f00145.jpg)
8102内置的许多有趣的第三方应用，需另开贴再说
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a6391c889e510fb3d5751ea6d333c895d0430c8c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d7ba55564e925849a8efdf9682d158cdbf4e5c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4ab2951ebe096b63cc5b376106338744eaf8acb2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c7b08cf91a4c510f98868b2b6a59252dd52aa5b2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3e8e000a18b87d62e00c22e0d0828381e30fdb2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9596e234e5dde711edbd2ac7adefce1b9c16618d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/913cc087c9177f3ed785953c7acf3bc79e3d5647.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b828b601baa1cd11cbf41b11b312c8fcc2ce2db2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1b41aeeb15ce36d3986bea0130f33a87e850b18d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94cbe095a4c27d1e17aa53f511d5ad6edcc4386c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3e2e716dfb888ba61ea9d345ff.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/768ebdb54aed2e7389e2ed1d8d01a18b86d6fae9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b02086f4c54d068d9f2d3562cc86b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/66633eef3d6d55fb94851c1767224f4a21a4ddb1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91b7ca4ad11373f05c623aaeae0f4bfbfaed0493.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7add4af4e0fe992535173c613ea85edf8cb171d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9f52d91f603738d5f515913b91bb051f919ecda.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8861b642ad4bd113ae90e20350afa40f4afb0593.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2b946b328744ebf82170310ed3f9d72a6159a7f7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/03e20a234f4a20a46cdf69f69a529822730ed037.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91b7ca4ad11373f05f103baeae0f4bfbfaed04cd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1292b7170924ab18591eb5063ffae6cd7a890be8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/13b79cf3b2119313e44bab816f380cd790238de8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d729c645ad345982ec4bb0a306f431adcaef8437.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5d616d7a02087bf418f103d8f8d3572c10dfcfd3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a075d86e950352a887c71395943fbf2b3118bd3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d3e7d77fca8065385be1f0229ddda144ac3482e9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc7301d99dddb00baa1cc112ad3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1c9453a95edf8db1465728550323dd54574e74ff.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e3381bd88d1001e953f1403eb20e7bec55e79723.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e772ae167f3e670965d211ce31c79f3df9dc5522.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43cf3cb4c9ea15ce7130b438bc003af33b87b21e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0f36b2638535e5dd9109f2ee7cc6a7efcf1b62cb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/222d95d2572c11dfbfaae812692762d0f603c2f9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a738e51352ac65c5d203042f1f2b21192138acb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9f52b096e061d9504a4600971f40ad163d9ca12.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a46df16d8086163f6246a60afc4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc734f09ddddb00baa1cc112a00.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c2d2a8fd1e178a8254cc2f91fc03738da877e801.jpg)
经典Build集·8102完！【蓝绿冲汇·上篇】
【蓝绿冲汇·上篇】
Windows 8 Build 8121
吐槽：闪瞎眼的自动选取主题色图标[喷]界面有些返祖
阶段：Developer Preview
详细版本：6.2.8121.0.winmain.110922-1933
编译日期：2011年9月22日
泄漏情况：图片来自远景，未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89e3183f6709c93dd7a35cc6953df8dcd00054a7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/66633eef3d6d55fbac96241767224f4a21a4dda0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a46de4ad9086163f6246a60af88.jpg)
【蓝绿冲汇·上篇】
Windows 8 Build 8130
吐槽：不知道office是2010还是2013测试版
阶段：Developer Preview
详细版本：6.2.8130.0.winmain.111006-1107
编译日期：2011年10月6日
泄漏情况：图片来自远景，未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6e29c4cd7cd98d10609b50002b3fb80e7aec90ad.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/86a877395343fbf2f84afa12ba7eca8064388f96.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/75dea15d10385343b2d1db109913b07ecb8088de.jpg)
不破500不开心
破500了
【蓝绿冲汇·上篇】
Windows 8 Build 8148
吐槽：安装程序的分辨率由800*600上升至1024*768，Metro OOBE个性化步骤上线〖然而可选颜色比8056少[阴险]〗，此版本乱码众多，新版任务管理器外观定型〖色调柔和了点〗。Metro IE完善了点。Metro控制面板已支持开始屏幕个性化，设备图标扁平化。评分最高分由7.9升级至9.9。屏幕键盘和触摸键盘更人性化。Windows To Go上线。
阶段：Pre-Consumer Preview
详细版本：6.2.8148.0.winmain.111103-1846
编译日期：2011年11月3日
泄漏情况：2015年5月18日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/66633eef3d6d55fb3190411567224f4a21a4dda0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b02080bc108d268d9f2d3562cc8ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f0a59f188618367a818748ee24738bd4b21ce5e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9da0314f9258d10940d69e81db58ccbf6d814dc5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c23f62297dda144175f5b81b8b7d0a20df486a0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fefd0c62f6246b609a008547e1f81a4c500fa2e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8be72e550923dd54a678905bdb09b3de9d8248eb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5d616d7a02087bf47b4860daf8d3572c10dfcf56.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc79109fadfdb00baa1cc112ae8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/09a06e22dd54564e6211d20ab9de9c82d0584f86.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d53eb6c9a786c9177762640ac33d70cf3ac75790.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/66633eef3d6d55fb324c461567224f4a21a4dd74.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6fdade399b504fc205d58036efdde71191ef6d74.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/edbfb61273f082026048a10c41fbfbedaa641b1b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0f36b2638535e5dd34f795ec7cc6a7efcf1b621b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f2e5f412b07eca80d7d809d49b2397dda044831d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9f52b096e061d95619b070b71f40ad163d9ca1d.jpg)
开始屏幕已支持多选
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/112ee6ca39dbb6fd771dd6150324ab18962b37b7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fa55aa10728b4710a8d3ceffc9cec3fdfd03237d.jpg)
网络托盘图标圆润化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5fc48e25b899a9012a11690517950a7b0308f5d6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e1b0ca355982b2b768890bf73badcbef77099be0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/39c56d54b319ebc4f27f44aa8826cffc1f1716f6.jpg)
开始屏幕已有基本的个性化，也是8种颜色
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b2ebd9086b63f624fb050b308d44ebf81b4ca39a.jpg)
多了个激活设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8861b642ad4bd11345ca850150afa40f4afb05f6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/90e26e25ab18972bf3423cf9eccd7b899f510af9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bb19cc65034f78f0caa9a6c073310a55b2191c53.jpg)
最原始的Windows To Go，图标是Vista LOGO+U盘组成的
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6d0187ff9925bc31bce43eab54df8db1ca1370b9.jpg)
表情更多了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/07e4de13c8fcc3ced36ff6009845d688d53f204e.jpg)
单手模式支持放大缩小了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1292b7170924ab18b246de043ffae6cd7a890ba1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dedb600928381f3089c3b29aa3014c086f06f024.jpg)
这里更扁化了
4074X2=8148[滑稽][太开心]
经典Build集·8148完！【蓝绿冲汇·上篇】
【蓝绿冲汇·下篇】
Windows 8 Build 8158
吐槽：超级按钮上线，开始屏幕主色调变紫【可能开始菜单已砍，开始按钮变为Win8.1开始按钮的前身】
阶段：Pre-Consumer Preview
详细版本：6.2.8158.0.winmain.111118-2210
编译日期：2011年11月18日
泄漏情况：部分图片来自远景，未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/891e72cf36d3d5392a3534f03087e950342ab0ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f86dce004c086e067cc8047808087bf40bd1cb92.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1c9453a95edf8db12b6147570323dd54574e74af.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da9777060bd18ba51f8198718e3af.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a1949728bd4b31cd35caf888dd6277f9f2ff892.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a9d0df98a9014c080e781396007b02087af4f4b3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d9d1db305c6034a880ea83b2c1134954082376ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6e29c4cd7cd98d10bd9737022b3fb80e7aec90b3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b7df9500fb30f246b92d730c295d143ac4b03e9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c2d2a8fd1e178a82fd814493fc03738da877e8bd.jpg)
【蓝绿冲汇·下篇】
Windows 8 Build 8161
吐槽：安装程序Win8化，主色调变青(CP化)，OOBE个性化可选9种颜色，超级按钮上线，开始菜单已砍，开始按钮变为Win8.1开始按钮的前身，头像出现一个男人！Ribbon UI完善，这是最后一个Vista logo的已泄露版本
阶段：Pre-Consumer Preview
详细版本：6.2.8161.0.winmain.111128-1254
编译日期：2011年11月28日
泄漏情况：2015年9月19日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cb20d41d8701a18bc2df387c942f07082938fec6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39dbbde04d65da160924aa1830d1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/746f643a5bb5c9ea9d9429d0df39b6003bf3b397.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/25cc6bd6912397dd3d6bb2375382b2b7d1a287ec.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cde466e83901213f163e64ef5ee736d12e2e95ed.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/01c0f00b304e251f7c7acfcbad86c9177e3e536d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/792fd1fc5266d0160694b51b9d2bd40734fa356c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/17d876dea9ec8a133fdc7cd3fd03918fa1ecc030.jpg)
【古色古香】
***
Windows 8 Build 8165
吐槽：无变化
阶段：Pre-Consumer Preview
详细版本：6.2.8165.fbl_fun_resp.111205-2000
编译日期：2011年12月5日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9da0314f9258d1096348b981db58ccbf6d814d4b.jpg)
【古色古香】
***
Windows 8 Build 8172
吐槽：色调变为深青色，应用商店磁贴颜色变深，关于标识变成Windows 8 Beta
阶段：Pre-Consumer Preview
详细版本：6.2.8172.0.winmain.111214-1750
编译日期：2011年12月14日
泄漏情况：图片来自远景，未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b006dd062d9f2d307c537dca3ec8a136227cc26.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/50cc3442fbf2b2111dfa967dc08065380dd78e26.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94f352fbe6cd7b8990ba29b0052442a7d8330e27.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a8f65097bf40ad12c44d4d05d2c11dfa8ecce52.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39dbb2177465da160924aa183026.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6d0187ff9925bc3198aa12ab54df8db1ca137007.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/191a5a6c55fbb2fb23a64b21454a20a44723dc6d.jpg)
【古色古香】
Windows 8 Build 8175
吐槽：CES2012大会展览Build，已经很接近8250版本了
阶段：Pre-Consumer Preview
详细版本：6.2.8175.0.fbl_dev_dp4.111216-2019
编译日期：2011年12月16日
泄漏情况：未泄露，但有视频流出 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e1b0ca355982b2b7479824f73badcbef77099bf7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7159acee76094b36374704dea9cc7cd98c109d25.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8b1b11084b36acafb23589cf76d98d1000e99c25.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/36fd2c37acaf2edd3e2456da871001e938019325.jpg)
【古色古香】
Windows 8 Build 8194
吐槽：已经去除开始按钮，为啥去除？因为超级按钮的出现导致开始按钮的功能被移除，如同一个空壳，所以缩略图的方式比较好
阶段：Pre-Consumer Preview
详细版本：6.2.8194.0.winmain.120127-1917
编译日期：2012年1月27日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4903f7539822720e6869fcc971cb0a46f31fab57.jpg)
【古色古香】
Windows 8 Build 8195
吐槽：和8194没有区别
阶段：Pre-Consumer Preview
详细版本：6.2.8195.0.winmain.120131-1637
编译日期：2012年1月31日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d8d6150f0cf3d7ca1e102645f81fbe096a63a910.jpg)
【古色古香】
Windows 8 Build 8220
吐槽：这是已知最后拥有Vista logo的版本，这个版本设定了Win8的方向
阶段：Consumer Preview
详细版本：6.2.8220.0.winmain_win8beta.120127-1925
编译日期：2012年1月27日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/65d9b32b2834349b74a976b6c3ea15ce37d3be4f.jpg)
【古色古香】
Windows 8 Build 8225
吐槽：任务栏的字体变为微软雅黑细体，logo未知
阶段：Consumer Preview
详细版本：6.2.8225.0.winmain_win8beta.120203-1918
编译日期：2012年2月3日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cb20d41d8701a18bb288087c942f07082938fe93.jpg)
【古色古香】
Windows 8 Build 8234
吐槽：图很假！Windows 8 Consumer Preview字体为什么是黑体？？
***
阶段：Consumer Preview
详细版本：6.2.8234.0.winmain_win8beta.120216-1807
编译日期：2012年2月16日
泄漏情况：图片来自远景，未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bcf7f544d688d43f68bb94c1771ed21b0ff43bec.jpg)
明天预告：
【古色古香·斗鱼】8250
【完美融合·混沌】8318～8383
【古色古香·斗鱼】
Windows 8 Build 8250
吐槽：正式启用新LOGO！，开机界面出现了吐泡泡的二维斗鱼(betta鱼！)安装程序背景更为青色，安装程序终于能正常使用触摸键盘！Windows 8默认头像定型，锁屏界面更简约。开启所有应用更快捷。互动型提升。超级按钮侧栏更扁平。触摸键盘完善中。Metro设置完善中。
阶段：Consumer Preview
详细版本：6.2.8250.0.winmain_win8beta.120217-1520
编译日期：2012年2月17日
泄漏情况：2012年2月29日公开发布
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0fbe47a5462309f7449d2026780e0cf3d6cad60e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/25cc6bd6912397dda2d215305382b2b7d1a28754.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1c9453a95edf8db1fda2f1500323dd54574e746f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7add4af4e0fe99258dd0e4643ea85edf8cb1711f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9596e234e5dde711b10ecec2adefce1b9c16611f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e17121d00054090f603728de95e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c13f5edab6fd5266a27db320a118972bd50736a1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/edbfb61273f08202df2d1e0b41fbfbedaa641bb8.jpg)
正式迎来新LOGO！彻底扁平化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/09a06e22dd54564ea5726d0db9de9c82d0584fe0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8eeffa17fdfaaf51d758088b865494eef11f7a44.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a462593020d6163f6246a60af43.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ef371e300a55b31965f00a4149a98226cefc17ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94f352fbe6cd7b89e996b2b7052442a7d8330e05.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/23d305d1f703918f6135b5fe5b3d269758eec410.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/303b5cc69f3df8dc854704a5c711728b46102885.jpg)
侧栏更扁平，上面的图案消失
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b6d00c610c3387443771a4485b0fd9f9d62aa040.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/86a877395343fbf246572c17ba7eca8064388f85.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/01c0f00b304e251fddb56eccad86c9177e3e53bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3efd750f8198618ab7d65b040ed2e738ad4e6c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3e8e000a18b87d68139212b0d0828381e30fd85.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/11c9419659ee3d6d90fc0dff49166d224e4adec6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39dbdd45ed62da160924aa183076.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2b946b328744ebf8c125910bd3f9d72a6159a7a0.jpg)
删除变成了一个圆圈+减号
【完美融合·混沌】
Windows 8 Build 8318
吐槽：
阶段：Pre-Release Preview
详细版本：6.2.8318.0.fbl_core1_soc_120409-2355
编译日期：2012年4月9日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0cfc09071d950a7bad21b9f000d162d9f3d3c9e0.jpg)
【完美融合·混沌】
Windows 8 Build 8330
吐槽：主题已是8400样式，关于图片定型，默认壁纸是灰黑色的8堆在一起
阶段：Pre-Release Preview
详细版本：6.2.8330.0.fbl_woa.120424-2227
编译日期：2012年4月24日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/750e81cc7b899e517cf2cd2048a7d933c9950dff.jpg)
【完美融合·混沌】
Windows 8 Build 8331
吐槽：伪语言版本。有检测错误的工具和伪语言的说明。开始屏幕个性化完善，加入大量颜色。OOBE阶段最后出现了打开超级按钮的教程。桌面的部分元素扁平化
阶段：Pre-Release Preview
详细版本：6.2.8331.0.fbl_loc.120425-2034
编译日期：2012年4月25日
泄漏情况：2014年12月14日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d53eb6c9a786c9173763a40dc33d70cf3ac75793.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/90566bf531adcbef76b88832a6af2edda2cc9f6f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f243b7a30cf431ad345fb50d4136acaf2fdd986f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8de5158a4710b9129da100cac9fdfc0393452293.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cde466e83901213fb27cb8e85ee736d12e2e95a8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d41a971e3a292df5c08a5e21b6315c6035a873aa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/86a877395343fbf25e625417ba7eca8064388faa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/edc03e83b2b7d0a2f503f6a9c1ef76094a369a36.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8f0879168a82b901c6573107798da9773812ef06.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7d9932fab2fb4316d2eb874e2aa4462308f7d300.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/891e72cf36d3d539549ef2f73087e950342ab05d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/973e1cca0a46f21f72c0a367fc246b600d33ae00.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/65d9b32b2834349bdfeb93b1c3ea15ce37d3be0f.jpg)
控制面板上面的阳光消失
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f8794fc3eb51ad81b0ef41ad53a32.jpg)
光标也被压平
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2b946b328744ebf8c85a980bd3f9d72a6159a7d5.jpg)
【完美融合·混沌】
Windows 8 Build 8375
吐槽：和8331没有区别
阶段：Pre-Release Preview
详细版本：6.2.8375.0.winmain_win8rc.120504-1900
编译日期：2012年5月4日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8f0879168a82b901c0523f07798da9773812ef79.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6d0187ff9925bc317dcbfdac54df8db1ca137061.jpg)
【完美融合·混沌】
Windows 8 Build 8383
吐槽：任务栏被扁平化
阶段：Pre-Release Preview
详细版本：6.2.8383
编译日期：未知
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c0056accbef7609b15a66ab24dda3cc7dd99ea3.jpg)
【完美融合·毒香】
Windows 8 Build 8400
吐槽：默认壁纸变成小清新的红色郁金香壁纸，任务栏预览改进，部分图标Win8化，Metro应用的图标大部分定形，进度条扁平化，超级按钮略微改进，Metro设置的设备变灰。Aero在最后的疯狂中…
阶段：Release Preview
详细版本：6.2.8400.0.winmain_win8rc.120518-1423
***
编译日期：2012年5月18日
泄漏情况：2012年6月1日公开发布 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94f352fbe6cd7b890b0990be052442a7d8330e9f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e918ed12632762d02a5b0e82aaec08fa503dc698.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7d9932fab2fb4316857ad0472aa4462308f7d398.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cae7042662d0f7034fd73fe102fa513d2797c598.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/745c39de8db1cb131919962ed754564e93584b94.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab0c7d4d510fd9f928a9ff542f2dd42a2934a443.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/13b79cf3b2119313a624558d6f380cd790238d99.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2b9791256b600c337f954af5104c510fd8f9a111.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/86a877395343fbf2a07a321eba7eca8064388faa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dc76b659ccbf6c81d9feb8d5b63eb13532fa4033.jpg)
地图应用
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3fca0008c93d70cf55043e30f2dcd100bba12b02.jpg)
相机应用
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f9f52d91f603738d1d629b1fb91bb051f919ecdd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e6eacfd2fd1f4134f69893432f1f95cad0c85e51.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fccad63433fa828bfbc50bdef71f4134960a5a1a.jpg)
系统和安全图标Win8化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d8d6150f0cf3d7ca954ca94bf81fbe096a63a94f.jpg)
更新也Win8化 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/303b5cc69f3df8dcbf2b1eacc711728b461028ea.jpg)
进度条扁平化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a00afe24bc315c607384fad287b1cb13485477eb.jpg)
Vista、Win7和7850～8250的任务栏预览大小是固定的，8400可以根据窗口大小判定任务栏预览大小
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1b41aeeb15ce36d3d16e130d30f33a87e850b19e.jpg)
帮助上面的渐变消失 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/303b5cc69f3df8dcbc931facc711728b46102852.jpg)
【完美融合·毒香】
Windows 8 Build 8422
吐槽：
阶段：Release Preview
详细版本：6.2.8422.fbl_core1_soc_partner.120525-1923
编译日期：2012年5月24日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ca76de004a90f603dd990e7a3312b31bb151eddc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e3381bd88d1001e91d788632b20e7bec55e797b8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43bb1ff1f736afc3d825ad58b919ebc4b64512d3.jpg)
【完美融合·毒香】
Windows 8 Build 8424
吐槽：Aero仍然存在，但这是已知最后拥有Aero的Build
阶段：Release Preview
详细版本：6.2.8424.fbl_woa_drop.120530-2000
编译日期：2012年5月30日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8c4b0b80800a19d8e846193839fa828ba71e46bf.jpg)
【七彩画纸·雏菊】
Windows 8 Build 8431
吐槽：Aero消失了，默衰，这个Build的元素彻底扁平化(前进后退向上刷新搜索按钮、地址栏背景惨白化、功能区背景惨白化、任务栏半透明扁平化、任务栏指向效果简化、桌面选框Win8化)
阶段：Pre-RTM
详细版本：6.2.8431.0.fbl_uex.120609-2000
编译日期：2012年6月9日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/112ee6ca39dbb6fd2deb7c1b0324ab18962b3754.jpg)
【七彩画纸·雏菊】
Windows 8 Build 8432
吐槽：RT的Aero也消失了，同时元素也彻底扁平化
阶段：Pre-RTM
详细版本：6.2.8432.0.fbl_woa.120611-2000
编译日期：2012年6月11日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/20ad422cd42a2834c373af3651b5c9ea14cebf28.jpg)
【七彩画纸·雏菊】
Windows 8 Build 8441
吐槽：控制面板左栏惨白化，多彩卡片式窗口出现(我怀疑843X的窗口是像10240那样惨白的样子)
阶段：Pre-RTM
详细版本：6.2.8441.0.winmain.120623-1614
编译日期：2012年6月23日
泄漏情况：来自远景，未泄露，只有PE泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a4614b513046163f6246a60af6a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/25cc6bd6912397ddaf8b00395382b2b7d1a28716.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f32afb83d158ccbf20632d0713d8bc3eb0354121.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e3381bd88d1001e927e38c32b20e7bec55e79721.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2acb608b3de9c829bcd61b26681800a18d8435c.jpg)
【七彩画纸·雏菊】
Windows 8 Build 8888
吐槽：8888相比之前泄露的版本，颜值简直是粑粑粑粑。oobe最后阶段～多彩画纸在8888首次出现。从8888开始，背景一直基佬紫，开机界面也一直是田字牌(除9431)。8888 当年被选作RTM，但因为其存在严重的bug，因此后来被跳跃版本9200直接覆盖。8888不包括任何 Modern UI 应用。由于并不受微软保护，此版本特别纯净
阶段：Pre-RTM
详细版本：6.2.8888.16384.win8_gdr_soc_intel.120724-2000
编译日期：2012年7月24日
泄漏情况：2014年12月14日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/678bf92e07082838a9295a29b299a9014d08f1d9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43bb1ff1f736afc3ec68b958b919ebc4b6451298.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ca76de004a90f603d1a11a7a3312b31bb151edf4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b0208c4acb9dc68d9f2d3562cc898.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b7df9500fb30f24c68b6a3ec295d143ac4b03eb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/11fbbef8d72a6059c80167272234349b023bbaf4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bdeb2635970a304e774621c7dbc8a786c8175c98.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/07e4de13c8fcc3cea565480e9845d688d53f205f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0fbe47a5462309f747c82d2f780e0cf3d6cad65a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd999f7b4e43301213fb90e912e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0b0f9cecab64034ff7d1413ba5c379310b551de0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d729c645ad345982bb5065af06f431adcaef842e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e1711a30f0c4090f603728de9e1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0bc2cbae2edda3cc6f3e381d0be93901203f922e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7b33f83cf8dcd100e7b47b1c788b4710b8122fdc.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b006dd062d9f2d39710a7d2a3ec8a136227cc84.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c760c3c37d1ed21b6352add8a76eddc450da3f6d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b2ebd9086b63f6248af8ba3e8d44ebf81b4ca358.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b32ad38e8c5494eedea28c2427f5e0fe98257e04.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8b1b11084b36acaf20d91bc176d98d1000e99cc3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cca0f3eff01f3a29035d58f39325bc315d607c6f.jpg)
明天：9200～9347
【七彩画纸·雏菊】
Windows 8 Build 9200
吐槽：相比8888，唯一的区别是内置了许多应用
阶段：RTM(8.0)
详细版本：6.2.9200.16384.win8_rtm.120725-1247
编译日期：2012年7月25日
泄漏情况：2012年10月26日正式推出
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f7b124a88226cffc1d29c78db3014a90f703ea87.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e178ebcf40e4090f603728de987.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c2d2a8fd1e178a82bc3f079ffc03738da877e887.jpg)
【七彩画纸·雏菊】
Windows 8 Build 9220、9222
吐槽：
阶段：Post-RTM(8.0)
详细版本：6.2.9220、6.2.9222
编译日期：未知
泄漏情况：来自远景、未泄漏 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8de5158a4710b91202f38dc1c9fdfc03934522d0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/03e20a234f4a20a47d5b46f89a529822730ed0b9.jpg)
【七彩画纸·雏菊】
Windows 8 Build 9289
吐槽：相比9200，区别是开始屏幕底色变为黑色，默认壁纸也是黑色
阶段：Alpha(8.1)
详细版本：6.3.9289.fbl_srv_wdacxml.121220
编译日期：2012年12月20日
泄漏情况：来自远景、未泄漏 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/11c9419659ee3d6d603efdf449166d224e4ade0e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fcc53b6134a85edf11d29a1c43540923dc5475ac.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8c4b0b80800a19d811c1fe3a39fa828ba41e46c0.jpg)
【七彩画纸·蓝天】
Windows Blue Build 9319
吐槽：内核升至6.3
阶段：Milestone 1(8.1)
详细版本：6.3.9319.0.winmain.130208-1820
编译日期：2013年2月8日
泄漏情况：来自远景、未泄漏 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89c917ce3bc79f3d387b800fb0a1cd11738b2968.jpg)
【七彩画纸·蓝天】
Windows Blue Build 9347
吐槽：外观毫无区别，据说增强了系统的搜索功能
阶段：Milestone 1(8.1)
详细版本：6.3.9347.0.winmain_bluem1.130220-1504
编译日期：2013年2月20日
泄漏情况：来自远景、未泄漏 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91fdd4df9c82d1586a783e8e8a0a19d8bd3e4208.jpg)
【七彩画纸·蓝天】
Windows Blue Build 9364
吐槽：改进非常多的Milestone 1版本，OOBE个性化颜色继续增长。新增四个应用(闹钟、计算器、录音机、影音时光)，开始屏幕的批量功能改进。同时磁贴大小已有四种规格，开始屏幕个性化被集成在超级按钮侧栏上，更方便！ 超级按钮侧栏更人性化。IE升级为11，分屏功能改善并定型。同时设置终于可以与控制面板有可比性了。安装程序的假透明消失。用户文件夹出现在计算机主页上。
阶段：Milestone 1(8.1)
详细版本：6.3.9364.0.fbl_partner_out13.130315-2105
编译日期：2013年3月15日
泄漏情况：2013年3月24日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43cf3cb4c9ea15ce4035e721bc003af33b87b230.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ef371e300a55b319f222855d49a98226cefc1737.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a8f65097bf40ad1203fc0cb5d2c11dfa8ecce30.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e772ae167f3e6709129842d731c79f3df9dc5577.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b828b601baa1cd11912e7508b312c8fcc2ce2d77.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dc76b659ccbf6c8148ec2bc0b63eb13532fa4030.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab0c7d4d510fd9f9bb8c52412f2dd42a2934a470.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/97de0758252dd42a46830083093b5bb5c8eab801.jpg)
安装程序的假透明消失。呈灰色
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d3e7d77fca8065388876a53b9ddda144ac34826b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd9192b34f13301213fb90e918d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6fdade399b504fc275e2b02defdde71191ef6d4a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/891e72cf36d3d539c3090feb3087e950342ab0d3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e71ba91a9d16fdfa0588c6c6be8f8c5495ee7b23.jpg)
四种规格有了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/01c0f00b304e251f44f5e7d0ad86c9177e3e5389.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da97718008503ba51f8198718e3e4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2acb608b3de9c8210ecfaa76681800a18d84306.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab0c7d4d510fd9f9bf5256412f2dd42a2934a442.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a1949728bd4b31cabcf97938dd6277f9f2ff818.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab30d04443a98226d7d3290f8082b9014b90ebf9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0bc2cbae2edda3ccedc0ba080be93901203f92e3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c23f62297dda14428616e9ab8b7d0a20df486a7.jpg)
这个风格完爆其他公司的设计[真棒]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/09a06e22dd54564e2e2fe611b9de9c82d0584f41.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/592cdb3fb13533fa4ab09106a2d3fd1f40345b8d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b0eb5d282df5e0fe281e8b29566034a85fdf728d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5b21ca6fddc451da700f0ec3bcfd5266d1163216.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/79f5463eb80e7becccdc01c9252eb9389a506b8d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/11fbbef8d72a60594cf4e3322234349b023bba23.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab0c7d4d510fd9f9b0f357412f2dd42a2934a423.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4f47682542a7d933ca25e65ba74bd11372f00179.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/891e72cf36d3d539c4ea02eb3087e950342ab03c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91f4dda0cd11728b9a13800ac2fcc3cec2fd2cd5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3fca0008c93d70cfedc3a625f2dcd100bba12bd6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9596e234e5dde71130bd4fdeadefce1b9c1661a4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cca0f3eff01f3a2980a7d9e69325bc315d607ca4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d8d6150f0cf3d7ca2c2e305ef81fbe096a63a937.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2acb608b3de9c826d53f7a76681800a18d843dd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dde29afbaf51f3de12e2b74c9eeef01f3b2979bf.jpg)
出现了SkyDrive，SkyDrive与系统高度整合
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/833aa4fcfc0392453421ef278d94a4c27c1e2573.jpg)
系统属性完善
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f8794416b4606d81b0ef41ad53a73.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0253be32c895d143ad25ea0b79f082025baf07bf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4aa1d418ebc4b7455103b93ec5fc1e178b821573.jpg)
网络设置分化并扩展
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/191a5a6c55fbb2fb0878563a454a20a44723dcb8.jpg)
应用设置分化并扩展 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/191a5a6c55fbb2fb084e563a454a20a44723dca2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9a402dec2e738bd49753ba19ab8b87d6267ff999.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91b7ca4ad11373f0836467b7ae0f4bfbfaed04b7.jpg)
轻松使用设置出现
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cb20d41d8701a18ba1ec1967942f07082938fe8c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e918ed12632762d0c87cac97aaec08fa503dc649.jpg)
恢复相关设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e179e5684194090f603728de926.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94de4f35349b033b3ca6f7f21fce36d3d439bde5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/967cb33e8794a4c29ed2ec0304f41bd5ac6e391e.jpg)
***
IE升级为11，不过RTM什么鬼
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d3e7d77fca806538762baf3b9ddda144af3482ce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d41a971e3a292df548eca63db6315c6035a873e4.jpg)
【七彩画纸·蓝天】
Windows Blue Build 9369
吐槽：超级按钮的搜索与所有应用分开，同时所有应用的打开接口更快捷，开始屏幕下方提供了一个按钮，点击就可以打开应用程序列表，再次点击就能关闭。超级按钮的共享界面细微改进。SkyDrive应用被替换成更方便的Files应用。超级按钮变得更加透明了。这个版本有一个触发率中等的显示BUG
阶段：Milestone 1(8.1)
详细版本：6.3.9369.0.fbl_partner_out14.130324-1300
编译日期：2013年3月24日
泄漏情况：2013年4月16日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4903f7539822720e43a197d271cb0a46f31faba4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b2ebd9086b63f6243c5c4c2b8d44ebf81b4ca38e.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da9772e2ef303ba51f8198718e38e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c6ec517bdab44aed3121cbccb91c8701a08bfba4.jpg)
超级按钮的搜索与所有应用分开 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ec5b49dca3cc7cd908a045f13301213fb90e917a.jpg)
超级按钮的共享改进
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3e08f377e2888ba61ea9d34510.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4aa1d418ebc4b7454babc73ec5fc1e178b8215cb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a9d0df98a9014c084754588d007b02087af4f4a4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/eb90644e78f0f736adba3c290055b319eac41342.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5b21ca6fddc451da62a97cc3bcfd5266d11632b4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b020856414fc968d9f2d3562cc807.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d1d7f0dca144ad342f1ff5afdaa20cf430ad856f.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9374
吐槽：开始屏幕的批量界面更统一，同时开始屏幕个性化的界面也更新了，超级按钮搜索更简洁， “所有应用”按钮已变成箭头状，正式定名8.1。对部分元素进行了更新
阶段：Milestone 2
详细版本：6.3.9374.0.fbl_partner_out15.130329-2355
编译日期：2013年3月29日
泄漏情况：2013年4月19日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94de4f35349b033b067f81f21fce36d3d439bd1c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/83099b029245d6880139ce8caec27d1ed31b24d0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ef371e300a55b319e833ff5d49a98226cdfc17c0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bd0ec850f3deb48f1564ddf6fa1f3a292cf578fa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/61cbdf0f7bec54e7be1b6736b3389b504ec26a1c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3ed8cc5b74543a9871786e414178a82b80114fa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c13f5edab6fd5266336e403ca118972bd5073642.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9a402dec2e738bd4ab00ce19ab8b87d6267ff9ee.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5ee3ed83b9014a90fd1f3a95a3773912b21beeee.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a9d0df98a9014c084b1a548d007b02087af4f4ee.jpg)
开始屏幕的批量界面更统一，同时开始屏幕个性化的界面更紧凑了， “所有应用”按钮已变成箭头状。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc758ecb1c4db00baa1cc112a1b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e772ae167f3e67090dec39d731c79f3df9dc551b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/17d876dea9ec8a1352b72bc8fd03918fa1ecc05a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a075d86e950352aa09159205943fbf2b3118b1f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dc76b659ccbf6c81300853c0b63eb13532fa40d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a8f65097bf40ad14914bbcb5d2c11dfa8ecce1f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/83099b029245d688005ecd8caec27d1ed31b24ab.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9375
吐槽：外观和9374相似
详细版本：6.3.9375.0.fbl_partner_out14.130328-1742
编译日期：2013年3月28日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/47fc4f391f30e92499e8e31946086e061c95f7bb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/61cbdf0f7bec54e7b07c6536b3389b504ec26a7f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8be72e550923dd54fe3ed840db09b3de9d8248ba.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9379
吐槽：外观还是和9374相似
详细版本：6.3.9379.0.fbl_partner_out14.130410-1711
编译日期：2013年4月10日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c2f63daea40f4bfb0cc4e07c094f78f0f63618f3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94f352fbe6cd7b89776e44ab052442a7d8330e89.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c2d2a8fd1e178a82be920188fc03738da877e865.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9385
吐槽：应用基本汉化完成。相机、音乐、视频，影音时光获得改进。IE 11出现了全新F12工具
详细版本：6.3.9385.0.fbl_partner_out17.130415-2049
编译日期：2013年4月15日
泄漏情况：2013年5月1日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab0c7d4d510fd9f970a697412f2dd42a2934a45f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d41a971e3a292df5100d6e3db6315c6036a873c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a9a4522bc65c1038e9860ceab8119313b17e8910.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a6391c889e510fb330a9b5bfd333c895d0430c5f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dea568b20f2442a798f53f8ddb43ad4bd0130210.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ef371e300a55b319bf02405d49a98226cefc1710.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dba428c3d5628535051b10099aef76c6a6ef6311.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c2d2a8fd1e178a82e2c6bd88fc03738da877e812.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a2505d8f2d3572c6ee851f48013632763d0c382.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3304e5035aafa40f0cdc01f5a164034f79f019f1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/50cc3442fbf2b21129244a66c08065380dd78e82.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8808a4cfc3fdfc03b0472c90de3f8794a5c226d4.jpg)
音乐的风格再也不是玩具了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/746f643a5bb5c9eab8e9cccbdf39b6003bf3b3f2.jpg)
视频也简洁了许多
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a738e51352ac65ca60fa95bf1f2b21192138a82.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/035de527cffc1e17dd4a43194090f603728de913.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89c917ce3bc79f3def282b18b0a1cd11708b29c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/480e363c269759eeb55caee3b8fb43166c22df84.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d01b11c7a7efce1b7c3301e2a551f3deb58f65f0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4fd025a6d933c895ee585653db1373f0830200ed.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b02080cc5f1c968d9f2d3562cc884.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/42fc1cf50ad162d988e1ac341bdfa9ec8b13cd85.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/65ebf2cbd1c8a786c64384266d09c93d71cf50a6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a6391c889e510fb333d3b8bfd333c895d3430cc1.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9388
吐槽：
详细版本：6.3.9388.0.fbl_partner_out18.130429-2155
编译日期：2013年4月29日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c13f5edab6fd5266e011f53ca118972bd50736d1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/01c0f00b304e251f9ebe2dd0ad86c9177e3e5346.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f6f45df23a87e95087583a441a385343faf2b445.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f7b124a88226cffc4a66769ab3014a90f703ea44.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8a7402390cd7912329db5d5ca7345982b3b780d1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da97762604f03ba51f8198718e345.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9405
吐槽：闹钟、计算器、录音机转正，闹钟、计算器磁贴色调由灰色转为草绿色，录音机磁贴色调由灰色转为橙色，所有应用搜索框多了个放大镜图标
详细版本：6.3.9405.0.fbl_partner_out20.130515-1746
编译日期：2013年5月15日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dfc99fddd100baa1dabc8f934d10b912c9fc2e7f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1b41aeeb15ce36d379a34b1830f33a87e850b16d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cde466e83901213f68db86f45ee736d12e2e9520.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6d0187ff9925bc31b1b5c9b054df8db1ca137020.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91b7ca4ad11373f0c398a7b7ae0f4bfbfaed046c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8808a4cfc3fdfc038de82b90de3f8794a5c2267f.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9410
吐槽：鸡肋般的开始按钮又回来了。同时磁贴放大/缩小按钮进行了合并
阶段：Milestone 2
详细版本：6.3.9410.0.fbl_partner_out21.130522-1653
编译日期：2013年5月15日
泄漏情况：未泄露，部分图片来自视频网站
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c760c3c37d1ed21b2c8e1acca76eddc450da3f4c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f86dce004c086e0673d00b6208087bf40bd1cb90.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/990db02b6059252d74ab292d3e9b033b5ab5b954.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3379ce763912b31be890f9008c18367adbb4e114.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b32ad38e8c5494ee1229383027f5e0fe98257e81.jpg)
【七彩画纸·蓝天】
Windows 8.1 Build 9415
吐槽：计算机更名为此电脑(之后变成了这台电脑)Windows 7的库“消失”(我想说消失的好！[哈哈])此电脑主页的用户文件夹去除了“我的”字样。电脑设置Win8.1风格化，对设置项目进行了统一分类，设置里的搜索被移到深色侧栏的上边
阶段：Milestone 2
详细版本：6.3.9415.0.fbl_partner_out22.130525-0845
编译日期：2013年5月25日
泄漏情况：未泄露，图片来自远景 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c722407e9e2f07084ddb1c29e324b899a801f236.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e6eacfd2fd1f413496c533572f1f95cad0c85e19.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3efd750f81986186f99d9ad40ed2e738ad4e636.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c6ec517bdab44aed75568fcdb91c8701a08bfbf0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/b8ede119367adab410d12a6a81d4b31c8601e48f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/79f5463eb80e7bec980b35c8252eb9389a506b3f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a529801090ef76c67f05cd029716fdfaae51673d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/833aa4fcfc039245cc63d7268d94a4c27c1e253d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/42fc1cf50ad162d9803f54351bdfa9ec8b13cd3f.jpg)
【青蓝沙滩】
Windows 8.1 Build 9428
吐槽：开始按钮被固定在左下角，其余其他变化未知
阶段：Milestone Preview
详细版本：6.3.9428.0.winmain_bluemp.130612-1715
编译日期：2013年6月12日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3c2dea1101e93901e543b01771ec54e737d1964f.jpg)
【青蓝沙滩】
Windows 8.1 Build 9431
吐槽：最灵动的Beta鱼上线！开始屏幕可以和桌面同一个壁纸。可以登录到桌面，屏幕键盘的表情全彩化。OOBE个性化定形以及完善。OOBE最后阶段的超级按钮教程消失，全新的开始屏幕布局。新增美食、健康、帮助与提示(占位符，并不可用)、阅读列表、扫描等应用。更新了所有应用。几乎所有应用都有了搜索框。控制面板加入了一个新的选项：工作文件夹。IE 11的F12开发工具风格转为暗黑。此电脑变成了这台电脑。Win32应用的磁贴全彩化。Win+X菜单多了关机选项。显示设置有变化了
阶段：Milestone Preview
详细版本：6.3.9431.0.winmain_bluemp.130615-1214
编译日期：2013年6月15日
泄漏情况：2013年6月26日公开发布 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9596e234e5dde711f96a06e3adefce1b9c166164.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c5c182dce71190ef1c43d7cac41b9d16fcfa6064.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a529801090ef76c6cc6abe3e9716fdfaae516764.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a7e5f7ee76c6a7efa29eed33f7faaf51f2de6664.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d01b11c7a7efce1bf0938ddfa551f3deb58f6564.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3632c0eece1b9d16937fdf74f9deb48f8d546464.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e71ba91a9d16fdfac0d483fbbe8f8c5495ee7b64.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8eeffa17fdfaaf51835bc4aa865494eef11f7a64.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a9d0df98a9014c0893396cb0007b02087af4f49f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3ed8cc5b74543a95ee2bdd914178a82b801141b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c23f62297dda144e42e2aa7b8b7d0a20df486f1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/222d95d2572c11dfaf13f836692762d0f503c2de.jpg)
Win32应用的磁贴全彩化。并且所有应用的搜索框更融为一体 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dfc99fddd100baa16c3901ae4d10b912c9fc2e87.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43bb1ff1f736afc3ac527970b919ebc4b64512ba.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c07b0cb7bcb0a46d212cd2c6163f6246a60afec.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f8fa1ced54e736d17106ca1d91504fc2d4626987.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c7b08cf91a4c510ff3d1a40f6a59252dd52aa587.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4903f7539822720e166ca2ef71cb0a46f31fab7e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f87940f8b083bd81b0ef41ad53aa0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/592cdb3fb13533fa08c2d33ba2d3fd1f40345ba0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dfc99fddd100baa1529707ae4d10b912c9fc2e65.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2acb608b3de9c825361b99a6681800a18d84390.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/79f5463eb80e7bec0eab43f4252eb9389a506ba3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/23d305d1f703918fa94e7ddf5b3d269758eec479.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/17d876dea9ec8a13662817f5fd03918fa1ecc0ee.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2c75e70b19d8bc3e397f46df888ba61ea9d345a1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a8f65097bf40ad19c4484f65d2c11dfa8ecce7d.jpg)
IE 11的F12开发工具风格转为暗黑 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/01c0f00b304e251f0518a6edad86c9177e3e5329.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89c917ce3bc79f3d61efa925b0a1cd11738b298a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8808a4cfc3fdfc03365eaeadde3f8794a5c226f2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/150fd5fa43166d225f7958814c2309f79152d28a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8808a4cfc3fdfc033676aeadde3f8794a5c2268a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fa55aa10728b4710270bb1d9c9cec3fdfd0323f0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3c2dea1101e939017217c12b71ec54e737d19687.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c7b08cf91a4c510ffd82ae0f6a59252dd52aa552.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f3ed8cc5b74543a9573eb6d914178a82b80114f7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91f4dda0cd11728bda09c037c2fcc3cec2fd2cf0.jpg)
【青蓝沙滩】
Windows 8.1 Build 9450
吐槽：
阶段：Milestone Preview
详细版本：6.3.9450.0.winmain.130625-1705
编译日期：2013年6月25日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0253be32c895d1436d5daa3679f082025baf07f5.jpg)
【青蓝沙滩】
Windows 8.1 Build 9456
吐槽：
阶段：Milestone Preview
详细版本：6.3.9456.0.fbl_partner_out27.130703-2335
编译日期：2013年7月3日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b7df9500fb30f24f5715916c295d143ac4b0335.jpg)
【青蓝沙滩】
Windows 8.1 Build 9471
吐槽：开始屏幕个性化有了更多选项。美食应用更新了图标，健康应用的磁贴颜色变成橙色，帮助与提示正式可用。新增了Skype应用。几乎所有应用都有了搜索按钮。阅读列表更新。Win+X菜单的关机选项变成了三个选项。屏幕键盘加入了更多表情。控制面板工作文件夹的图标定形。设置主页微调。
阶段：Pre-RTM
详细版本：6.3.9471.0.fbl_partner_out30.130726-2004
编译日期：2013年7月26日
泄漏情况：2013年8月12日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e1b0ca355982b2b7e9e08ad13badcbef77099b99.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/49d0cc19972bd4079ee860e871899e510eb309e9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/79f5463eb80e7bec1da6b0f4252eb9389a506b98.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2b1b189d43f87943f25f83bd81b0ef419d53ac6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/16baf559d109b3deec03577dc6bf6c81810a4c58.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/61cbdf0f7bec54e77cc5a90bb3389b504ec26aeb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c760c3c37d1ed21b93af9df0a76eddc450da3fb2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da977e85b353eba51f8198718e3a1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d2acb608b3de9c82a0ad4a9a6681800a1bd843d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5ee3ed83b9014a903b63f4a8a3773912b21beeb8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8f0879168a82b90186aa7126798da9773812ef92.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/68cc7831e924b8994fcbca2d64061d950b7bf622.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/91fdd4df9c82d158be4aeaa48a0a19d8be3e42d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3c2dea1101e9390167f43e2b71ec54e737d19622.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3deab51a0ef41bd533d95ae15bda81cb38db3d16.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f8fa1ced54e736d165143e1d91504fc2d4626991.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5d616d7a02087bf4e694e5fcf8d3572c10dfcfa5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3b1833e636d12f2ef5cf1d7545c2d562873568d6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc7177170f9db00baa1cc112aa3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7b33f83cf8dcd10036474a34788b4710bb122fc5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dba428c3d5628535aab66f349aef76c6a6ef6342.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/32fa6bf2d7ca7bcb00277a3ab4096b63f724a8b8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/43cf3cb4c9ea15ce16615d1cbc003af33b87b209.jpg)
【青蓝沙滩】
Windows 8.1 Build 9477
吐槽：Mail采用了新的色彩，帮助和提示的图标发生了变化，开始屏幕也可以选择更多的壁纸了。并且首次拥有了入门向导。
阶段：Pre-RTM
详细版本：6.3.9477.0.fbl_partner_out31.130803-0736
***
编译日期：2013年8月3日
泄漏情况：2013年8月21日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/9d3036db81cb39dbcf96e305da160924aa183000.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/480e363c269759eeef13e498b8fb43166c22df1c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d9d1db305c6034a865683cd2c11349540b2376d4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4f47682542a7d93340fe6020a74bd11372f00100.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b0208ba6bbbb268d9f2d3562cc83d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8a7402390cd791239e6b1027a7345982b0b780cb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a2505d8f2d3572cd7a1188f8013632763d0c31c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c2f63daea40f4bfb6b2a1907094f78f0f53618e4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/792fd1fc5266d01675fa1a7b9d2bd40737fa35f3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fa55aa10728b4710dfb2799fc9cec3fdfd03233d.jpg)
【青蓝沙滩】
Windows 8.1 Build 9483
吐槽：这个Build没有时间炸弹，并且内置神秘应用
阶段：Pre-RTM
详细版本：6.3.9483.0.winblue_rtm.130809-2020
编译日期：2013年8月9日
泄漏情况：2013年8月28日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3fca0008c93d70cf6e6f255ef2dcd100b8a12bc5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/27fdae3c70cf3bc7c99542bfdb00baa1cf112ac5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89c917ce3bc79f3daf746b63b0a1cd11708b29c5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/303b5cc69f3df8dc89a800c2c711728b451028c5.jpg)
【几何分屏】
Windows 8.1 Build 9600.16384
吐槽：这个Build为某些程序引入了一些不同的窗口尺寸，采用了一个新的锁屏背景和大黄默认壁纸。还包含了一个新的主题。开始屏幕布局和一些应用更新。
阶段：RTM【2013】
详细版本：6.3.9600.16384.winblue_rtm.130821-1623
编译日期：2013年8月21日
泄漏情况：2013年8月27日泄露，10月18日发布
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cae7042662d0f703e5daa98902fa513d2797c574.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5fc48e25b899a9012986666317950a7b0308f52d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a2505d8f2d3572c7e39a1898013632760d0c385.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bd0ec850f3deb48f56b79c8bfa1f3a292ff578fa.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/eb90644e78f0f736902371540055b319e9c413fe.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d1d7f0dca144ad34ec5dbad2daa20cf433ad85fe.jpg)
【几何分屏】
Windows 8.1 Build 9600.16596
吐槽：这个Build有了一些Windows 10的基本特点。比如IE升级到11.0.3，2013变成2014，开始屏幕布局更新并且出现搜索及关机按钮，开始屏幕右键菜单(这是个倒退)。所有应用默认排列更新。Modern应用支持固定到任务栏，Modern应用支持显示任务栏。Modern应用有标题栏和关闭按钮。SkyDrive界面更新。
阶段：Update 1 Beta
详细版本：6.3.9600.16596.winblues14_gdr_lean.140114-0237
编译日期：2014年1月14日
泄漏情况：2014年1月22日图片泄露，2月3日镜像泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ca76de004a90f60300c94b1f3312b31bb151ed67.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/eb90644e78f0f736caec9b590055b319eac41349.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/a00afe24bc315c603e49bfb787b1cb134b5477fb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/25cc6bd6912397dd7ba44c5c5382b2b7d2a287fb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fccad63433fa828bb8304abbf71f4134960a5a48.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0253be32c895d143f40d337b79f082025baf0760.jpg)
【几何分屏】
Windows 8.1 Build 9600.16610
吐槽：SkyDrive更名为OneDrive。
阶段：Update 1 Beta
详细版本：6.3.9600.16610.winblue_s14.140201-1007
编译日期：2014年2月1日
泄漏情况：2014年2月7日补丁泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/891e72cf36d3d539756fdd9b3087e950342ab00a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f47beb5594eef01fc446ca9deafe9925bd317d0a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/141351d02f2eb93877fda8aadf628535e7dd6fc8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/42fc1cf50ad162d97c48b0441bdfa9ec8b13cd3e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e3381bd88d1001e9dd43c657b20e7bec55e79765.jpg)
【几何分屏】
Windows 8.1 Build 9600.17019
吐槽：Modern应用标题栏字体优化
阶段：Update 1 Beta
详细版本：6.3.9600.17019.winblue_gdr.140205-2003
编译日期：2014年2月5日
泄漏情况：已泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/92ef69f51bd5ad6ee31bb9b28bcb39dbb4fd3cf9.jpg)
【几何分屏】
Windows 8.1 Build 9600.17024
吐槽：开始屏幕布局更新优化
阶段：Update 1 Beta
详细版本：6.3.9600.17024.winblue_gdr_s14sku_partner.140214-1700
编译日期：2014年2月5日
泄漏情况：2014年2月22日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/83099b029245d688e1c46efcaec27d1ed01b249d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6fdade399b504fc239986c5defdde71192ef6d9d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ab30d04443a98226a91af77f8082b9014890eb81.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a1949728bd4b31cfefd48e38dd6277f9c2ff89f.jpg)
【几何分屏】
Windows 8.1 Build 9600.17031
吐槽：最终RTM！
阶段：RTM(2014)
详细版本：6.3.9600.17031.winblue_gdr.140221-1952
编译日期：2014年2月21日
泄漏情况：2014年4月发布 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f08aad8165380cd75f297cb5ab44ad34588281ad.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c7b08cf91a4c510f6a373d426a59252dd62aa5e9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fefd0c62f6246b60a24c6d2ce1f81a4c500fa21a.jpg)
Windows 8 完！
【几何分屏】
Windows Build 9697
吐槽：这个Build可能拥有Update 1的特性
阶段：？
详细版本：6.X.9697.fbl_gdx_dev_p.140227-2030
编译日期：2014年2月27日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/fa55aa10728b471093162594c9cec3fdfd0323a6.jpg)
【双屏动感】
Windows Build 9788
吐槽：全新的开始菜单出现，开始菜单样式和布局接近win7。
阶段：Technical Preview 1
详细版本：6.4.9788.winmain.140704-2025
编译日期：2014年7月4日
泄漏情况：未泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/09a06e22dd54564e35b79d7fb9de9c82d3584f9f.jpg)
【双屏动感】
Windows Build 9795
吐槽：只是默认壁纸更换而已
阶段：Technical Preview 1
详细版本：6.4.9795.fbl_up_dev.140713-1834
编译日期：2014年7月13日
泄漏情况：未泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/5ee3ed83b9014a90f7a620fba3773912b11beed5.jpg)
【双屏动感】
Windows Technical Preview Build 9821
吐槽：开始菜单调整为全紫色，账户和关机按钮移动到左上边，开始菜单不再是97XX的win7样式，首次出现初始的搜索、任务视图、通知中心功能，资源管理器出现主页，一些图标极致扁平化。窗口边框消失。
阶段：Technical Preview 1
详细版本：6.4.9821？
编译日期：2014年？
泄漏情况：未泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/22249002918fa0ec21e6074b2c9759ee3c6ddb4c.jpg)
【双屏动感】
Windows Technical Preview Build 9833
吐槽：出现了一些神秘应用，并且设置出现预览版本通道
阶段：Technical Preview 1
详细版本：6.4.9833.0.fbl_release.140903-1451
编译日期：2014年9月3日
***
泄漏情况：2017年2月9日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/eb90644e78f0f7364af31bb50055b319eac4136e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a8f65097bf40ad171ba93575d2c11dfa8ecce19.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e17fe0d7277f9e2f01aa49bc1530e924ba99f3d8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f243b7a30cf431adaa25178d4136acaf2cdd9880.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8be72e550923dd54c728f3dcdb09b3de9d824824.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/79e6d41ab051f8197c6157fed0b44aed2f73e730.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/cb20d41d8701a18b847346fb942f07082a38fedb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d729c645ad345982ef7cb12606f431adc9ef8481.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0fbe47a5462309f7ba44faa6780e0cf3d6cad654.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/8861b642ad4bd113a8e5e08650afa40f4afb054b.jpg)
【双屏动感】
Windows Technical Preview Build 9834
吐槽：出现了一些和预览计划有关的应用
阶段：Technical Preview 1
详细版本：6.4.9834.0.fbl_partner_eeap.140908-0936
编译日期：2014年9月8日
泄漏情况：2014年12月12日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ed9abac551da81cb916937795866d0160b2431e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0b0f9cecab64034fbc4276b2a5c3793108551de8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f2e5f412b07eca8053d58d539b2397dda34483a3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/dde29afbaf51f3ded44a0dd09eeef01f382979fb.jpg)
【双屏动感】
Windows Technical Preview Build 9841
吐槽：唯一一个没有通知中心的公开版本Win10，onedrive相关过程集成在OOBE，搜索和反馈放开。并且更新设置改进
阶段：Technical Preview 1
详细版本：6.4.9841.0.fbl_release.140912-1613
编译日期：2014年9月12日
泄漏情况：2014年10月1日发布，第一个预览版 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/61cbdf0f7bec54e77dc6aaaab3389b504ec26a55.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/97de0758252dd42a352db11f093b5bb5c8eab857.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/75dea15d10385343d6e537959913b07ecb808855.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/eb90644e78f0f7366d8dfcb50055b319eac4130c.jpg)
【双屏动感】
Windows Technical Preview Build 9845
吐槽：
阶段：Technical Preview 1
详细版本：6.4.9845.0.fbl_partner_eeap.140922-1425
编译日期：2014年9月12日
泄漏情况：2015年10月6日泄露
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2b946b328744ebf80fc9d78bd3f9d72a6159a73b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4fd025a6d933c895650a2bcfdb1373f083020007.jpg)
【双屏动感】
Windows Technical Preview Build 9860
吐槽：主页改进，出现存储感知。出现两个神奇的应用，出现新版登录界面
阶段：Technical Preview 1
详细版本：6.4.9860.0.fbl_release.141008-2044
编译日期：2014年10月8日
泄漏情况：2014年10月21日推送 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94f352fbe6cd7b89352b8637052442a7d8330e30.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/90e26e25ab18972b737ebc7eeccd7b899f510a37.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/d0a6ff23720e0cf3d2f8f04f0046f21fbf09aa68.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/94cbe095a4c27d1e4b60877011d5ad6edcc43831.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/2ef27a940a7b0208928c835568d9f2d3562cc837.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4c0056accbef760970f8252b24dda3cc7ed99e8c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7a738e51352ac65c376adac7f1f2b21192138a08.jpg)
【双屏动感】
Windows Technical Preview Build 9879
吐槽：OOBE开始白化，搜索和虚拟桌面可以隐藏。会员中心开放。IE出现表情反馈。全屏搜索出现。早期的设置桌面个性化出现，并出现9926混合式开始。新版登录界面微调
阶段：Technical Preview 1
详细版本：6.4.9879.0.fbl_release.141103-1722
编译日期：2014年11月3日
泄漏情况：2014年11月8日推送 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/39c56d54b319ebc476a3c82d8826cffc1c1716a4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6fdade399b504fc29f840eb1efdde71192ef6da4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/750e81cc7b899e51a55a84a048a7d933ca950da7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7627b238b6003af31b0162d43f2ac65c1238b6c4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/ebecf02ad40735fa410df00d94510fb30d2408fe.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/7add4af4e0fe9925e2d9d7e43ea85edf8fb171a6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/222d95d2572c11df44040197692762d0f503c2a7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a1949728bd4b31c50e82a0f8dd6277f9c2ff8a0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/512bceed8a13632792397c879b8fa0ec0afac7a0.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/6050212209f790529967fe8a06f3d7ca7acbd57b.jpg)
【双屏动感】
Windows Technical Preview Build 9883
吐槽：OOBE全面白化，Win32的onedrive出现，而且Betta鱼疑似出现在这个版本上。还有出现了许多TX相关应用以及插图应用，这可能是UWP的开端
阶段：Technical Preview 1
详细版本：6.4.9883.0.fbl_release.141106-1705
编译日期：2014年11月6日
泄漏情况：已泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/f6f45df23a87e9502b7456d81a385343faf2b41c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c6ec517bdab44aedfe360450b91c8701a08bfb04.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4a8f65097bf40ad187eb7d575d2c11dfa8ecce69.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/89c917ce3bc79f3d7a995e84b0a1cd11738b297b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9835e13b31bb051335c099c3c7adab44bede004.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/1b41aeeb15ce36d3cf34398430f33a87e850b143.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/bdeb2635970a304e52591a4edbc8a786c8175c04.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a649102738da977f1203c9fba51f8198718e369.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/83099b029245d68844db0910aec27d1ed01b249a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/c5c182dce71190ef3dca286bc41b9d16fcfa6042.jpg)
【双屏动感】
Windows Technical Preview Build 9888
吐槽：第一个标为NT10的Build，但9888仍然很像NT6.x。所以这个Build是NT6.x的最后一个版本，它也是NT6.x的终点。
阶段：Technical Preview 1
详细版本：10.0.9888.0.fbl_release.141113-2137
编译日期：2014年11月13日
泄漏情况：2014年12月2日泄露 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/4aa1d418ebc4b745fff813a2c5fc1e178b82150f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/3fca0008c93d70cf442b0fb9f2dcd100b8a12ba2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/e9f52b096e061d95d52a938c71f40ad163d9ca08.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4931361992/0a1949728bd4b31c57c8330f8dd6277f9c2ff880.jpg)
Windows NT6.x 完！
