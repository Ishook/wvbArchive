今天早上，快递小哥给我发了一个短信，叫我去楼下的快递柜取件，盼望已久的Chipfancier固态U盘终于到货了，以下是开箱测评[滑稽] [茶杯]
先艾特人[滑稽] [玫瑰]
@cghvbnv22 @xiaobao8745 @微軟藍澤光 @oohkjv @盒饭洗米
这是盒子，快递单已经被我撕掉了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/89c917ce3bc79f3d167af58fb3a1cd11708b29ef.jpg)
从盒子里取出的有黄色袋子，绳子和快递单[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/792fd1fc5266d01603978f979e2bd40737fa35f3.jpg)
展示一下快递单，个人资料我已经涂掉了[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/8eeffa17fdfaaf514ff29100855494eef11f7a75.jpg)
黄色袋子里就是U盘[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/8f0879168a82b9016508d38c7a8da9773b12efd9.jpg)
这可真难开，胶粘得很紧啊[汗]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/d7fe574f251f95ca35618209c0177f3e650952ea.jpg)
取出了U盘，外观设计很好，但是大小比我想象中的大一点，没所谓[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/47fc4f391f30e924fe8d8f8e45086e061c95f75d.jpg)
黄色袋子也是带有防震功能的[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/1976d5b6d0a20cf4ad0ded607f094b36aeaf99e1.jpg)
插[吐舌]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/833aa4fcfc0392452e2ef2b08e94a4c27f1e25ef.jpg)
这个U盘的尾部是发光的，写入或读取文件时会闪烁[开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/cb20d41d8701a18bb9e500f0972f07082938fe7c.jpg)
店主默认分两区，F盘是PE，G盘是win10系统，但是由于这样跑分就很低了，所以我干脆用diskpart回归一个盘符好了，况且WTG装在一个盘的一个分区里稳定性比较好[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/43bb1ff1f736afc35bb42ddaba19ebc4b54512cd.jpg)
跑分如下，吊打我的旧CZ80[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4969670700/f0a59f188618367aed6c6d6227738bd4b11ce599.jpg)
但是我暂时不打算制做WTG，因为开学后就没机会玩了[滑稽]
不过这个U盘唯一的缺点是温度太高了，插入电脑一个小时后我拔下来，用温度计测得将近40摄氏度，逼得我要用酒精降温[怒]
