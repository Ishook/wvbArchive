![](http://www.xiami.com/album/2103583310?spm=a1z1s.6639561.471966069.2.fcbMg)
第一次发布专辑挺激动的呢，虽然只是一张EP。有请各位鉴赏，喜欢的话也荐给别人吧。
专辑封面镇楼
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5577417866/d7fe574f251f95ca48bbca98c5177f3e66095243.jpg)
***
主打曲10 Years of Vista，也不必我多说了，当然是为了纪念Windows Vista所作。从去年年中就在写，但是陆陆续续地一直没完成，直到去年年底才基本完工。现在润色完毕，可以发布了。
