出处 a.v9s.win/?p=846
一个个申请我还要审核弄的太麻烦了。现在开放直接获取！
OneDrive是微软的网盘业务，不受国内影响。此网盘是国内版！容量5T。
由于该文章被许多站长无良删除出处，不表明转载，甚至写成原创教程。一怒之下换域名！下面方法我已经改成最新的了！
转载不表明出处太恶心了，把所有与我有关的东西都删掉，还大大的写上原创！要脸不？
***
获取方法：
打开此网站。会自动分配给你一个临时邮箱，你也可以修改邮箱前缀为自己喜欢的前缀。（注：此邮箱会作为你的登录用户名，请你牢记！）
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5220387883/1292b7170924ab1824e2a8a33ffae6cd79890ba7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5220387883/bb06d5109313b07ef3b5189c06d7912396dd8c0b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5220387883/f9ccfc514fc2d562dcf99879ed1190ef74c66ca2.jpg)
好了at
@cghvbnv22 @asministstor @孙必林 @Longhorn4093 申精
--来自2006bt专属贴吧UWP
***